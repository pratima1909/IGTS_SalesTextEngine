# IGT Systems Sales Text Engine

A local web app for searching existing sales text and producing catalogue-guided drafts for new items.

## Open the app

Double-click `index.html` to use catalogue search and the local guided writer without setup. All matching and draft construction happen in the browser against the embedded catalogue; no API key or external service is used.

## Open through the local server (optional)

1. Open a terminal in this folder and run `npm start`.
2. Open [http://localhost:4173](http://localhost:4173).

Search by item ID, product name, MAG/AG code, or words inside either sales-text field. Use the text tabs to switch between short and long copy, then select **Copy text**.

Select **Write new sales text** to open the studio. Enter keywords and approved product facts. The browser retrieves up to five similar catalogue entries and uses a deterministic guided template to build editable short and long drafts. The result must receive human and claims review before use.
