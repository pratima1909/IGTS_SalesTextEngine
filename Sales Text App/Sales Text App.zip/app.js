const elements = {
  search: document.querySelector("#searchInput"),
  clearSearch: document.querySelector("#clearSearch"),
  typeFilter: document.querySelector("#typeFilter"),
  availabilityFilter: document.querySelector("#availabilityFilter"),
  resetFilters: document.querySelector("#resetFilters"),
  resultCount: document.querySelector("#resultCount"),
  resultList: document.querySelector("#resultList"),
  emptyResults: document.querySelector("#emptyResults"),
  loadMore: document.querySelector("#loadMore"),
  sourceLabel: document.querySelector("#sourceLabel"),
  loadingState: document.querySelector("#loadingState"),
  detailEmpty: document.querySelector("#detailEmpty"),
  detailContent: document.querySelector("#detailContent"),
  breadcrumb: document.querySelector("#breadcrumb"),
  itemId: document.querySelector("#itemId"),
  itemType: document.querySelector("#itemType"),
  itemName: document.querySelector("#itemName"),
  quickMeta: document.querySelector("#quickMeta"),
  shortTab: document.querySelector("#shortTab"),
  longTab: document.querySelector("#longTab"),
  textLength: document.querySelector("#textLength"),
  salesText: document.querySelector("#salesText"),
  copyCurrent: document.querySelector("#copyCurrent"),
  copyCurrentTop: document.querySelector("#copyCurrentTop"),
  salesFlag: document.querySelector("#salesFlag"),
  detailsGrid: document.querySelector("#detailsGrid"),
  toast: document.querySelector("#toast"),
  openComposer: document.querySelector("#openComposer"),
  closeComposer: document.querySelector("#closeComposer"),
  composerBackdrop: document.querySelector("#composerBackdrop"),
  composerPanel: document.querySelector("#composerPanel"),
  composerForm: document.querySelector("#composerForm"),
  localStatus: document.querySelector("#localStatus"),
  generateDraft: document.querySelector("#generateDraft"),
  generateLabel: document.querySelector(".generate-label"),
  generateLoading: document.querySelector(".generate-loading"),
  draftItemName: document.querySelector("#draftItemName"),
  draftKeywords: document.querySelector("#draftKeywords"),
  draftFacts: document.querySelector("#draftFacts"),
  draftAudience: document.querySelector("#draftAudience"),
  draftTone: document.querySelector("#draftTone"),
  draftLength: document.querySelector("#draftLength"),
  draftEmpty: document.querySelector("#draftEmpty"),
  draftResult: document.querySelector("#draftResult"),
  draftError: document.querySelector("#draftError"),
  draftShortTab: document.querySelector("#draftShortTab"),
  draftLongTab: document.querySelector("#draftLongTab"),
  draftEditor: document.querySelector("#draftEditor"),
  draftCount: document.querySelector("#draftCount"),
  copyDraft: document.querySelector("#copyDraft"),
  draftModel: document.querySelector("#draftModel"),
  draftReferences: document.querySelector("#draftReferences"),
  factWarnings: document.querySelector("#factWarnings"),
};

const state = {
  items: [],
  filtered: [],
  selected: null,
  activeText: "short",
  visible: 50,
  query: "",
  type: "all",
  availability: "all",
  drafts: null,
  activeDraft: "short",
};

const normalize = (value) => String(value ?? "")
  .normalize("NFKD")
  .replace(/[\u0300-\u036f]/g, "")
  .toLowerCase();

const GUIDANCE_STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is", "it",
  "of", "on", "or", "that", "the", "this", "to", "with", "your", "new", "item", "product",
]);

const formatNumber = new Intl.NumberFormat("en-US");
const displayValue = (value) => value || "—";
let toastTimer;
let searchTimer;

function makeSearchIndex(item) {
  return normalize([
    item.id, item.name, item.shortText, item.longText, item.magCode, item.magName,
    item.agCode, item.agName, item.itemType, item.businessCategory, item.mru,
  ].join(" \u241f "));
}

function scoreItem(item, normalizedQuery, tokens) {
  if (!tokens.every((token) => item._search.includes(token))) return -1;
  if (!normalizedQuery) return 0;

  const id = normalize(item.id);
  const name = normalize(item.name);
  const shortText = normalize(item.shortText);
  const longText = normalize(item.longText);
  const mag = normalize(`${item.magCode} ${item.magName}`);
  const ag = normalize(`${item.agCode} ${item.agName}`);

  let score = 0;
  if (id === normalizedQuery) score += 1200;
  else if (id.startsWith(normalizedQuery)) score += 780;
  else if (id.includes(normalizedQuery)) score += 520;
  if (name === normalizedQuery) score += 1000;
  else if (name.startsWith(normalizedQuery)) score += 720;
  else if (name.includes(normalizedQuery)) score += 460;
  if (shortText.includes(normalizedQuery)) score += 270;
  if (longText.includes(normalizedQuery)) score += 180;
  if (mag.includes(normalizedQuery)) score += 160;
  if (ag.includes(normalizedQuery)) score += 130;
  score += tokens.reduce((total, token) => total + (name.includes(token) ? 35 : 0) + (shortText.includes(token) ? 20 : 0), 0);
  return score;
}

function hasRequestedText(item) {
  const hasShort = Boolean(item.shortText.trim());
  const hasLong = Boolean(item.longText.trim());
  if (state.availability === "both") return hasShort && hasLong;
  if (state.availability === "short") return hasShort;
  if (state.availability === "long") return hasLong;
  return true;
}

function applySearch({ preserveSelection = true } = {}) {
  const normalizedQuery = normalize(state.query.trim());
  const tokens = normalizedQuery.split(/\s+/).filter(Boolean);

  state.filtered = state.items
    .filter((item) => state.type === "all" || item.itemType === state.type)
    .filter(hasRequestedText)
    .map((item) => ({ item, score: scoreItem(item, normalizedQuery, tokens) }))
    .filter((result) => result.score >= 0)
    .sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name))
    .map((result) => result.item);

  state.visible = 50;
  elements.resultCount.textContent = formatNumber.format(state.filtered.length);
  elements.clearSearch.hidden = !state.query;
  elements.resetFilters.hidden = !(state.query || state.type !== "all" || state.availability !== "all");
  elements.emptyResults.hidden = state.filtered.length > 0;
  elements.resultList.hidden = state.filtered.length === 0;

  if (!preserveSelection || (state.selected && !state.filtered.includes(state.selected))) {
    state.selected = null;
    showEmptyDetail();
  }

  renderResults();
}

function getSnippet(item) {
  const query = normalize(state.query.trim());
  const candidates = [
    { label: "Long", text: item.longText },
    { label: "Short", text: item.shortText },
  ];
  const source = candidates.find(({ text }) => query && normalize(text).includes(query))
    || candidates.find(({ text }) => text.trim())
    || { label: "Text", text: "No sales text available" };
  const compact = source.text.replace(/\s+/g, " ").trim();
  const matchIndex = query ? normalize(compact).indexOf(query) : 0;
  const start = Math.max(0, matchIndex - 55);
  const excerpt = compact.slice(start, start + 170);
  return `${source.label}: ${start > 0 ? "…" : ""}${excerpt}${start + 170 < compact.length ? "…" : ""}`;
}

function renderResults() {
  const visibleItems = state.filtered.slice(0, state.visible);
  const fragment = document.createDocumentFragment();

  visibleItems.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "result-item";
    button.setAttribute("role", "option");
    button.setAttribute("aria-selected", String(state.selected?.id === item.id));
    button.dataset.id = item.id;

    const kicker = document.createElement("div");
    kicker.className = "result-kicker";
    const id = document.createElement("span");
    id.className = "result-id";
    id.textContent = item.id || "No ID";
    const type = document.createElement("span");
    type.textContent = item.itemType.replaceAll("_", " ") || "Item";
    kicker.append(id, type);

    const title = document.createElement("h3");
    title.textContent = item.name || "Unnamed item";
    const snippet = document.createElement("p");
    snippet.className = "result-snippet";
    snippet.textContent = getSnippet(item);

    const tags = document.createElement("div");
    tags.className = "result-tags";
    const group = document.createElement("span");
    group.className = "mini-tag";
    group.textContent = item.agName || item.magName || item.businessCategory || "Uncategorised";
    tags.append(group);
    if (item.longText) {
      const textStatus = document.createElement("span");
      textStatus.className = "text-dot";
      textStatus.textContent = "Long text";
      tags.append(textStatus);
    }

    button.append(kicker, title, snippet, tags);
    button.addEventListener("click", () => selectItem(item));
    fragment.append(button);
  });

  elements.resultList.replaceChildren(fragment);
  elements.loadMore.hidden = state.visible >= state.filtered.length || state.filtered.length === 0;
  if (!elements.loadMore.hidden) {
    elements.loadMore.textContent = `Show more · ${formatNumber.format(state.filtered.length - state.visible)} remaining`;
  }
}

function selectItem(item, { updateHash = true } = {}) {
  state.selected = item;
  const query = normalize(state.query.trim());
  const longMatches = query && normalize(item.longText).includes(query);
  const shortMatches = query && normalize(item.shortText).includes(query);
  state.activeText = longMatches && !shortMatches ? "long" : item.shortText ? "short" : "long";
  renderResults();
  renderDetail();
  if (updateHash) history.replaceState(null, "", `#id=${encodeURIComponent(item.id)}`);
  if (window.innerWidth <= 900) document.querySelector(".detail-panel").scrollIntoView({ behavior: "smooth" });
}

function createBreadcrumb(item) {
  const values = [item.businessUnit, item.businessCategory, item.mru].filter(Boolean);
  const fragment = document.createDocumentFragment();
  values.forEach((value) => {
    const span = document.createElement("span");
    span.textContent = value;
    fragment.append(span);
  });
  return fragment;
}

function renderQuickMeta(item) {
  const entries = [
    ["MAG", [item.magCode, item.magName].filter(Boolean).join(" · ")],
    ["AG", [item.agCode, item.agName].filter(Boolean).join(" · ")],
    ["Owner", item.ownership],
  ].filter(([, value]) => value);
  const fragment = document.createDocumentFragment();
  entries.forEach(([label, value]) => {
    const span = document.createElement("span");
    span.className = "quick-meta-item";
    const strong = document.createElement("strong");
    strong.textContent = `${label}:`;
    span.append(strong, document.createTextNode(value));
    fragment.append(span);
  });
  elements.quickMeta.replaceChildren(fragment);
  elements.quickMeta.hidden = entries.length === 0;
}

function renderDetails(item) {
  const entries = [
    ["Business", item.business],
    ["Business unit", item.businessUnit],
    ["Business category", item.businessCategory],
    ["MRU", item.mru],
    ["MAG", [item.magCode, item.magName].filter(Boolean).join(" — ")],
    ["AG", [item.agCode, item.agName].filter(Boolean).join(" — ")],
    ["Item type", item.itemType.replaceAll("_", " ")],
    ["Ownership", item.ownership],
    ["Short text bucket", item.shortBucket],
    ["Long text bucket", item.longBucket],
  ];
  const fragment = document.createDocumentFragment();
  entries.forEach(([label, value]) => {
    const wrapper = document.createElement("div");
    const term = document.createElement("dt");
    const description = document.createElement("dd");
    term.textContent = label;
    description.textContent = displayValue(value);
    wrapper.append(term, description);
    fragment.append(wrapper);
  });
  elements.detailsGrid.replaceChildren(fragment);
}

function renderDetail() {
  const item = state.selected;
  if (!item) return showEmptyDetail();
  elements.loadingState.hidden = true;
  elements.detailEmpty.hidden = true;
  elements.detailContent.hidden = false;
  elements.breadcrumb.replaceChildren(createBreadcrumb(item));
  elements.itemId.textContent = `ID ${item.id}`;
  elements.itemType.textContent = item.itemType.replaceAll("_", " ");
  elements.itemName.textContent = item.name || "Unnamed item";
  elements.shortTab.disabled = !item.shortText;
  elements.longTab.disabled = !item.longText;
  elements.salesFlag.textContent = item.salesTextFlag;
  renderQuickMeta(item);
  renderDetails(item);
  renderActiveText();
}

function renderActiveText() {
  if (!state.selected) return;
  const isShort = state.activeText === "short";
  const text = isShort ? state.selected.shortText : state.selected.longText;
  elements.shortTab.setAttribute("aria-selected", String(isShort));
  elements.longTab.setAttribute("aria-selected", String(!isShort));
  elements.salesText.textContent = text || `No ${isShort ? "short" : "long"} sales text is available for this item.`;
  elements.salesText.classList.toggle("is-empty", !text);
  const actualLength = text.length;
  elements.textLength.textContent = `${formatNumber.format(actualLength)} characters`;
  const label = `Copy ${isShort ? "short" : "long"} text`;
  elements.copyCurrent.setAttribute("aria-label", label);
  elements.copyCurrentTop.querySelector("span").textContent = label;
  elements.copyCurrent.disabled = !text;
  elements.copyCurrentTop.disabled = !text;
}

function showEmptyDetail() {
  elements.loadingState.hidden = true;
  elements.detailContent.hidden = true;
  elements.detailEmpty.hidden = false;
  history.replaceState(null, "", location.pathname + location.search);
}

async function copyActiveText() {
  if (!state.selected) return;
  const text = state.activeText === "short" ? state.selected.shortText : state.selected.longText;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.append(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }
  showToast(`${state.activeText === "short" ? "Short" : "Long"} text copied`);
}

function showToast(message) {
  elements.toast.querySelector("span").textContent = message;
  elements.toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => elements.toast.classList.remove("is-visible"), 2200);
}

function clearAllFilters() {
  state.query = "";
  state.type = "all";
  state.availability = "all";
  elements.search.value = "";
  elements.typeFilter.value = "all";
  elements.availabilityFilter.value = "all";
  applySearch({ preserveSelection: false });
  elements.search.focus();
}

function setComposerOpen(open) {
  elements.composerPanel.hidden = !open;
  elements.composerBackdrop.hidden = !open;
  elements.openComposer.setAttribute("aria-expanded", String(open));
  if (open) {
    setTimeout(() => elements.draftKeywords.focus(), 0);
  } else {
    elements.openComposer.focus();
  }
}

function setDraftLoading(loading) {
  elements.generateDraft.disabled = loading;
  elements.generateLabel.hidden = loading;
  elements.generateLoading.hidden = !loading;
}

function cleanGuidanceText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function splitGuidancePhrases(value, limit = 8) {
  return [...new Set(String(value || "")
    .split(/[\r\n,;|]+/)
    .map((part) => cleanGuidanceText(part).replace(/^[-*\u2022]\s*/, ""))
    .filter(Boolean))]
    .slice(0, limit);
}

function guidanceTokens(request) {
  const source = normalize([request.itemName, request.keywords, request.facts, request.audience].join(" "));
  const tokens = source.match(/[a-z0-9]+/g) || [];
  return [...new Set(tokens.filter((token) => (token.length > 1 || /^\d$/.test(token)) && !GUIDANCE_STOP_WORDS.has(token)))];
}

function scoreGuidanceReference(item, request, tokens, phrases) {
  const fields = {
    name: normalize(item.name),
    short: normalize(item.shortText),
    long: normalize(item.longText),
    taxonomy: normalize([item.magName, item.agName, item.businessCategory, item.itemType].join(" ")),
  };
  let score = 0;
  tokens.forEach((token) => {
    if (fields.name.includes(token)) score += 28;
    if (fields.short.includes(token)) score += 19;
    if (fields.long.includes(token)) score += 8;
    if (fields.taxonomy.includes(token)) score += 6;
  });
  phrases.forEach((phrase) => {
    const normalizedPhrase = normalize(phrase);
    if (normalizedPhrase.length < 3) return;
    if (fields.name.includes(normalizedPhrase)) score += 70;
    if (fields.short.includes(normalizedPhrase)) score += 45;
    if (fields.long.includes(normalizedPhrase)) score += 25;
  });
  if (item.shortText && item.longText) score += 3;
  if (/^details\s+configured offering\s*$/i.test(cleanGuidanceText(item.longText))) score -= 8;
  return score;
}

function findGuidanceReferences(request) {
  const tokens = guidanceTokens(request);
  const phrases = [request.itemName, ...splitGuidancePhrases(request.keywords)].filter(Boolean);
  const seen = new Set();
  return state.items
    .map((item) => ({ item, score: scoreGuidanceReference(item, request, tokens, phrases) }))
    .filter(({ item, score }) => score > 0 && (item.shortText || item.longText))
    .sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name))
    .filter(({ item }) => {
      const signature = normalize(`${item.shortText}|${item.longText}`);
      if (seen.has(signature)) return false;
      seen.add(signature);
      return true;
    })
    .slice(0, 5)
    .map(({ item }) => ({
      id: item.id,
      name: item.name,
      shortText: item.shortText,
      longText: item.longText,
    }));
}

function joinNaturally(values) {
  if (values.length < 2) return values[0] || "";
  if (values.length === 2) return `${values[0]} and ${values[1]}`;
  return `${values.slice(0, -1).join(", ")}, and ${values.at(-1)}`;
}

function ensureSentence(value) {
  const text = cleanGuidanceText(value);
  if (!text) return "";
  return /[.!?]$/.test(text) ? text : `${text}.`;
}

function limitShortText(value, maxLength = 50) {
  const text = cleanGuidanceText(value);
  if (text.length <= maxLength) return text;
  const candidate = text.slice(0, maxLength + 1);
  const lastSpace = candidate.lastIndexOf(" ");
  return (lastSpace > 20 ? candidate.slice(0, lastSpace) : text.slice(0, maxLength)).replace(/[\s,;:\-]+$/, "");
}

function referenceUsesHeading(references, heading) {
  const pattern = new RegExp(`(^|\\n)\\s*${heading}\\s*(\\n|$)`, "i");
  return references.filter((reference) => pattern.test(reference.longText || "")).length >= Math.min(2, references.length);
}

function buildLocalDraft(request) {
  const keywordPhrases = splitGuidancePhrases(request.keywords, 6);
  const facts = splitGuidancePhrases(request.facts, 10);
  const itemName = cleanGuidanceText(request.itemName);
  const audience = cleanGuidanceText(request.audience);
  const name = itemName || keywordPhrases[0] || "New item";
  const references = findGuidanceReferences(request);
  const warnings = ["This local guided draft uses fixed templates and does not validate product claims."];

  const firstDescriptor = keywordPhrases.find((phrase) => !normalize(name).includes(normalize(phrase)));
  const expandedShort = itemName && firstDescriptor ? `${itemName} - ${firstDescriptor}` : name;
  const shortText = limitShortText(expandedShort);
  if (cleanGuidanceText(expandedShort).length > shortText.length) {
    warnings.push("The short draft was shortened to fit a 50-character guideline.");
  }
  if (!itemName) warnings.push("No item name was supplied; replace the working name before approval.");
  if (!facts.length) warnings.push("No approved product facts were supplied; add verified facts before approval.");
  if (!references.length) warnings.push("No close catalogue match was found; the draft uses the local template only.");

  const topics = keywordPhrases
    .filter((phrase) => normalize(phrase) !== normalize(name))
    .slice(0, request.length === "concise" ? 2 : 4);
  const topicText = joinNaturally(topics.length ? topics : keywordPhrases.slice(0, 1));
  const audienceSuffix = audience ? ` for ${audience}` : "";
  let lead;
  if (request.tone === "clinical") lead = `${name} is designed around ${topicText}${audienceSuffix}.`;
  else if (request.tone === "benefit-led") lead = `${name} brings together ${topicText}${audienceSuffix}.`;
  else if (request.tone === "concise") lead = `${name}: ${topicText}${audienceSuffix}.`;
  else lead = `${name} is focused on ${topicText}${audienceSuffix}.`;

  const sections = [];
  const includeIntroduction = request.length !== "concise" && referenceUsesHeading(references, "Introduction");
  const includeBenefits = request.length === "detailed" && referenceUsesHeading(references, "Key Benefits");
  if (includeIntroduction) sections.push(["Introduction", name]);
  if (includeBenefits && keywordPhrases.length) {
    sections.push(["Key Benefits", keywordPhrases.map((phrase) => `- ${phrase}`).join("\n")]);
  }

  let details = lead;
  if (facts.length) {
    const factLimit = request.length === "concise" ? 2 : facts.length;
    const selectedFacts = facts.slice(0, factLimit);
    details += request.length === "detailed"
      ? `\n\nApproved product facts\n\n${selectedFacts.map((fact) => `- ${fact}`).join("\n")}`
      : `\n\n${selectedFacts.map(ensureSentence).join(" ")}`;
  }
  sections.push(["Details", details]);

  return {
    model: `Local guide | ${references.length} catalogue match${references.length === 1 ? "" : "es"}`,
    references,
    drafts: {
      shortText,
      longText: sections.map(([heading, body]) => `${heading}\n\n${body}`).join("\n\n"),
      factWarnings: warnings,
    },
  };
}

function showDraftError(message) {
  elements.draftError.querySelector("p").textContent = message;
  elements.draftError.hidden = false;
}

function renderDraftReferences(references) {
  const fragment = document.createDocumentFragment();
  if (!references.length) {
    const chip = document.createElement("span");
    chip.className = "reference-chip";
    chip.textContent = "No close catalogue match found";
    fragment.append(chip);
  } else {
    references.forEach((reference) => {
      const chip = document.createElement("span");
      chip.className = "reference-chip";
      const id = document.createElement("b");
      id.textContent = reference.id;
      chip.append(id, document.createTextNode(reference.name));
      fragment.append(chip);
    });
  }
  elements.draftReferences.replaceChildren(fragment);
}

function renderFactWarnings(warnings) {
  elements.factWarnings.hidden = warnings.length === 0;
  if (!warnings.length) {
    elements.factWarnings.replaceChildren();
    return;
  }
  const title = document.createElement("strong");
  title.textContent = "Check before approval";
  const list = document.createElement("ul");
  warnings.forEach((warning) => {
    const item = document.createElement("li");
    item.textContent = warning;
    list.append(item);
  });
  elements.factWarnings.replaceChildren(title, list);
}

function renderActiveDraft() {
  if (!state.drafts) return;
  const isShort = state.activeDraft === "short";
  const text = isShort ? state.drafts.shortText : state.drafts.longText;
  elements.draftShortTab.setAttribute("aria-selected", String(isShort));
  elements.draftLongTab.setAttribute("aria-selected", String(!isShort));
  elements.draftEditor.value = text;
  elements.draftCount.textContent = `${formatNumber.format(text.length)} characters`;
}

function renderDraftResult(payload) {
  state.drafts = payload.drafts;
  state.activeDraft = "short";
  elements.draftModel.textContent = payload.model || "Local guided draft";
  elements.draftEmpty.hidden = true;
  elements.draftError.hidden = true;
  elements.draftResult.hidden = false;
  renderDraftReferences(payload.references || []);
  renderFactWarnings(payload.drafts.factWarnings || []);
  renderActiveDraft();
}

function handleDraftGeneration(event) {
  event.preventDefault();
  elements.draftError.hidden = true;

  const request = {
    itemName: elements.draftItemName.value,
    keywords: elements.draftKeywords.value,
    facts: elements.draftFacts.value,
    audience: elements.draftAudience.value,
    tone: elements.draftTone.value,
    length: elements.draftLength.value,
  };
  if (!request.keywords.trim()) {
    elements.draftKeywords.focus();
    showDraftError("Add at least one keyword or key phrase.");
    return;
  }

  try {
    setDraftLoading(true);
    renderDraftResult(buildLocalDraft(request));
  } catch (error) {
    showDraftError(error.message || "The draft could not be generated.");
  } finally {
    setDraftLoading(false);
  }
}

async function handleCopyDraft() {
  const text = elements.draftEditor.value.trim();
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    elements.draftEditor.select();
    document.execCommand("copy");
  }
  showToast(`${state.activeDraft === "short" ? "Short" : "Long"} draft copied`);
}

function bindEvents() {
  elements.search.addEventListener("input", (event) => {
    state.query = event.target.value;
    elements.clearSearch.hidden = !state.query;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => applySearch(), 70);
  });
  elements.clearSearch.addEventListener("click", () => {
    state.query = "";
    elements.search.value = "";
    applySearch();
    elements.search.focus();
  });
  elements.typeFilter.addEventListener("change", (event) => {
    state.type = event.target.value;
    applySearch();
  });
  elements.availabilityFilter.addEventListener("change", (event) => {
    state.availability = event.target.value;
    applySearch();
  });
  elements.resetFilters.addEventListener("click", clearAllFilters);
  elements.loadMore.addEventListener("click", () => {
    state.visible += 50;
    renderResults();
  });
  elements.shortTab.addEventListener("click", () => {
    state.activeText = "short";
    renderActiveText();
  });
  elements.longTab.addEventListener("click", () => {
    state.activeText = "long";
    renderActiveText();
  });
  elements.copyCurrent.addEventListener("click", copyActiveText);
  elements.copyCurrentTop.addEventListener("click", copyActiveText);
  elements.openComposer.addEventListener("click", () => setComposerOpen(true));
  elements.closeComposer.addEventListener("click", () => setComposerOpen(false));
  elements.composerBackdrop.addEventListener("click", () => setComposerOpen(false));
  elements.composerForm.addEventListener("submit", handleDraftGeneration);
  elements.draftShortTab.addEventListener("click", () => {
    state.activeDraft = "short";
    renderActiveDraft();
  });
  elements.draftLongTab.addEventListener("click", () => {
    state.activeDraft = "long";
    renderActiveDraft();
  });
  elements.draftEditor.addEventListener("input", () => {
    if (!state.drafts) return;
    const key = state.activeDraft === "short" ? "shortText" : "longText";
    state.drafts[key] = elements.draftEditor.value;
    elements.draftCount.textContent = `${formatNumber.format(elements.draftEditor.value.length)} characters`;
  });
  elements.copyDraft.addEventListener("click", handleCopyDraft);
  document.addEventListener("keydown", (event) => {
    const isTyping = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName);
    if (event.key === "/" && !isTyping) {
      event.preventDefault();
      elements.search.focus();
    }
    if (event.key === "Escape") {
      if (!elements.composerPanel.hidden) {
        setComposerOpen(false);
        return;
      }
      if (state.query) {
        state.query = "";
        elements.search.value = "";
        applySearch();
      }
      elements.search.blur();
    }
  });
}

async function initialise() {
  bindEvents();
  try {
    let payload = window.SALES_DATA;
    if (!payload) {
      const response = await fetch("public/data/items.json");
      if (!response.ok) throw new Error(`Data request failed with ${response.status}`);
      payload = await response.json();
    }
    state.items = payload.items.map((item) => ({ ...item, _search: makeSearchIndex(item) }));
    elements.sourceLabel.textContent = `${formatNumber.format(payload.metadata.itemCount)} catalogue items`;

    [...new Set(state.items.map((item) => item.itemType).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b))
      .forEach((type) => {
        const option = document.createElement("option");
        option.value = type;
        option.textContent = type.replaceAll("_", " ");
        elements.typeFilter.append(option);
      });

    applySearch();
    const initialId = new URLSearchParams(location.hash.replace(/^#/, "")).get("id");
    const initialItem = initialId && state.items.find((item) => item.id === initialId);
    if (initialItem) selectItem(initialItem, { updateHash: false });
    else showEmptyDetail();
  } catch (error) {
    console.error(error);
    elements.loadingState.querySelector("h1").textContent = "The sales library could not be loaded";
    elements.loadingState.querySelector("p").textContent = "Refresh the page. If the issue continues, restart the app with “npm start”.";
    elements.sourceLabel.textContent = "Catalogue unavailable";
  }
}

initialise();
