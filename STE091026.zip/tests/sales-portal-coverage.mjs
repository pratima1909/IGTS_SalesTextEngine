import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const context = vm.createContext({ window: {} });
vm.runInContext(fs.readFileSync("public/data/sales-portal-source.js", "utf8"), context);
const source = context.window.IGT_SALES_PORTAL_SOURCE;

assert.ok(source?.metadata);
assert.equal(source.metadata.observedDocumentCount, source.documents.length);
assert.equal(source.metadata.factCount, source.facts.length);
assert.equal(source.metadata.contentIndexedDocumentCount, source.documents.filter((document) => document.contentStatus === "indexed").length);
assert.equal(source.metadata.unreadableDocumentCount, source.documents.filter((document) => document.contentStatus === "unreadable").length);
assert.equal(source.metadata.factBackedDocumentCount, source.documents.filter((document) => document.factCount > 0).length);
assert.equal(new Set(source.documents.map((document) => document.id)).size, source.documents.length);
assert.equal(new Set(source.documents.map((document) => document.url)).size, source.documents.length);
assert.ok(source.documents.every((document) => document.url.includes("IGTSystemsSalesPortal2.0")));

const documentIds = new Set(source.documents.map((document) => document.id));
assert.ok(source.facts.every((fact) => documentIds.has(fact.sourceId)));
assert.ok(source.facts.every((fact) => fact.product && fact.topic && fact.text));
assert.ok(source.facts.every((fact) => !/\b(?:optional|option|best|superior|unique|guarantee|competitor)\b/i.test(fact.text)));

console.log("Sales Portal coverage test passed.");
