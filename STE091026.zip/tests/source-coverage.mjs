import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

function loadWindowData(path, property) {
  const context = vm.createContext({ window: {} });
  vm.runInContext(fs.readFileSync(path, "utf8"), context);
  return context.window[property];
}

const dhf = loadWindowData("public/data/azurion-technical-facts.js", "AZURION_TECHNICAL_DATA");
const manifest = loadWindowData("public/data/sharepoint-source-manifest.js", "SHAREPOINT_SOURCE_MANIFEST");
const sharePoint = loadWindowData("public/data/sharepoint-product-facts.js", "SHAREPOINT_PRODUCT_FACTS");
const salesPortal = loadWindowData("public/data/sales-portal-source.js", "IGT_SALES_PORTAL_SOURCE");

assert.equal(dhf.metadata.workbookSheetCount, 21);
assert.equal(dhf.metadata.sheetCoverage.length, 21);
assert.equal(dhf.metadata.indexedSheetCount, 19);
assert.equal(dhf.metadata.administrativeSheetCount, 2);
assert.equal(dhf.metadata.technicalFactCount, dhf.facts.length);
assert.equal(dhf.metadata.supplementalFactCount, dhf.supplementalFacts.length);
assert.equal(dhf.metadata.extractedFactCount, dhf.facts.length + dhf.supplementalFacts.length);
assert.equal(
  dhf.metadata.populatedCellCount,
  dhf.metadata.sheetCoverage.reduce((sum, sheet) => sum + sheet.populatedCells, 0),
);
assert.equal(
  Array.from(dhf.metadata.sheetCoverage)
    .filter((sheet) => sheet.status === "Administrative")
    .map((sheet) => sheet.name)
    .sort()
    .join("|"),
  "Frontpage|Revision History",
);
assert.ok(dhf.metadata.sheetCoverage.filter((sheet) => /clarity/i.test(sheet.name)).every((sheet) => sheet.status === "Indexed"));

assert.equal(manifest.metadata.listedFileCount, 200);
assert.equal(manifest.metadata.observedDocumentCount, manifest.documents.length);
assert.ok(manifest.metadata.observedDocumentCount >= 476);
assert.ok(manifest.metadata.searchDiscoveredFileCount >= 276);
assert.equal(manifest.metadata.continuationAvailable, true);
assert.equal(new Set(manifest.documents.map((document) => document.id)).size, manifest.documents.length);
assert.equal(new Set(manifest.documents.map((document) => document.stableIdentity)).size, manifest.documents.length);

assert.equal(sharePoint.metadata.documentCount, sharePoint.documents.length);
assert.equal(sharePoint.metadata.factCount, sharePoint.facts.length);
assert.equal(new Set(sharePoint.documents.map((document) => document.id)).size, sharePoint.documents.length);
const documentIds = new Set(sharePoint.documents.map((document) => document.id));
assert.ok(sharePoint.facts.every((fact) => documentIds.has(fact.sourceId)));
// Counts may decrease when an old passage fails the current evidence gate.
for (const [register, source] of [[manifest, sharePoint], [salesPortal, salesPortal]]) {
  assert.equal(register.metadata.enumerationComplete, false);
  assert.equal(register.metadata.authoritativeLibraryTotal, null);
  assert.equal(register.metadata.contentExtractionAttemptedDocumentCount, register.documents.length);
  assert.equal(register.metadata.contentIndexedDocumentCount, register.documents.filter(d=>d.contentStatus==='indexed').length);
  assert.equal(register.metadata.extractionFailedDocumentCount, register.documents.filter(d=>d.contentStatus==='failed').length);
  assert.equal(register.metadata.unreadableDocumentCount, register.documents.filter(d=>d.contentStatus==='unreadable').length);
  assert.ok(register.documents.every(d=>d.stableIdentity && d.extractionAttemptedAt && d.fetchUrl));
  assert.equal(new Set(register.documents.map(d=>d.stableIdentity)).size, register.documents.length);
  const byId = new Map(register.documents.map(d=>[d.id,d]));
  for (const fact of source.facts) {
    const document = byId.get(fact.sourceId);
    assert.equal(document?.contentStatus, 'indexed');
    assert.equal(document?.selectionStatus, 'selected');
    assert.equal(fact.evidence?.sourceIdentity, document.stableIdentity);
    assert.equal(fact.evidence?.sourceUrl, document.url);
    assert.match(fact.evidence?.contentSha256 || '', /^[a-f0-9]{64}$/);
    assert.ok(fact.evidence?.quote.length > 20);
    assert.ok(Number.isInteger(fact.evidence?.normalizedStart));
    assert.equal(fact.evidence?.reviewStatus, 'screened');
    assert.doesNotMatch(fact.text, /\b(?:optional|option|options|best|superior|unique|guarantee|competitor)\b/i);
  }
  for (const document of register.documents) {
    assert.equal(document.factCount, source.facts.filter(f=>f.sourceId===document.id).length);
    if (document.factCount===0) assert.ok(document.exclusionReason);
  }
}
// These known pitfalls must remain register-only when observed in a refresh.
for (const [register, names] of [[manifest, [
  '191028_SmartCT NPI Leave Behind_A5_LS_03.pdf',
  '452299183751_Philips_SmartCT_brochure_HR_NC.pdf',
  'MAT4612_Azurion_with_SmartIQ_product_overview.pdf',
]], [salesPortal, [
  '452299175781_Philips_SHD_Suite_tools_brochure_HR.pdf',
  'Azurion_Mentice integration, Product Overview.pdf',
  'BV_Vectra_Specifications_January_2022_Updated.pdf',
]]]) {
  for (const name of names) {
    for (const document of register.documents.filter(d=>d.title===name)) {
      assert.equal(document.factCount, 0, `${name} must not supply claims`);
    }
  }
}
assert.ok(!sharePoint.facts.some(f=>f.product==='Touch Screen Module Pro'), 'Optional module passages are excluded');

assert.equal(salesPortal.metadata.observedDocumentCount, salesPortal.documents.length);
assert.equal(salesPortal.metadata.factCount, salesPortal.facts.length);
assert.equal(salesPortal.metadata.enumerationComplete, false);
assert.equal(new Set(salesPortal.documents.map((document) => document.id)).size, salesPortal.documents.length);
assert.equal(new Set(salesPortal.documents.map((document) => document.url)).size, salesPortal.documents.length);
const salesPortalDocumentIds = new Set(salesPortal.documents.map((document) => document.id));
assert.ok(salesPortal.facts.every((fact) => salesPortalDocumentIds.has(fact.sourceId)));
assert.equal(
  salesPortal.metadata.contentIndexedDocumentCount,
  salesPortal.documents.filter((document) => document.contentStatus === "indexed").length,
);

const html = fs.readFileSync("index.html", "utf8");
for (const id of ["openCoverage", "coveragePanel", "dhfCoverageKpis", "spCoverageKpis", "portalCoverageKpis", "coverageSheetList", "coverageDocumentList", "portalDocumentList"]) {
  assert.match(html, new RegExp(`id=["']${id}["']`));
}
for (const id of ["draftAudience", "draftFeedback", "draftFeedbackStatus", "generateActionText"]) {
  assert.match(html, new RegExp(`id=["']${id}["']`));
}
assert.ok(html.indexOf('id="draftAudience"') < html.indexOf('id="draftFeedback"'));
assert.match(html, /sharepoint-source-manifest\.js/);
assert.match(html, /sales-portal-source\.js/);

console.log("Source coverage test passed.");
