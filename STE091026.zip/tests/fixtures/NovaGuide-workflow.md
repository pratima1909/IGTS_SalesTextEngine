# NovaGuide workflow

NovaGuide integrates imaging information in the interventional workflow to support confident navigation.
NovaGuide presents relevant guidance information in one view to help clinical teams maintain focus during procedures.
