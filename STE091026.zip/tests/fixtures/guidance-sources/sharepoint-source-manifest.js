// Generated from the authorized SharePoint folder listing, direct verification, and site-scoped search.
window.SHAREPOINT_SOURCE_MANIFEST = {
  "metadata": {
    "sourceName": "IGT-S Strategy Execution & Transformation SharePoint",
    "folderName": "Data Analytics/SSA_PAL_Filterted",
    "snapshotDate": "2026-09-28",
    "listedFileCount": 200,
    "searchDiscoveredFileCount": 276,
    "observedDocumentCount": 476,
    "continuationAvailable": true,
    "contentIndexedDocumentCount": 65,
    "coverageNote": "The refresh combines the connector's 200-file folder page, previously verified files, and site-scoped wildcard and file-type searches. A continuation marker remains, so 476 unique observed documents is a verified lower bound rather than a claim of complete folder enumeration."
  },
  "documents": [
    {
      "id": "sp-manifest-1",
      "title": "121126_Customer_Testimonial_ERCP_AMC_worldwide_LR.pdf",
      "updatedAt": "2013-07-31T08:19:37Z",
      "sizeBytes": 158760,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/121126_Customer_Testimonial_ERCP_AMC_worldwide_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-2",
      "title": "131120_Neurosuite_Brochure_LR_spread.pdf",
      "updatedAt": "2026-06-26T04:42:20Z",
      "sizeBytes": 1882828,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/131120_Neurosuite_Brochure_LR_spread.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-3",
      "title": "142517_BROCHURE_Healthcare_Educational_Behind_LR.pdf",
      "updatedAt": "2020-04-08T09:49:25Z",
      "sizeBytes": 910758,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/142517_BROCHURE_Healthcare_Educational_Behind_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-4",
      "title": "191028_SmartCT NPI Leave Behind_A5_LS_03.pdf",
      "updatedAt": "2026-06-26T04:42:22Z",
      "sizeBytes": 1402994,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/191028_SmartCT%20NPI%20Leave%20Behind_A5_LS_03.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-5",
      "title": "200214_Evolution messaging guide_A4_09_Final.pdf",
      "updatedAt": "2026-06-26T04:42:23Z",
      "sizeBytes": 1965742,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/200214_Evolution%20messaging%20guide_A4_09_Final.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-6",
      "title": "201204_Azurion Hilrom ORT_MA_HR.pdf",
      "updatedAt": "2021-03-30T07:47:34Z",
      "sizeBytes": 1556178,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/201204_Azurion Hilrom ORT_MA_HR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-7",
      "title": "201204_Azurion Hilrom ORT_MA_LR.pdf",
      "updatedAt": "2021-03-30T11:38:52Z",
      "sizeBytes": 793234,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/201204_Azurion Hilrom ORT_MA_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-8",
      "title": "201204_Azurion Hilrom Specs_MA_HR.pdf",
      "updatedAt": "2021-03-30T08:46:17Z",
      "sizeBytes": 1214634,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/201204_Azurion Hilrom Specs_MA_HR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-9",
      "title": "201204_Azurion Hilrom Specs_MA_LR.pdf",
      "updatedAt": "2026-06-26T04:42:24Z",
      "sizeBytes": 727765,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/201204_Azurion%20Hilrom%20Specs_MA_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-10",
      "title": "2022 Cardiology Toolkit_03_10_2022_1.pptx",
      "updatedAt": "2026-06-26T08:55:37Z",
      "sizeBytes": 149499554,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/_layouts/15/Doc.aspx?sourcedoc=%7B254E9325-ECF3-4D59-9A05-36FD32A2473E%7D&file=2022%20Cardiology%20Toolkit_03_10_2022_1.pptx&action=edit&mobileredirect=true",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-11",
      "title": "2024_Hennessey_Dynamic Coronary Roadmap versus standard angiography for percutaneous coronary intervention-the randomised, multi.pdf",
      "updatedAt": "2026-06-26T04:58:40Z",
      "sizeBytes": 1436315,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/2024_Hennessey_Dynamic%20Coronary%20Roadmap%20versus%20standard%20angiography%20for%20percutaneous%20coronary%20intervention-the%20randomised,%20multi.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-12",
      "title": "2024_ICO_S_CPPT_1.pptx",
      "updatedAt": "2026-06-26T08:59:39Z",
      "sizeBytes": 686262780,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/_layouts/15/Doc.aspx?sourcedoc=%7B141508DB-36D2-4912-9C5D-9D79B9A1E9B6%7D&file=2024_ICO_S_CPPT_1.pptx&action=edit&mobileredirect=true",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-13",
      "title": "210714_Azurion FlexArm Opragon leaflet MA_03 HR.pdf",
      "updatedAt": "2021-10-14T12:30:34Z",
      "sizeBytes": 3979048,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/210714_Azurion FlexArm Opragon leaflet MA_03 HR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-14",
      "title": "210714_Azurion FlexArm Opragon leaflet MA_03 LR.pdf",
      "updatedAt": "2021-10-14T12:30:37Z",
      "sizeBytes": 1323243,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/210714_Azurion FlexArm Opragon leaflet MA_03 LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-15",
      "title": "210801_EchoNavigator release 4 customer PPT_content_v9.0_Final_disclaimer non-USA_1.pptx",
      "updatedAt": "2022-03-28T10:17:27Z",
      "sizeBytes": 19436278,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/210801_EchoNavigator release 4 customer PPT_content_v9.0_Final_disclaimer non-USA_1.pptx?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-16",
      "title": "210801_EchoNavigator release 4 customer PPT_content_v9.0_Final_USA_1.pptx",
      "updatedAt": "2022-06-21T11:57:07Z",
      "sizeBytes": 19435213,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/210801_EchoNavigator release 4 customer PPT_content_v9.0_Final_USA_1.pptx?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-17",
      "title": "211132_Dosewise_Azurion_cppt_02_v01Dec_ROW Version_1.pptx",
      "updatedAt": "2026-06-26T09:02:55Z",
      "sizeBytes": 381042735,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/_layouts/15/Doc.aspx?sourcedoc=%7B2827A4AE-914E-4497-B235-BB83C998CADC%7D&file=211132_Dosewise_Azurion_cppt_02_v01Dec_ROW%20Version_1.pptx&action=edit&mobileredirect=true",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-18",
      "title": "2200270_Philips_Neurosurgery_with_Azurion_presentation_V4_1.pptx",
      "updatedAt": "2026-06-26T09:03:09Z",
      "sizeBytes": 551708965,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/_layouts/15/Doc.aspx?sourcedoc=%7B30A6960D-173A-4BBF-9F54-560953064ACA%7D&file=2200270_Philips_Neurosurgery_with_Azurion_presentation_V4_1.pptx&action=edit&mobileredirect=true",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-19",
      "title": "2210526_Philips_Mie_University_customer_story_V6_FINAL.pdf",
      "updatedAt": "2026-06-26T04:42:26Z",
      "sizeBytes": 640053,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/2210526_Philips_Mie_University_customer_story_V6_FINAL.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-20",
      "title": "2220578_Azurion_SpineSuite_customer_presentation_V3_FINAL_1.pptx",
      "updatedAt": "2026-06-26T08:28:14Z",
      "sizeBytes": 729905302,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/_layouts/15/Doc.aspx?sourcedoc=%7BBA2FFA3E-B925-4FC8-9702-347471D115AF%7D&file=2220578_Azurion_SpineSuite_customer_presentation_V3_FINAL_1.pptx&action=edit&mobileredirect=true",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-21",
      "title": "2250255_Philips_IGT_advert_US_150x210_HR_600dpi_final.pdf",
      "updatedAt": "2026-06-26T04:43:21Z",
      "sizeBytes": 294040,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/2250255_Philips_IGT_advert_US_150x210_HR_600dpi_final.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-22",
      "title": "2250396_Philips_FAQ_Azurion R3.1_New FlexVision monitors_HR_NC_PAL.pdf",
      "updatedAt": "2026-06-26T04:43:21Z",
      "sizeBytes": 217511,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/2250396_Philips_FAQ_Azurion%20R3.1_New%20FlexVision%20monitors_HR_NC_PAL.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-23",
      "title": "240501_03 Azurion Tech Max Program Leaflet_NA_L&R approved.pdf",
      "updatedAt": "2024-06-24T08:37:06Z",
      "sizeBytes": 805819,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/240501_03 Azurion Tech Max Program Leaflet_NA_L&R approved.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-24",
      "title": "2D Perfusion 2013 03.pdf",
      "updatedAt": "2026-06-26T04:58:23Z",
      "sizeBytes": 246872,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/2D%20Perfusion%202013%2003.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-25",
      "title": "3000 091 42383 LumiGuide Docking Top Multilanguage.pdf",
      "updatedAt": "2026-06-26T04:58:52Z",
      "sizeBytes": 19471433,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/3000%20091%2042383%20LumiGuide%20Docking%20Top%20Multilanguage.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-26",
      "title": "3000 122 55291 LumiGuide Equipment R2 2023-07.pdf",
      "updatedAt": "2026-06-26T04:58:51Z",
      "sizeBytes": 11512866,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/3000%20122%2055291%20LumiGuide%20Equipment%20R2%202023-07.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-27",
      "title": "3000 138 00061 LumiGuide Equipment R2 ADD 2024-05-09.pdf",
      "updatedAt": "2024-05-09T03:51:53Z",
      "sizeBytes": 913668,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/3000 138 00061 LumiGuide Equipment R2 ADD 2024-05-09.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-28",
      "title": "3000 147 55251 LumiGuide 3D Hub Multilanguage.pdf",
      "updatedAt": "2026-06-26T04:40:54Z",
      "sizeBytes": 19438072,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/3000%20147%2055251%20LumiGuide%203D%20Hub%20Multilanguage.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-29",
      "title": "3000 147 65351_LumiGuide Equipment_en_US.pdf",
      "updatedAt": "2026-06-26T04:40:52Z",
      "sizeBytes": 11574434,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/3000%20147%2065351_LumiGuide%20Equipment_en_US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-30",
      "title": "300002104364 A CHT OM IntraSightSystem.pdf",
      "updatedAt": "2026-06-26T04:43:21Z",
      "sizeBytes": 7901373,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300002104364%20A%20CHT%20OM%20IntraSightSystem.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-31",
      "title": "300002104364 A ENG OM IntraSightSystem.pdf",
      "updatedAt": "2026-06-26T04:43:27Z",
      "sizeBytes": 7506611,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300002104364%20A%20ENG%20OM%20IntraSightSystem.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-32",
      "title": "300002418163 A OM FM-PIM (en-us).pdf",
      "updatedAt": "2026-06-26T04:43:26Z",
      "sizeBytes": 1637254,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300002418163%20A%20OM%20FM-PIM%20(en-us).pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-33",
      "title": "300002564353 A OM Rotational IVUS (en-us).pdf",
      "updatedAt": "2026-06-26T04:43:25Z",
      "sizeBytes": 1386673,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300002564353%20A%20OM%20Rotational%20IVUS%20(en-us).pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-34",
      "title": "300003106971_H_User Manual, Verisight Pro Catheters.pdf",
      "updatedAt": "2026-06-26T04:44:06Z",
      "sizeBytes": 870092,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300003106971_H_User%20Manual,%20Verisight%20Pro%20Catheters.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-35",
      "title": "300003736824 A OM SyncVision v4.2.x-Eng.pdf",
      "updatedAt": "2026-06-26T04:44:07Z",
      "sizeBytes": 7169313,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300003736824%20A%20OM%20SyncVision%20v4.2.x-Eng.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-36",
      "title": "300004969172 A OM CORE 3.5 Mobile (Eng).pdf",
      "updatedAt": "2026-06-26T04:44:08Z",
      "sizeBytes": 5934960,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300004969172%20A%20OM%20CORE%203.5%20Mobile%20(Eng).pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-37",
      "title": "300007015131 A OM Revolution (Eng).pdf",
      "updatedAt": "2026-06-26T04:44:07Z",
      "sizeBytes": 1081236,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300007015131%20A%20OM%20Revolution%20(Eng).pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-38",
      "title": "300010660481_A, Operator's Manual, SyncVision v4.2_en-US.pdf",
      "updatedAt": "2026-06-26T04:44:10Z",
      "sizeBytes": 7034616,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/300010660481_A,%20Operator%27s%20Manual,%20SyncVision%20v4.2_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-39",
      "title": "3D-Ra 2013 05.pdf",
      "updatedAt": "2026-06-26T04:58:28Z",
      "sizeBytes": 450952,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/3D-Ra%202013%2005.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-40",
      "title": "4322 070 33731 2021-06 AltaTrack 3D Hub.pdf",
      "updatedAt": "2026-06-26T04:40:50Z",
      "sizeBytes": 4005102,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2033731%202021-06%20AltaTrack%203D%20Hub.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-41",
      "title": "4322 070 33942_AltaTrack_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:54Z",
      "sizeBytes": 9542545,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2033942_AltaTrack_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-42",
      "title": "4322 070 36041_LumiGuide Equipment _en-US.pdf",
      "updatedAt": "2026-06-26T04:40:55Z",
      "sizeBytes": 11515586,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2036041_LumiGuide%20Equipment%20_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-43",
      "title": "4322 070 38863 2023-06 LumiGuide Navigation Wire EN-US.pdf",
      "updatedAt": "2026-06-26T04:40:56Z",
      "sizeBytes": 1343827,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2038863%202023-06%20LumiGuide%20Navigation%20Wire%20EN-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-44",
      "title": "4322 070 38973 LumiGuide Navigation Wire Multilanguage.pdf",
      "updatedAt": "2026-06-26T04:40:59Z",
      "sizeBytes": 24043404,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2038973%20LumiGuide%20Navigation%20Wire%20Multilanguage.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-45",
      "title": "4522 203 58523_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:57Z",
      "sizeBytes": 1667186,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2058523_Philips%20Hemodynamic%20Application_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-46",
      "title": "4522 203 66871_SmartCT_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:58Z",
      "sizeBytes": 11348111,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2066871_SmartCT_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-47",
      "title": "4522 203 75734 DoseAware_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:57Z",
      "sizeBytes": 2361255,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2075734%20DoseAware_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-48",
      "title": "4522 203 78552_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:01Z",
      "sizeBytes": 12237564,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078552_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-49",
      "title": "4522 203 78553_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:03Z",
      "sizeBytes": 12337477,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078553_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-50",
      "title": "4522 203 78554_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:04Z",
      "sizeBytes": 12342030,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078554_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-51",
      "title": "4522 203 78555_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:05Z",
      "sizeBytes": 12713689,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078555_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-52",
      "title": "4522 203 78556_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:07Z",
      "sizeBytes": 12714526,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078556_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-53",
      "title": "4522 203 78931_ClarifEye_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:06Z",
      "sizeBytes": 4714826,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078931_ClarifEye_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-54",
      "title": "4522 203 78932_ClarifEye_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:06Z",
      "sizeBytes": 4478739,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078932_ClarifEye_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-55",
      "title": "4522 203 78933_ClarifEye_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:09Z",
      "sizeBytes": 4117052,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078933_ClarifEye_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-56",
      "title": "4522 203 79301_Interventional Workspot_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:09Z",
      "sizeBytes": 8885243,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2079301_Interventional%20Workspot_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-57",
      "title": "4522 203 79651_3D-RA_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:08Z",
      "sizeBytes": 5073069,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2079651_3D-RA_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-58",
      "title": "4522 203 80001_3D Roadmap_en-US.pdf",
      "updatedAt": "2020-02-04T11:44:44Z",
      "sizeBytes": 1998559,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4522 203 80001_3D Roadmap_en-US.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-59",
      "title": "4522 203 80351_MR-CT Roadmap_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:11Z",
      "sizeBytes": 3296802,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2080351_MR-CT%20Roadmap_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-60",
      "title": "4522 203 80701_XperCT Dual_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:12Z",
      "sizeBytes": 6815466,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2080701_XperCT%20Dual_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-61",
      "title": "4522 203 81051_XperGuide_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:13Z",
      "sizeBytes": 7776727,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2081051_XperGuide_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-62",
      "title": "4522 203 81401_EmboGuide_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:12Z",
      "sizeBytes": 8543463,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2081401_EmboGuide_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-63",
      "title": "4522 203 81751_StentBoost_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:14Z",
      "sizeBytes": 8002540,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2081751_StentBoost_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-64",
      "title": "4522 203 82451_VesselNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:15Z",
      "sizeBytes": 3516848,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2082451_VesselNavigator_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-65",
      "title": "4522 203 82801_AneurysmFlow_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:15Z",
      "sizeBytes": 3480423,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2082801_AneurysmFlow_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-66",
      "title": "4522 203 83151_EP navigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:17Z",
      "sizeBytes": 6988419,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2083151_EP%20navigator_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-67",
      "title": "4522 203 83501_HeartNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:16Z",
      "sizeBytes": 2555809,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2083501_HeartNavigator_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-68",
      "title": "4522 203 83851_SmartPerfusion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:17Z",
      "sizeBytes": 8400918,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2083851_SmartPerfusion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-69",
      "title": "4522 203 85721_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:17Z",
      "sizeBytes": 2317358,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2085721_Philips%20Hemodynamic%20Application_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-70",
      "title": "4522 203 85722_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:20Z",
      "sizeBytes": 2615155,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2085722_Philips%20Hemodynamic%20Application_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-71",
      "title": "4522 203 85723_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:20Z",
      "sizeBytes": 3153132,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2085723_Philips%20Hemodynamic%20Application_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-72",
      "title": "4522 204 14481-QuickReferenceCard-PatientTable_en-US.pdf",
      "updatedAt": "2024-05-15T07:43:16Z",
      "sizeBytes": 293337,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4522 204 14481-QuickReferenceCard-PatientTable_en-US.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-73",
      "title": "4522 204 14483-QuickReferenceCard-PatientTable_US.pdf",
      "updatedAt": "2025-08-07T07:53:38Z",
      "sizeBytes": 366287,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4522 204 14483-QuickReferenceCard-PatientTable_US.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-74",
      "title": "4522_991_08001_Philips_vesselnavigator_CS.pdf",
      "updatedAt": "2026-06-26T04:41:21Z",
      "sizeBytes": 197253,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522_991_08001_Philips_vesselnavigator_CS.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-75",
      "title": "4522_991_17551_Philips_brochure_Neurosuite_FINAL.pdf",
      "updatedAt": "2026-06-26T04:41:20Z",
      "sizeBytes": 1820205,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522_991_17551_Philips_brochure_Neurosuite_FINAL.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-76",
      "title": "4522_991_20861_Philips_Brochure_DCR_and_Stentboost.pdf",
      "updatedAt": "2026-06-26T04:41:23Z",
      "sizeBytes": 8472302,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522_991_20861_Philips_Brochure_DCR_and_Stentboost.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-77",
      "title": "452296216791_3drm_LR.pdf",
      "updatedAt": "2026-06-26T04:44:10Z",
      "sizeBytes": 101642,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296216791_3drm_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-78",
      "title": "452296219221_xperct_LR.pdf",
      "updatedAt": "2026-06-26T04:44:43Z",
      "sizeBytes": 308492,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296219221_xperct_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-79",
      "title": "452296219901_fd20_LR.pdf",
      "updatedAt": "2026-06-26T04:44:43Z",
      "sizeBytes": 91402,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296219901_fd20_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-80",
      "title": "452296219901_xperguide_LR.pdf",
      "updatedAt": "2026-06-26T04:44:44Z",
      "sizeBytes": 91407,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296219901_xperguide_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-81",
      "title": "452296219921_3drm_LR.pdf",
      "updatedAt": "2026-06-26T04:44:44Z",
      "sizeBytes": 75018,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296219921_3drm_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-82",
      "title": "452296220231_xperct_LR.pdf",
      "updatedAt": "2026-06-26T04:44:44Z",
      "sizeBytes": 66828,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296220231_xperct_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-83",
      "title": "452296222561_fd10_LR.pdf",
      "updatedAt": "2007-06-08T13:51:39Z",
      "sizeBytes": 68874,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452296222561_fd10_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-84",
      "title": "452296225771_xperguide_LR.pdf",
      "updatedAt": "2026-06-26T04:45:24Z",
      "sizeBytes": 107791,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296225771_xperguide_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-85",
      "title": "452296227481_fd10_LR.pdf",
      "updatedAt": "2026-06-26T04:45:24Z",
      "sizeBytes": 171274,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296227481_fd10_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-86",
      "title": "452296228811_stentboost_LR.pdf",
      "updatedAt": "2007-10-15T08:11:38Z",
      "sizeBytes": 143632,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452296228811_stentboost_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-87",
      "title": "452296231451_cttrueview_LR.pdf",
      "updatedAt": "2026-06-26T04:45:25Z",
      "sizeBytes": 212240,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296231451_cttrueview_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-88",
      "title": "452296232771_vasc_surgery_fd20_LR.pdf",
      "updatedAt": "2026-06-26T04:45:25Z",
      "sizeBytes": 105751,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296232771_vasc_surgery_fd20_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-89",
      "title": "452296232851_LR_stentboost.pdf",
      "updatedAt": "2026-06-26T04:45:25Z",
      "sizeBytes": 196038,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296232851_LR_stentboost.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-90",
      "title": "452296258621_LR.pdf",
      "updatedAt": "2026-06-26T07:07:05Z",
      "sizeBytes": 1127499,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296258621_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-91",
      "title": "452296278537_LR_EPnav_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:26Z",
      "sizeBytes": 2056457,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296278537_LR_EPnav_brochure.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-92",
      "title": "452296294041_AlluraClarity-folderUSA_Final_LR.pdf",
      "updatedAt": "2026-06-26T04:46:26Z",
      "sizeBytes": 2004672,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296294041_AlluraClarity-folderUSA_Final_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-93",
      "title": "452296295231_LR2.pdf",
      "updatedAt": "2026-06-26T04:46:26Z",
      "sizeBytes": 980982,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296295231_LR2.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-94",
      "title": "452299101681_Philips_Productoverview_VeradiusUnity.pdf",
      "updatedAt": "2026-06-26T04:46:29Z",
      "sizeBytes": 831509,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299101681_Philips_Productoverview_VeradiusUnity.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-95",
      "title": "452299107951_Philips_Intuis_fixed_base_Brochure_V7.pdf",
      "updatedAt": "2026-06-26T04:46:29Z",
      "sizeBytes": 1053651,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299107951_Philips_Intuis_fixed_base_Brochure_V7.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-96",
      "title": "452299108181_Philips_Allura_Centron_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:28Z",
      "sizeBytes": 803957,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299108181_Philips_Allura_Centron_brochure.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-97",
      "title": "452299110221_Philips_Pulsera_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:31Z",
      "sizeBytes": 750507,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299110221_Philips_Pulsera_brochure.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-98",
      "title": "452299116681_Veradius_Unity_Product_Overview_LR.pdf",
      "updatedAt": "2026-06-26T04:46:31Z",
      "sizeBytes": 293418,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299116681_Veradius_Unity_Product_Overview_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-99",
      "title": "452299122381_Philips_Azurion_3_brochure_FINAL.pdf",
      "updatedAt": "2017-02-17T13:51:12Z",
      "sizeBytes": 633799,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299122381_Philips_Azurion_3_brochure_FINAL.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-100",
      "title": "452299122941_Philips_Azurion_7_brochure_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:33Z",
      "sizeBytes": 643407,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299122941_Philips_Azurion_7_brochure_FINAL.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-101",
      "title": "452299123041_Philips_Azurion_simulation_study_whitepaper_LR.PDF",
      "updatedAt": "2026-06-26T04:46:33Z",
      "sizeBytes": 352969,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299123041_Philips_Azurion_simulation_study_whitepaper_LR.PDF",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-102",
      "title": "452299125151_161103_SmartSuite_specification_3F15_HR.pdf",
      "updatedAt": "2026-06-26T04:46:34Z",
      "sizeBytes": 3338237,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299125151_161103_SmartSuite_specification_3F15_HR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-103",
      "title": "452299125161_161103_SmartSuite_specification_7C12_HR.pdf",
      "updatedAt": "2026-06-26T04:46:35Z",
      "sizeBytes": 3593069,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299125161_161103_SmartSuite_specification_7C12_HR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-104",
      "title": "452299125161_161103_SmartSuite_specification_7C12_LR.pdf",
      "updatedAt": "2026-06-26T04:46:34Z",
      "sizeBytes": 3574896,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299125161_161103_SmartSuite_specification_7C12_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-105",
      "title": "452299125171_161103_SmartSuite_specification_7C20_HR.pdf",
      "updatedAt": "2026-06-26T04:46:38Z",
      "sizeBytes": 22106320,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299125171_161103_SmartSuite_specification_7C20_HR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-106",
      "title": "452299125171_161103_SmartSuite_specification_7C20_LR.pdf",
      "updatedAt": "2026-06-26T04:46:37Z",
      "sizeBytes": 3600807,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299125171_161103_SmartSuite_specification_7C20_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-107",
      "title": "452299126941_Philips_Interventional_Hemodynamic_system_product_overview_v8.pdf",
      "updatedAt": "2026-06-26T04:46:37Z",
      "sizeBytes": 296010,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299126941_Philips_Interventional_Hemodynamic_system_product_overview_v8.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-108",
      "title": "452299128271_Philips_Interventional_Hemodynamic_whitepaper_v2.pdf",
      "updatedAt": "2026-06-26T04:46:39Z",
      "sizeBytes": 432054,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299128271_Philips_Interventional_Hemodynamic_whitepaper_v2.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-109",
      "title": "452299128671_170436_Azurion 7B12-12_HA_MA_LR.pdf",
      "updatedAt": "2026-06-26T04:46:38Z",
      "sizeBytes": 3554468,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299128671_170436_Azurion%207B12-12_HA_MA_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-110",
      "title": "452299128681_170436_Azurion 7B20-15_HA_MA_LR.pdf",
      "updatedAt": "2026-06-26T04:46:40Z",
      "sizeBytes": 3222464,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299128681_170436_Azurion%207B20-15_HA_MA_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-111",
      "title": "452299128691_170436_Azurion 7B20-12_HA_MA_LR.pdf",
      "updatedAt": "2026-06-26T04:46:41Z",
      "sizeBytes": 3237498,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299128691_170436_Azurion%207B20-12_HA_MA_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-112",
      "title": "452299128991_LR_Mobile_Surgery_portfolio_brochure.pdf",
      "updatedAt": "2017-12-21T08:06:56Z",
      "sizeBytes": 2314920,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299128991_LR_Mobile_Surgery_portfolio_brochure.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-113",
      "title": "452299129221_Philips_Hybrid_Suite_Trumpf_product_overview_V3.pdf",
      "updatedAt": "2026-06-26T04:46:41Z",
      "sizeBytes": 172635,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299129221_Philips_Hybrid_Suite_Trumpf_product_overview_V3.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-114",
      "title": "452299130501_Philips_Nieuwegein_Case_study_final_HR_single_page.pdf",
      "updatedAt": "2026-06-26T04:46:43Z",
      "sizeBytes": 4222327,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299130501_Philips_Nieuwegein_Case_study_final_HR_single_page.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-115",
      "title": "452299130891_Philips_BV_Endura_Pain_Management_product_overview.pdf",
      "updatedAt": "2026-06-26T04:46:42Z",
      "sizeBytes": 273369,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299130891_Philips_BV_Endura_Pain_Management_product_overview.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-116",
      "title": "452299130941_170626_iRotate-xPlane_White Paper_MA LR.pdf",
      "updatedAt": "2026-06-26T04:46:44Z",
      "sizeBytes": 1614613,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299130941_170626_iRotate-xPlane_White%20Paper_MA%20LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-117",
      "title": "452299132691_Mobile_Surgery_Solutions_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:43Z",
      "sizeBytes": 2186788,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299132691_Mobile_Surgery_Solutions_brochure.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-118",
      "title": "452299140161_FlexArm_Use-Lab_Whitepaper_F.pdf",
      "updatedAt": "2026-06-26T04:46:43Z",
      "sizeBytes": 1358211,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299140161_FlexArm_Use-Lab_Whitepaper_F.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-119",
      "title": "452299140571_Philips_Zenition_50_Image_Intensifier_specifications.pdf",
      "updatedAt": "2026-06-26T04:46:48Z",
      "sizeBytes": 8763035,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299140571_Philips_Zenition_50_Image_Intensifier_specifications.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-120",
      "title": "452299140591_Philips_Zenition_70_Flat_Detector_specifications.pdf",
      "updatedAt": "2026-06-26T04:46:48Z",
      "sizeBytes": 3972124,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299140591_Philips_Zenition_70_Flat_Detector_specifications.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-121",
      "title": "452299144241 Zenition_Conversation_Starter_A5_October_2022.pdf",
      "updatedAt": "2022-10-13T14:25:33Z",
      "sizeBytes": 4110561,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299144241 Zenition_Conversation_Starter_A5_October_2022.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-122",
      "title": "452299145671_Philips_Technology_Maximizer_Zenition_Mobile_C_Arm_Series.pdf",
      "updatedAt": "2019-04-09T08:29:03Z",
      "sizeBytes": 1019847,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299145671_Philips_Technology_Maximizer_Zenition_Mobile_C_Arm_Series.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-123",
      "title": "452299149011_190328_Hybrid OR Sterility study results_factsheet MA LR.pdf",
      "updatedAt": "2019-09-09T10:13:03Z",
      "sizeBytes": 2019989,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299149011_190328_Hybrid OR Sterility study results_factsheet MA LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-124",
      "title": "452299150041_Philips_Mobile_Carms_SmartPath_trade-up_to_new_innovations_datasheet.pdf",
      "updatedAt": "2026-06-26T04:46:51Z",
      "sizeBytes": 290053,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299150041_Philips_Mobile_Carms_SmartPath_trade-up_to_new_innovations_datasheet.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-125",
      "title": "452299153411_Spine suite results one pager_V2.pdf",
      "updatedAt": "2021-09-29T13:40:48Z",
      "sizeBytes": 179177,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299153411_Spine suite results one pager_V2.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-126",
      "title": "452299157481_Philips-Azurion-Whitepaper-MCVI-FINAL-UNBRANDED_JAN2021.pdf",
      "updatedAt": "2026-06-26T04:46:52Z",
      "sizeBytes": 2547826,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299157481_Philips-Azurion-Whitepaper-MCVI-FINAL-UNBRANDED_JAN2021.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-127",
      "title": "452299157611_Philips_Azurion_Upgrade_Overview_USA.pdf",
      "updatedAt": "2026-06-26T04:46:52Z",
      "sizeBytes": 357316,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299157611_Philips_Azurion_Upgrade_Overview_USA.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-128",
      "title": "452299162901_IGT_Baptist-Bethesda_Zenition_CS_FNL_LR.pdf",
      "updatedAt": "2026-06-26T04:46:55Z",
      "sizeBytes": 945737,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299162901_IGT_Baptist-Bethesda_Zenition_CS_FNL_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-129",
      "title": "452299163581_Philips_Azurion_cybersecurity_whitepaper.pdf",
      "updatedAt": "2026-06-26T04:46:55Z",
      "sizeBytes": 283886,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299163581_Philips_Azurion_cybersecurity_whitepaper.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-130",
      "title": "452299163591_Philips_Azurion_Lab_Integration_and_CyberSecurity_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:55Z",
      "sizeBytes": 98236,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299163591_Philips_Azurion_Lab_Integration_and_CyberSecurity_FINAL.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-131",
      "title": "452299164901_Philips Catalyst Like4Like_LR.pdf",
      "updatedAt": "2020-11-23T08:14:43Z",
      "sizeBytes": 2731008,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299164901_Philips Catalyst Like4Like_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-132",
      "title": "452299165021_Philips_Spine_suite_brochure_V10_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:55Z",
      "sizeBytes": 884362,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299165021_Philips_Spine_suite_brochure_V10_FINAL.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-133",
      "title": "452299166741_Zenition70_Mobile C-arm_Saiseikai Shiga_to_Support EVAR Procedure_Oct 2022.pdf",
      "updatedAt": "2022-10-10T11:31:39Z",
      "sizeBytes": 6229353,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299166741_Zenition70_Mobile C-arm_Saiseikai Shiga_to_Support EVAR Procedure_Oct 2022.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-134",
      "title": "452299166851_Philips Azurion_customer_installation_leaflet_FEB_2021.pdf",
      "updatedAt": "2026-06-26T04:46:57Z",
      "sizeBytes": 353078,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299166851_Philips%20Azurion_customer_installation_leaflet_FEB_2021.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-135",
      "title": "452299167511_Philips_IGT_Azurion_Environmental_performance_brochure.pdf",
      "updatedAt": "2021-05-26T14:27:05Z",
      "sizeBytes": 326841,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299167511_Philips_IGT_Azurion_Environmental_performance_brochure.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-136",
      "title": "452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final (1).pdf",
      "updatedAt": "2026-06-26T04:46:59Z",
      "sizeBytes": 529985,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final%20(1).pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-137",
      "title": "452299167831_Philips_ClarifEye_Usability_Evaluation_infographic_results_LR.pdf",
      "updatedAt": "2021-03-09T10:40:12Z",
      "sizeBytes": 83962,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299167831_Philips_ClarifEye_Usability_Evaluation_infographic_results_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-138",
      "title": "452299168531_Philips_Azurion_accessories_brochure_HR.pdf",
      "updatedAt": "2026-06-26T04:46:59Z",
      "sizeBytes": 5192093,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299168531_Philips_Azurion_accessories_brochure_HR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-139",
      "title": "452299168871_Philips_MD_Eleva_EOS_leaflet_Final.pdf",
      "updatedAt": "2021-05-12T11:34:22Z",
      "sizeBytes": 288784,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299168871_Philips_MD_Eleva_EOS_leaflet_Final.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-140",
      "title": "452299168991_Philips_Neuro_Suite_brochure_Global incl US_final.pdf",
      "updatedAt": "2026-06-26T04:47:00Z",
      "sizeBytes": 839402,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299168991_Philips_Neuro_Suite_brochure_Global%20incl%20US_final.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-141",
      "title": "452299169591_Philips_Azurion_with_IntraSight_Robert_Bosch_Krankenhaus_Stuttgart_customer_story.pdf",
      "updatedAt": "2026-06-26T04:47:02Z",
      "sizeBytes": 161905,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299169591_Philips_Azurion_with_IntraSight_Robert_Bosch_Krankenhaus_Stuttgart_customer_story.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-142",
      "title": "452299170311_Philips_Zenition_50_Image_Intensifier_specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:03Z",
      "sizeBytes": 5047093,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299170311_Philips_Zenition_50_Image_Intensifier_specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-143",
      "title": "452299170321_Philips_Zenition_70_Flat_Detector_specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:04Z",
      "sizeBytes": 5665596,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299170321_Philips_Zenition_70_Flat_Detector_specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-144",
      "title": "452299170361_Philips_Azurion_release_1.2.5_update_highlights_datasheet.pdf",
      "updatedAt": "2021-08-11T13:17:16Z",
      "sizeBytes": 219315,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299170361_Philips_Azurion_release_1.2.5_update_highlights_datasheet.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-145",
      "title": "452299170371_Zenition70_Mobile C-arm_Saiseikai_Utsunomiya_Hospital_Customer_Story_Orthopedics_2022.pdf",
      "updatedAt": "2022-10-10T11:53:01Z",
      "sizeBytes": 3087255,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299170371_Zenition70_Mobile C-arm_Saiseikai_Utsunomiya_Hospital_Customer_Story_Orthopedics_2022.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-146",
      "title": "452299172491_Hybrid OR product brochure_LR.pdf",
      "updatedAt": "2026-06-26T04:47:08Z",
      "sizeBytes": 3670564,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299172491_Hybrid%20OR%20product%20brochure_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-147",
      "title": "452299172741_Philips_Azurion_3F15_with_FlexVision_Specifications.pdf",
      "updatedAt": "2026-06-26T04:47:08Z",
      "sizeBytes": 698976,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299172741_Philips_Azurion_3F15_with_FlexVision_Specifications.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-148",
      "title": "452299172751_Philips_Azurion_3F12_Specifications.pdf",
      "updatedAt": "2026-06-26T04:47:07Z",
      "sizeBytes": 744058,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299172751_Philips_Azurion_3F12_Specifications.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-149",
      "title": "452299173901_Zenition50_Mobile C-arm_Fukui_Prefectural_Hospital_Customer_Story_Ortho_Spine_JaPan.pdf",
      "updatedAt": "2026-06-26T04:47:09Z",
      "sizeBytes": 3710336,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299173901_Zenition50_Mobile%20C-arm_Fukui_Prefectural_Hospital_Customer_Story_Ortho_Spine_JaPan.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-150",
      "title": "452299174211_Philips_Azurion_5C12_Specifications.pdf",
      "updatedAt": "2026-06-26T04:47:09Z",
      "sizeBytes": 708525,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299174211_Philips_Azurion_5C12_Specifications.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-151",
      "title": "452299174221_Philips_Azurion_5C20 Specifications.pdf",
      "updatedAt": "2026-06-26T04:47:10Z",
      "sizeBytes": 656746,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299174221_Philips_Azurion_5C20%20Specifications.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-152",
      "title": "452299175591_Philips_Hemo_System_with_IntelliVue_X3_Brochure_HR_NC.pdf",
      "updatedAt": "2022-03-16T13:18:04Z",
      "sizeBytes": 13060115,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299175591_Philips_Hemo_System_with_IntelliVue_X3_Brochure_HR_NC.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-153",
      "title": "452299176331__Philips_Zenition_50_brochure_May 2022_Updated_LR.pdf",
      "updatedAt": "2022-05-05T06:53:16Z",
      "sizeBytes": 3132059,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299176331__Philips_Zenition_50_brochure_May 2022_Updated_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-154",
      "title": "452299176841_BV Endura Brochure_MA_LR.pdf",
      "updatedAt": "2022-05-18T10:20:17Z",
      "sizeBytes": 2776550,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299176841_BV Endura Brochure_MA_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-155",
      "title": "452299176851_Zenition Orthopedics Brochure_Global_LR.pdf",
      "updatedAt": "2022-05-18T09:14:56Z",
      "sizeBytes": 1730745,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299176851_Zenition Orthopedics Brochure_Global_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-156",
      "title": "452299178061_Zenition Ortho Leaflet_Global.pdf",
      "updatedAt": "2022-08-16T07:03:53Z",
      "sizeBytes": 1626447,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299178061_Zenition Ortho Leaflet_Global.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-157",
      "title": "452299178071_Zenition Vascular Leaflet_Global.pdf",
      "updatedAt": "2022-08-16T06:41:11Z",
      "sizeBytes": 2139481,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299178071_Zenition Vascular Leaflet_Global.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-158",
      "title": "452299178481_Philips_Azurion_Network_whitepaper_HR_FINAL.pdf",
      "updatedAt": "2026-06-26T04:47:13Z",
      "sizeBytes": 914528,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178481_Philips_Azurion_Network_whitepaper_HR_FINAL.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-159",
      "title": "452299178481_Philips_Network_whitepaper_HR_NC_single_page.pdf",
      "updatedAt": "2026-06-26T04:47:15Z",
      "sizeBytes": 1938541,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178481_Philips_Network_whitepaper_HR_NC_single_page.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-160",
      "title": "452299178481_Philips_Network_whitepaper_HR_NC_spreads.pdf",
      "updatedAt": "2026-06-26T04:47:16Z",
      "sizeBytes": 1920894,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178481_Philips_Network_whitepaper_HR_NC_spreads.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-161",
      "title": "452299178751_MAT-5692_Philips_Azurion_7_M12_Monoplane_Ceiling_Mounted_and_Floor_Ceiling_and_Floor_Mounted_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:16Z",
      "sizeBytes": 1638646,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178751_MAT-5692_Philips_Azurion_7_M12_Monoplane_Ceiling_Mounted_and_Floor_Ceiling_and_Floor_Mounted_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-162",
      "title": "452299178771_MAT-5691_Philips_Azurion_5M20_Monoplane_Ceiling_and_Floor_Mounted_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:17Z",
      "sizeBytes": 1462103,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178771_MAT-5691_Philips_Azurion_5M20_Monoplane_Ceiling_and_Floor_Mounted_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-163",
      "title": "452299178771_Philips_Azurion_5M20_Monoplane_Ceiling_and_Floor_Mounted_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:17Z",
      "sizeBytes": 1318916,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178771_Philips_Azurion_5M20_Monoplane_Ceiling_and_Floor_Mounted_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-164",
      "title": "452299178781_MAT-5693_Philips_Azurion_7_M20_Monoplane_Ceiling_Mounted_with_FlexArm_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:17Z",
      "sizeBytes": 1595790,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178781_MAT-5693_Philips_Azurion_7_M20_Monoplane_Ceiling_Mounted_with_FlexArm_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-165",
      "title": "452299178781_Philips_Azurion_7_M20_Monoplane_Ceiling_Mounted_with_FlexArm_Specifications_HR_NC_Jun24.pdf",
      "updatedAt": "2024-06-03T14:32:43Z",
      "sizeBytes": 27358464,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299178781_Philips_Azurion_7_M20_Monoplane_Ceiling_Mounted_with_FlexArm_Specifications_HR_NC_Jun24.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-166",
      "title": "452299180251_MAT-5688_Philips_Azurion_3_M12_Monoplane_Floor_Mounted_for_cardiac_interventions_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:20Z",
      "sizeBytes": 1241514,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299180251_MAT-5688_Philips_Azurion_3_M12_Monoplane_Floor_Mounted_for_cardiac_interventions_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-167",
      "title": "452299180261_MAT-5689_Philips_Azurion_3_M15_Monoplane_Floor_Mounted_for_interventional_procedures_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:20Z",
      "sizeBytes": 1243444,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299180261_MAT-5689_Philips_Azurion_3_M15_Monoplane_Floor_Mounted_for_interventional_procedures_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-168",
      "title": "452299180281_Philips_Azurion_workspaces_brochure_HR_NC.pdf",
      "updatedAt": "2025-04-14T09:29:29Z",
      "sizeBytes": 7058615,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299180281_Philips_Azurion_workspaces_brochure_HR_NC.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-169",
      "title": "452299180301_MAT-5694_Philips_Azurion_7_B12-12_Biplane_for_cardiac_interventions_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:23Z",
      "sizeBytes": 1364833,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299180301_MAT-5694_Philips_Azurion_7_B12-12_Biplane_for_cardiac_interventions_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-170",
      "title": "452299180311_MAT-5695_Philips_Azurion_7_B20-12_Biplane_for_minimally_invasive_interventions_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:23Z",
      "sizeBytes": 1387552,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299180311_MAT-5695_Philips_Azurion_7_B20-12_Biplane_for_minimally_invasive_interventions_Specifications_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-171",
      "title": "452299180341_Philips_Azurion_7_B20_15_neurovascular_interventions_specifications_sept23.pdf",
      "updatedAt": "2026-06-26T04:47:45Z",
      "sizeBytes": 23058578,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299180341_Philips_Azurion_7_B20_15_neurovascular_interventions_specifications_sept23.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-172",
      "title": "452299181971_Philips_Azurion_7_brochure_HR_NC.pdf",
      "updatedAt": "2025-04-15T06:59:44Z",
      "sizeBytes": 16020889,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299181971_Philips_Azurion_7_brochure_HR_NC.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-173",
      "title": "452299181971_Philips_Azurion_7_brochure_July 2023.pdf",
      "updatedAt": "2026-06-26T04:47:45Z",
      "sizeBytes": 17484679,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299181971_Philips_Azurion_7_brochure_July%202023.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-174",
      "title": "452299183511_Philips_Azurion_3_brochure_LR.pdf",
      "updatedAt": "2026-06-26T04:47:48Z",
      "sizeBytes": 702846,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299183511_Philips_Azurion_3_brochure_LR.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-175",
      "title": "452299183751_Philips_SmartCT_brochure_HR_NC.pdf",
      "updatedAt": "2025-05-22T07:02:44Z",
      "sizeBytes": 11935760,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299183751_Philips_SmartCT_brochure_HR_NC.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-176",
      "title": "452299184121_Philips_SmartPath_Catalyst_brochure_LR.pdf",
      "updatedAt": "2024-04-23T09:16:35Z",
      "sizeBytes": 988667,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299184121_Philips_SmartPath_Catalyst_brochure_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-177",
      "title": "452299184401_MAT-5696_Philips_Azurion_7_B20-15_Biplane_for_neurovascular_interventions_Specifications_LR.pdf",
      "updatedAt": "2025-12-04T13:51:17Z",
      "sizeBytes": 1395440,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299184401_MAT-5696_Philips_Azurion_7_B20-15_Biplane_for_neurovascular_interventions_Specifications_LR.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-178",
      "title": "452299184501_Philips_SmartCT_specifications_HR_NC.pdf",
      "updatedAt": "2025-05-22T07:01:12Z",
      "sizeBytes": 14451250,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299184501_Philips_SmartCT_specifications_HR_NC.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-179",
      "title": "452299184601_Zenition Cybersecurity Whitepaper.pdf",
      "updatedAt": "2026-06-26T04:47:55Z",
      "sizeBytes": 5660020,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299184601_Zenition%20Cybersecurity%20Whitepaper.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-180",
      "title": "452299185611_Philips_Azurion_7_M20_with_FlexArm_brochure_HR_NC.pdf",
      "updatedAt": "2025-04-14T09:38:29Z",
      "sizeBytes": 11373836,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299185611_Philips_Azurion_7_M20_with_FlexArm_brochure_HR_NC.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-181",
      "title": "452299189281_Philips_IGT_Learning_App_postcard.pdf",
      "updatedAt": "2025-03-25T14:50:51Z",
      "sizeBytes": 423013,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/452299189281_Philips_IGT_Learning_App_postcard.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-182",
      "title": "4523 001 00051_EchoNavigator_en-US.pdf",
      "updatedAt": "2019-12-16T11:01:16Z",
      "sizeBytes": 7141083,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 00051_EchoNavigator_en-US.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-183",
      "title": "4523 001 00401_StentBoost Live_en-US.pdf",
      "updatedAt": "2020-06-18T06:34:57Z",
      "sizeBytes": 1590330,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 00401_StentBoost Live_en-US.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-184",
      "title": "4523 001 00771_Dynamic Coronary Roadmap_en-US.pdf",
      "updatedAt": "2020-06-18T06:31:30Z",
      "sizeBytes": 964904,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 00771_Dynamic Coronary Roadmap_en-US.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-185",
      "title": "4523 001 01142_EchoNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:24Z",
      "sizeBytes": 6145630,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001142_EchoNavigator_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-186",
      "title": "4523 001 01143_EchoNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:25Z",
      "sizeBytes": 6139460,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001143_EchoNavigator_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-187",
      "title": "4523 001 01144_EchoNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:25Z",
      "sizeBytes": 6141157,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001144_EchoNavigator_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-188",
      "title": "4523 001 01511_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:27Z",
      "sizeBytes": 12927670,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001511_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-189",
      "title": "4523 001 01513_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:28Z",
      "sizeBytes": 12630540,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001513_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-190",
      "title": "4523 001 01842_Collaboration_Live_EN-US.pdf",
      "updatedAt": "2026-06-26T04:41:26Z",
      "sizeBytes": 1888074,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001842_Collaboration_Live_EN-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-191",
      "title": "4523 001 01901_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:30Z",
      "sizeBytes": 10266170,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001901_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-192",
      "title": "4523 001 01902_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:31Z",
      "sizeBytes": 10424727,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2001902_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-193",
      "title": "4523 001 02261_Philips Interventional Hemodynamic System_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:30Z",
      "sizeBytes": 1194346,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2002261_Philips%20Interventional%20Hemodynamic%20System_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-194",
      "title": "4523 001 02263_Hemodynamic System_en-US.pdf",
      "updatedAt": "2023-12-18T14:47:06Z",
      "sizeBytes": 761393,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 02263_Hemodynamic System_en-US.pdf?web=1",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-195",
      "title": "4523 001 02533_Hemodynamic System_zh-TW.pdf",
      "updatedAt": "2026-06-26T04:41:31Z",
      "sizeBytes": 902957,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2002533_Hemodynamic%20System_zh-TW.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-196",
      "title": "4523 001 03571_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:34Z",
      "sizeBytes": 12361741,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2003571_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-197",
      "title": "4523 001 03572_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:35Z",
      "sizeBytes": 12034637,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2003572_Azurion_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-198",
      "title": "4523 001 03951_SmartCT_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:37Z",
      "sizeBytes": 12026689,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2003951_SmartCT_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-199",
      "title": "4523 001 04651_3D Roadmap_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:36Z",
      "sizeBytes": 1582103,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2004651_3D%20Roadmap_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-200",
      "title": "4523 001 05001_3D-RA_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:37Z",
      "sizeBytes": 4668169,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2005001_3D-RA_en-US.pdf",
      "source": "folder-page"
    },
    {
      "id": "sp-manifest-201",
      "title": "4523 001 24652_XperGuide_en-US.pdf",
      "updatedAt": "2023-09-29T08:58:05Z",
      "sizeBytes": 304296,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 24652_XperGuide_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-202",
      "title": "4523 001 25782_Foot Switch_en-US.pdf",
      "updatedAt": "2023-07-26T13:38:29Z",
      "sizeBytes": 403354,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 25782_Foot Switch_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-203",
      "title": "4523 001 25783_Foot Switch_en-US.pdf",
      "updatedAt": "2023-09-19T09:17:08Z",
      "sizeBytes": 427341,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 25783_Foot Switch_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-204",
      "title": "4523 001 25784_Foot Switch_en-US.pdf",
      "updatedAt": "2025-02-05T11:57:15Z",
      "sizeBytes": 484786,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 25784_Foot Switch_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-205",
      "title": "4523 001 26601_MultiDiagnost Eleva Foot Switch_en-US.pdf",
      "updatedAt": "2023-09-20T06:34:30Z",
      "sizeBytes": 400823,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 26601_MultiDiagnost Eleva Foot Switch_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-206",
      "title": "4523 001 27721_Allura CV20 Foot Switch_en-US.pdf",
      "updatedAt": "2023-09-20T06:38:39Z",
      "sizeBytes": 425282,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 27721_Allura CV20 Foot Switch_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-207",
      "title": "4523 001 30521_Patient Table_en-US.pdf",
      "updatedAt": "2024-05-15T07:48:31Z",
      "sizeBytes": 229323,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 30521_Patient Table_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-208",
      "title": "4523 001 30522_Patient Table_en-US.pdf",
      "updatedAt": "2024-12-09T10:28:05Z",
      "sizeBytes": 283501,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 30522_Patient Table_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-209",
      "title": "4523 001 30523_Patient Table_en-US.pdf",
      "updatedAt": "2025-09-03T07:06:15Z",
      "sizeBytes": 416893,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 30523_Patient Table_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-210",
      "title": "4523 001 30831_Patient Tabel L4L zh-CN.pdf",
      "updatedAt": "2024-05-29T12:09:39Z",
      "sizeBytes": 285569,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 30831_Patient Tabel L4L zh-CN.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-211",
      "title": "4523 001 30851_PatientTable_en-US.pdf",
      "updatedAt": "2024-05-16T12:30:49Z",
      "sizeBytes": 228656,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 30851_PatientTable_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-212",
      "title": "4523 001 30852 Patient Table_en-US.pdf",
      "updatedAt": "2024-12-13T10:31:55Z",
      "sizeBytes": 285643,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 30852 Patient Table_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-213",
      "title": "4523 001 30853_Patient Table_en-US.pdf",
      "updatedAt": "2025-09-10T05:02:56Z",
      "sizeBytes": 416083,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 30853_Patient Table_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-214",
      "title": "4523 001 34131_Azurion_en-US.pdf",
      "updatedAt": "2025-07-31T06:33:49Z",
      "sizeBytes": 169107,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 34131_Azurion_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-215",
      "title": "4523 001 34771_Coronary Tools, Interventional Tools_zh-TW.pdf",
      "updatedAt": "2025-08-12T05:40:23Z",
      "sizeBytes": 264490,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 34771_Coronary Tools, Interventional Tools_zh-TW.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-216",
      "title": "4523 001 34831_Azurion_en-US.pdf",
      "updatedAt": "2025-02-11T13:32:30Z",
      "sizeBytes": 295569,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/4523 001 34831_Azurion_en-US.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-217",
      "title": "459801631264_ClarifEye Needle IFU_EN.pdf",
      "updatedAt": "2021-08-24T09:38:20Z",
      "sizeBytes": 373176,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/459801631264_ClarifEye Needle IFU_EN.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-218",
      "title": "459801631273_ClarifEye Marker IFU_EN.pdf",
      "updatedAt": "2021-08-24T09:42:45Z",
      "sizeBytes": 387921,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/459801631273_ClarifEye Marker IFU_EN.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-219",
      "title": "Allura_XPER_FD10_10_Passport.pdf",
      "updatedAt": "2006-11-20T20:00:07Z",
      "sizeBytes": 176542,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Allura_XPER_FD10_10_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-220",
      "title": "Allura_XPER_FD10_20_Passport.pdf",
      "updatedAt": "2006-10-27T12:20:18Z",
      "sizeBytes": 92826,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Allura_XPER_FD10_20_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-221",
      "title": "Allura_XPER_FD10_Passport.pdf",
      "updatedAt": "2006-10-27T12:17:30Z",
      "sizeBytes": 104024,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Allura_XPER_FD10_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-222",
      "title": "Allura_Xper_FD20_15.pdf",
      "updatedAt": "2014-11-25T11:14:14Z",
      "sizeBytes": 112572,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Allura_Xper_FD20_15.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-223",
      "title": "Allura_XPER_FD20_Passport.pdf",
      "updatedAt": "2006-10-27T12:18:05Z",
      "sizeBytes": 100767,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Allura_XPER_FD20_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-224",
      "title": "Azurion PR messaging_FINAL_Feb9_1.pptx",
      "updatedAt": "2017-02-09T20:29:02Z",
      "sizeBytes": 859032,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Azurion PR messaging_FINAL_Feb9_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-225",
      "title": "Azurion Release 2.2 FlexArm upgrade.pdf",
      "updatedAt": "2021-05-31T08:41:19Z",
      "sizeBytes": 1073896,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Azurion Release 2.2 FlexArm upgrade.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-226",
      "title": "Azurion_simulation_study_infographic_PDF_high_res.pdf",
      "updatedAt": "2017-01-12T11:06:56Z",
      "sizeBytes": 82266,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Azurion_simulation_study_infographic_PDF_high_res.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-227",
      "title": "BV Vectra Technology Maximizer Plus Collateral.pdf",
      "updatedAt": "2020-10-20T07:37:14Z",
      "sizeBytes": 704408,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/BV Vectra Technology Maximizer Plus Collateral.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-228",
      "title": "BV_Endura_Passport.pdf",
      "updatedAt": "2013-02-07T15:31:32Z",
      "sizeBytes": 2218441,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/BV_Endura_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-229",
      "title": "BV_Pulsera_Passport.pdf",
      "updatedAt": "2013-02-07T15:53:57Z",
      "sizeBytes": 2784296,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/BV_Pulsera_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-230",
      "title": "CAD IVP Customer Deck_1.pptx",
      "updatedAt": "2021-05-14T09:20:08Z",
      "sizeBytes": 24862680,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/CAD IVP Customer Deck_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-231",
      "title": "Cardiology Toolkit 1_  Social Media Engagement flow_1.pptx",
      "updatedAt": "2023-04-07T22:02:23Z",
      "sizeBytes": 3025899,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Cardiology Toolkit 1_  Social Media Engagement flow_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-232",
      "title": "Cardiology website instructions_1.pptx",
      "updatedAt": "2021-05-14T13:56:52Z",
      "sizeBytes": 2464164,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Cardiology website instructions_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-233",
      "title": "Cardiology_Campaign_Photo_Journey_Application_2022_1.pptx",
      "updatedAt": "2022-03-31T07:25:53Z",
      "sizeBytes": 82403571,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Cardiology_Campaign_Photo_Journey_Application_2022_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-234",
      "title": "Cardiology_Event_Activation_Playbook_July 2024_1.pptx",
      "updatedAt": "2024-07-24T12:24:07Z",
      "sizeBytes": 78734438,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Cardiology_Event_Activation_Playbook_July 2024_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-235",
      "title": "Case Study_ Delivering Next-Gen Benefits, Nottingham - PCI _ Philips IGT_v1.0.PDF",
      "updatedAt": "2018-06-29T06:47:50Z",
      "sizeBytes": 2584805,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Case Study_ Delivering Next-Gen Benefits, Nottingham - PCI _ Philips IGT_v1.0.PDF?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-236",
      "title": "Clinique_Pasteur_Customer_Testimonial_Allura_Centron.pdf",
      "updatedAt": "2013-09-18T06:47:36Z",
      "sizeBytes": 218659,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Clinique_Pasteur_Customer_Testimonial_Allura_Centron.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-237",
      "title": "CLV_IGT_One Pager SmartCT_020123.pdf",
      "updatedAt": "2023-01-02T06:49:44Z",
      "sizeBytes": 181855,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/CLV_IGT_One Pager SmartCT_020123.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-238",
      "title": "CLV_IGT_One Pager_Dynamic Coronary Roadmap (DCR)_020123.pdf",
      "updatedAt": "2022-12-19T06:30:19Z",
      "sizeBytes": 236948,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/CLV_IGT_One Pager_Dynamic Coronary Roadmap (DCR)_020123.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-239",
      "title": "CLV_IGT_One Pager_Hemo_160123.pdf",
      "updatedAt": "2023-01-16T18:27:43Z",
      "sizeBytes": 246927,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/CLV_IGT_One Pager_Hemo_160123.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-240",
      "title": "CLV_IGT_One Pager_IntraSight_020123.pdf",
      "updatedAt": "2022-12-08T09:40:55Z",
      "sizeBytes": 179409,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/CLV_IGT_One Pager_IntraSight_020123.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-241",
      "title": "CLV_IGT_One Pager_TechMaximizer_200123.pdf",
      "updatedAt": "2023-01-02T12:37:06Z",
      "sizeBytes": 262395,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/CLV_IGT_One Pager_TechMaximizer_200123.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-242",
      "title": "Collimator_Passport.pdf",
      "updatedAt": "2006-10-27T13:26:14Z",
      "sizeBytes": 79237,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Collimator_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-243",
      "title": "Covid and the heart - Cardiology reputation program.pdf",
      "updatedAt": "2021-05-12T12:19:09Z",
      "sizeBytes": 1258406,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Covid and the heart - Cardiology reputation program.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-244",
      "title": "Customer_Testimonial_Allura_FC_CHU_Brest.pdf",
      "updatedAt": "2013-09-18T06:46:37Z",
      "sizeBytes": 134187,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Customer_Testimonial_Allura_FC_CHU_Brest.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-245",
      "title": "D000702156  Declaration of Compatibility CX50 signed vA.pdf",
      "updatedAt": "2026-06-26T04:48:42Z",
      "sizeBytes": 211018,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000702156  Declaration of Compatibility CX50 signed vA.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-246",
      "title": "D000702195 Declaration of Compatibility X-ray System and Xcelera_ISCV vD-02-signed.pdf",
      "updatedAt": "2022-01-31T15:32:45Z",
      "sizeBytes": 418387,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000702195 Declaration of Compatibility X-ray System and Xcelera_ISCV vD-02-signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-247",
      "title": "D000702288 Declaration of Compatibility X-ray System and Trumpf Trusystem 7500 vA-01-signed.pdf",
      "updatedAt": "2021-07-27T13:18:31Z",
      "sizeBytes": 471445,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000702288 Declaration of Compatibility X-ray System and Trumpf Trusystem 7500 vA-01-signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-248",
      "title": "D000702419 Declaration of Compatibility X-ray System and Skytron CBC vB-00-signed.pdf",
      "updatedAt": "2021-11-29T16:11:05Z",
      "sizeBytes": 144823,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000702419 Declaration of Compatibility X-ray System and Skytron CBC vB-00-signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-249",
      "title": "D000720870 Declaration of Compatibility X-ray System and Boston Scientific iLab vB-00-signed.pdf",
      "updatedAt": "2021-11-29T15:54:39Z",
      "sizeBytes": 184338,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000720870 Declaration of Compatibility X-ray System and Boston Scientific iLab vB-00-signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-250",
      "title": "D000720889 Declaration of Compatibility X-ray System and Corindus Corpath vB-00-signed.pdf",
      "updatedAt": "2021-11-29T15:55:11Z",
      "sizeBytes": 145796,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000720889 Declaration of Compatibility X-ray System and Corindus Corpath vB-00-signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-251",
      "title": "D000720915 Declaration of Compatibility X-ray System and Trumpf boom vC-01 - signed.pdf",
      "updatedAt": "2022-01-31T15:29:30Z",
      "sizeBytes": 414687,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000720915 Declaration of Compatibility X-ray System and Trumpf boom vC-01 - signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-252",
      "title": "D000720915 Declaration of Compatibility X-ray System and Trumpf boom vD-01 - signed.pdf",
      "updatedAt": "2022-07-20T13:51:33Z",
      "sizeBytes": 661032,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000720915 Declaration of Compatibility X-ray System and Trumpf boom vD-01 - signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-253",
      "title": "D000720981 Declaration of Compatibility X-ray System and NXFC vC - signed (1).pdf",
      "updatedAt": "2022-04-08T07:52:21Z",
      "sizeBytes": 218644,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000720981 Declaration of Compatibility X-ray System and NXFC vC - signed (1).pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-254",
      "title": "D000720981 Declaration of Compatibility X-ray System and NXFC-vD.0 - signed.pdf",
      "updatedAt": "2022-10-24T09:02:51Z",
      "sizeBytes": 679468,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D000720981 Declaration of Compatibility X-ray System and NXFC-vD.0 - signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-255",
      "title": "D001111952 DoComp Corindus CorPath_vB - signed.pdf",
      "updatedAt": "2025-03-16T18:57:24Z",
      "sizeBytes": 264339,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D001111952 DoComp Corindus CorPath_vB - signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-256",
      "title": "D001111952 DoComp Corindus CorPath_vD_signed.pdf",
      "updatedAt": "2025-11-19T11:40:50Z",
      "sizeBytes": 250842,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D001111952 DoComp Corindus CorPath_vD_signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-257",
      "title": "D001310704 LumiGuide Equipment UK Declaration of Conformity Rev A.pdf",
      "updatedAt": "2023-09-18T07:50:47Z",
      "sizeBytes": 322899,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D001310704 LumiGuide Equipment UK Declaration of Conformity Rev A.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-258",
      "title": "D001807385_A_OPERATOR'S MANUAL, ROTATIONAL OPTION.pdf",
      "updatedAt": "2025-10-21T20:06:11Z",
      "sizeBytes": 1571180,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D001807385_A_OPERATOR'S MANUAL, ROTATIONAL OPTION.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-259",
      "title": "D001939966 DoComp Philips AngioCT_vD.pdf",
      "updatedAt": "2026-03-12T09:29:17Z",
      "sizeBytes": 222252,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D001939966 DoComp Philips AngioCT_vD.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-260",
      "title": "D001954295 DoComp ISM EasySuite_vD_signed.pdf",
      "updatedAt": "2025-11-19T11:35:32Z",
      "sizeBytes": 252040,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D001954295 DoComp ISM EasySuite_vD_signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-261",
      "title": "D045587-02 SCTO Sales Presentation_1.pptx",
      "updatedAt": "2021-01-21T23:17:42Z",
      "sizeBytes": 16715060,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D045587-02 SCTO Sales Presentation_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-262",
      "title": "D059341-01 Tack Launch Print Ads.pdf",
      "updatedAt": "2021-10-13T16:43:33Z",
      "sizeBytes": 1332108,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D059341-01 Tack Launch Print Ads.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-263",
      "title": "D059487-01 Philips Cardiology Portfolio Vision Deck_1.pptx",
      "updatedAt": "2021-05-15T01:54:06Z",
      "sizeBytes": 26304040,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D059487-01 Philips Cardiology Portfolio Vision Deck_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-264",
      "title": "D060094-01 Tack digital ads.docx",
      "updatedAt": "2022-03-08T13:24:00Z",
      "sizeBytes": 158085,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D060094-01 Tack digital ads.docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-265",
      "title": "D060787-00 Cardiology Portfolio Story Deck_1.pptx",
      "updatedAt": "2021-05-17T00:28:19Z",
      "sizeBytes": 27330526,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D060787-00 Cardiology Portfolio Story Deck_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-266",
      "title": "D061346-00 TOBA II BTK 24-month clinical summary.pdf",
      "updatedAt": "2021-11-10T21:32:30Z",
      "sizeBytes": 363846,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D061346-00 TOBA II BTK 24-month clinical summary.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-267",
      "title": "D061377-00 IVUS Consensus eblast.pdf",
      "updatedAt": "2021-12-03T17:05:51Z",
      "sizeBytes": 1939346,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D061377-00 IVUS Consensus eblast.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-268",
      "title": "D061377-00 IVUS Consensus One Pager.pdf",
      "updatedAt": "2021-12-14T09:30:54Z",
      "sizeBytes": 79708,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D061377-00 IVUS Consensus One Pager.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-269",
      "title": "D061591-00 AngioSculpt Evo Indications Flyer.pdf",
      "updatedAt": "2022-04-08T22:34:26Z",
      "sizeBytes": 340605,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D061591-00 AngioSculpt Evo Indications Flyer.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-270",
      "title": "d061625-03-cied-infection-lbct-one-pager.pdf",
      "updatedAt": "2023-10-31T18:44:32Z",
      "sizeBytes": 166113,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/d061625-03-cied-infection-lbct-one-pager.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-271",
      "title": "D061671-01 iFR Class IA Gold Just Got Better_1.pptx",
      "updatedAt": "2022-05-16T23:34:32Z",
      "sizeBytes": 25527900,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D061671-01 iFR Class IA Gold Just Got Better_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-272",
      "title": "D062041-00_ULC_PCI_Updated_Messaging_Final_1.pptx",
      "updatedAt": "2022-09-21T16:37:50Z",
      "sizeBytes": 6474395,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/D062041-00_ULC_PCI_Updated_Messaging_Final_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-273",
      "title": "Declaration of Compatibility_BiodexTable.pdf",
      "updatedAt": "2024-03-14T10:10:53Z",
      "sizeBytes": 295433,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_BiodexTable.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-274",
      "title": "Declaration of Compatibility_Brainlab_Navigation.pdf",
      "updatedAt": "2019-09-20T08:36:53Z",
      "sizeBytes": 233665,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Brainlab_Navigation.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-275",
      "title": "Declaration of Compatibility_Cydar EV.pdf",
      "updatedAt": "2023-06-13T07:17:02Z",
      "sizeBytes": 87906,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Cydar EV.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-276",
      "title": "Declaration of Compatibility_Dornier.pdf",
      "updatedAt": "2023-06-13T07:16:10Z",
      "sizeBytes": 1906566,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Dornier.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-277",
      "title": "Declaration of Compatibility_IDI Table.pdf",
      "updatedAt": "2024-03-14T11:40:47Z",
      "sizeBytes": 219760,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_IDI Table.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-278",
      "title": "Declaration of Compatibility_Maquet Meera Table.pdf",
      "updatedAt": "2024-03-14T10:32:00Z",
      "sizeBytes": 283773,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Maquet Meera Table.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-279",
      "title": "Declaration of Compatibility_Medtronic_Stealthstation.pdf",
      "updatedAt": "2023-06-13T07:20:02Z",
      "sizeBytes": 115834,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Medtronic_Stealthstation.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-280",
      "title": "Declaration of Compatibility_Radlink.pdf",
      "updatedAt": "2023-06-13T07:21:16Z",
      "sizeBytes": 151826,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Radlink.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-281",
      "title": "Declaration of Compatibility_Socomec UPS_ 230V.pdf",
      "updatedAt": "2023-06-13T07:14:19Z",
      "sizeBytes": 89489,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Socomec UPS_ 230V.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-282",
      "title": "Declaration of Compatibility_Stille_Tables.pdf",
      "updatedAt": "2023-06-13T07:10:34Z",
      "sizeBytes": 163431,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Stille_Tables.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-283",
      "title": "Declaration of Compatibility_StilleTable.pdf",
      "updatedAt": "2024-03-14T10:35:36Z",
      "sizeBytes": 286725,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_StilleTable.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-284",
      "title": "Declaration of Compatibility_Stryker_ADAPT.pdf",
      "updatedAt": "2023-06-13T07:23:04Z",
      "sizeBytes": 161619,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Stryker_ADAPT.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-285",
      "title": "Declaration of Compatibility_Stryker_HipCheck.pdf",
      "updatedAt": "2023-06-13T07:22:14Z",
      "sizeBytes": 129199,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Stryker_HipCheck.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-286",
      "title": "Declaration of Compatibility_Stryker_SpineMap_Go.pdf",
      "updatedAt": "2023-06-13T07:23:54Z",
      "sizeBytes": 133061,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Declaration of Compatibility_Stryker_SpineMap_Go.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-287",
      "title": "Detector_Passport.pdf",
      "updatedAt": "2006-10-27T13:24:30Z",
      "sizeBytes": 178392,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Detector_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-288",
      "title": "DHF194029 DeclofCompatibility Carto3 V07_02_signed.pdf",
      "updatedAt": "2020-08-20T06:01:59Z",
      "sizeBytes": 1767312,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DHF194029 DeclofCompatibility Carto3 V07_02_signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-289",
      "title": "DHF225387 Declaration of Compatibility ISM EasySuiteV09_00_signed.pdf",
      "updatedAt": "2020-08-06T12:24:00Z",
      "sizeBytes": 374343,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DHF225387 Declaration of Compatibility ISM EasySuiteV09_00_signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-290",
      "title": "DHF250148 DoComp Trumpf Trusystem 7500 V09-01_signed.pdf",
      "updatedAt": "2020-08-06T13:12:41Z",
      "sizeBytes": 232145,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DHF250148 DoComp Trumpf Trusystem 7500 V09-01_signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-291",
      "title": "DHF267156 DoComp Boston Scientific iLab V06_01_signed.pdf",
      "updatedAt": "2020-11-18T07:22:35Z",
      "sizeBytes": 594212,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DHF267156 DoComp Boston Scientific iLab V06_01_signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-292",
      "title": "DHF271068_DeclofCompatibility_XraySystem_and_Trumpf_boom V05 signed.pdf",
      "updatedAt": "2020-08-07T13:48:07Z",
      "sizeBytes": 333598,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DHF271068_DeclofCompatibility_XraySystem_and_Trumpf_boom V05 signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-293",
      "title": "DHF328029 Declaration of Compatibility NXFC V04_01_signed.pdf",
      "updatedAt": "2020-11-18T07:27:30Z",
      "sizeBytes": 596514,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DHF328029 Declaration of Compatibility NXFC V04_01_signed.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-294",
      "title": "DICOM_Integris_H_Release_3___Integris_V_Release11.pdf",
      "updatedAt": "2026-06-26T07:12:47Z",
      "sizeBytes": 42420,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DICOM_Integris_H_Release_3___Integris_V_Release11.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-295",
      "title": "DICOM_Integris_V_Release_11.pdf",
      "updatedAt": "2026-06-26T07:12:46Z",
      "sizeBytes": 42420,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DICOM_Integris_V_Release_11.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-296",
      "title": "DICOM_Integris_V_with_High-Speed_DICOM_Interface_R1.pdf",
      "updatedAt": "2026-06-26T07:12:48Z",
      "sizeBytes": 38284,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DICOM_Integris_V_with_High-Speed_DICOM_Interface_R1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-297",
      "title": "DS IGT Brochure _ 452299133921.pdf",
      "updatedAt": "2018-03-06T12:06:13Z",
      "sizeBytes": 956618,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DS IGT Brochure _ 452299133921.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-298",
      "title": "DS leaflet Cardio Vascular_452299112551.pdf",
      "updatedAt": "2018-01-26T09:44:24Z",
      "sizeBytes": 2193299,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DS leaflet Cardio Vascular_452299112551.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-299",
      "title": "DS leaflet Mobile C arm_452299109901.pdf",
      "updatedAt": "2018-01-26T09:46:48Z",
      "sizeBytes": 1674362,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/DS leaflet Mobile C arm_452299109901.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-300",
      "title": "EcoPassport_Philips_Azurion_Biplane_System V2.pdf",
      "updatedAt": "2024-07-31T11:50:05Z",
      "sizeBytes": 237173,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/EcoPassport_Philips_Azurion_Biplane_System V2.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-301",
      "title": "Final march 30 Customer presentation_Tables_1.pptx",
      "updatedAt": "2021-03-30T11:23:18Z",
      "sizeBytes": 10919300,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Final march 30 Customer presentation_Tables_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-302",
      "title": "Grid_Passport.pdf",
      "updatedAt": "2006-11-01T14:41:18Z",
      "sizeBytes": 117052,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Grid_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-303",
      "title": "Head of Cardiology 02_23_23_Final_1.pptx",
      "updatedAt": "2023-02-27T11:58:26Z",
      "sizeBytes": 70058533,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Head of Cardiology 02_23_23_Final_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-304",
      "title": "Heart Navigator r3 2016 07.pdf",
      "updatedAt": "2016-07-21T12:28:28Z",
      "sizeBytes": 2471045,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Heart Navigator r3 2016 07.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-305",
      "title": "HS IGT Azurion marcom toolkit March 2022_1.pptx",
      "updatedAt": "2022-03-28T14:40:14Z",
      "sizeBytes": 28246286,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Azurion marcom toolkit March 2022_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-306",
      "title": "HS IGT Azurion toolkit January 2022_1.pptx",
      "updatedAt": "2022-02-01T15:25:04Z",
      "sizeBytes": 16797118,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Azurion toolkit January 2022_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-307",
      "title": "HS IGT Cardiology marcom toolkit July 2021_1.pptx",
      "updatedAt": "2021-07-30T15:55:43Z",
      "sizeBytes": 27822226,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Cardiology marcom toolkit July 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-308",
      "title": "HS IGT Cardiology marcom toolkit March 2021_1.pptx",
      "updatedAt": "2021-05-28T11:01:56Z",
      "sizeBytes": 67180647,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Cardiology marcom toolkit March 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-309",
      "title": "HS IGT Cardiology marcom toolkit May 2021_1.pptx",
      "updatedAt": "2021-05-28T10:56:43Z",
      "sizeBytes": 10725701,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Cardiology marcom toolkit May 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-310",
      "title": "HS IGT Clinical suites toolkit July 2021_1.pptx",
      "updatedAt": "2021-07-30T15:45:09Z",
      "sizeBytes": 26129002,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Clinical suites toolkit July 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-311",
      "title": "HS IGT Clinical suites toolkit March 2021_1.pptx",
      "updatedAt": "2021-05-28T11:08:45Z",
      "sizeBytes": 16342291,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Clinical suites toolkit March 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-312",
      "title": "HS IGT Clinical suites toolkit November 2021_1.pptx",
      "updatedAt": "2021-11-26T13:42:06Z",
      "sizeBytes": 24318644,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Clinical suites toolkit November 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-313",
      "title": "HS IGT Clinical suites toolkit September 2021_1.pptx",
      "updatedAt": "2021-09-29T14:39:05Z",
      "sizeBytes": 25096858,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Clinical suites toolkit September 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-314",
      "title": "HS IGT Neurovascular Stroke toolkit_apr_2023_1.pptx",
      "updatedAt": "2023-04-24T13:35:55Z",
      "sizeBytes": 103700001,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular Stroke toolkit_apr_2023_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-315",
      "title": "HS IGT Neurovascular Stroke toolkit_apr2022_1.pptx",
      "updatedAt": "2022-04-29T14:49:31Z",
      "sizeBytes": 104654733,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular Stroke toolkit_apr2022_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-316",
      "title": "HS IGT Neurovascular Stroke toolkit_sept23_2022_1.pptx",
      "updatedAt": "2022-09-23T15:03:11Z",
      "sizeBytes": 92973734,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular Stroke toolkit_sept23_2022_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-317",
      "title": "HS IGT Neurovascular toolkit January 2021.pdf",
      "updatedAt": "2021-01-19T13:12:26Z",
      "sizeBytes": 1318163,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular toolkit January 2021.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-318",
      "title": "HS IGT Neurovascular toolkit March 2021.pdf",
      "updatedAt": "2021-03-31T08:45:42Z",
      "sizeBytes": 1459460,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular toolkit March 2021.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-319",
      "title": "HS IGT Neurovascular toolkit March 2022_1.pptx",
      "updatedAt": "2022-03-22T08:50:24Z",
      "sizeBytes": 30791959,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular toolkit March 2022_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-320",
      "title": "HS IGT Neurovascular toolkit May 2021.pdf",
      "updatedAt": "2021-05-27T06:15:22Z",
      "sizeBytes": 2732003,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular toolkit May 2021.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-321",
      "title": "HS IGT Neurovascular toolkit Sept 2021.pdf",
      "updatedAt": "2021-09-24T12:38:35Z",
      "sizeBytes": 3379497,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Neurovascular toolkit Sept 2021.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-322",
      "title": "HS IGT Radiology marcom toolkit July 2021_1.pptx",
      "updatedAt": "2021-07-30T15:57:15Z",
      "sizeBytes": 23175281,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Radiology marcom toolkit July 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-323",
      "title": "HS IGT Radiology marcom toolkit March 2021_1.pptx",
      "updatedAt": "2021-05-28T11:04:56Z",
      "sizeBytes": 41243649,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Radiology marcom toolkit March 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-324",
      "title": "HS IGT Radiology marcom toolkit May 2021_1.pptx",
      "updatedAt": "2021-05-28T11:00:39Z",
      "sizeBytes": 11457102,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Radiology marcom toolkit May 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-325",
      "title": "HS IGT Surgery marcom toolkit July 2021_1.pptx",
      "updatedAt": "2021-07-29T05:55:33Z",
      "sizeBytes": 17307327,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Surgery marcom toolkit July 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-326",
      "title": "HS IGT Surgery marcom toolkit March 2021_1.pptx",
      "updatedAt": "2021-03-31T14:42:47Z",
      "sizeBytes": 29862797,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Surgery marcom toolkit March 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-327",
      "title": "HS IGT Surgery marcom toolkit May 2021_1.pptx",
      "updatedAt": "2021-05-27T07:27:46Z",
      "sizeBytes": 48468284,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Surgery marcom toolkit May 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-328",
      "title": "HS IGT Surgery marcom toolkit Nov 2021 Final_1.pptx",
      "updatedAt": "2021-11-25T07:46:12Z",
      "sizeBytes": 12833933,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS IGT Surgery marcom toolkit Nov 2021 Final_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-329",
      "title": "HS_IGT___Azurion_7-With-FlexArm-_Brochure_Global__v4_20220318.pdf",
      "updatedAt": "2025-04-14T09:38:29Z",
      "sizeBytes": 11373836,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_7-With-FlexArm-_Brochure_Global__v4_20220318.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-330",
      "title": "HS_IGT___Azurion_ClarityIQ_White-Paper_Global-Non-US__v2_20220318.pdf",
      "updatedAt": "2022-03-18T10:20:57Z",
      "sizeBytes": 1659805,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_ClarityIQ_White-Paper_Global-Non-US__v2_20220318.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-331",
      "title": "HS_IGT___Azurion_ClarityIQ_White-Paper_US__v1_20220318.pdf",
      "updatedAt": "2022-03-18T10:20:44Z",
      "sizeBytes": 1675518,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_ClarityIQ_White-Paper_US__v1_20220318.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-332",
      "title": "HS_IGT___Azurion_ClarityIQ-TJU-multi-vendor-study_Article_Global__v1_20230315.pdf",
      "updatedAt": "2021-12-27T10:31:03Z",
      "sizeBytes": 62846,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_ClarityIQ-TJU-multi-vendor-study_Article_Global__v1_20230315.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-333",
      "title": "HS_IGT___Azurion_DoseAware_Brochure_Global__v1_20240123.pdf",
      "updatedAt": "2024-01-23T14:32:55Z",
      "sizeBytes": 641809,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_DoseAware_Brochure_Global__v1_20240123.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-334",
      "title": "HS_IGT___Azurion_DoseAware_Presentation_Global__v1_20220223_1.pptx",
      "updatedAt": "2021-12-07T13:32:26Z",
      "sizeBytes": 18436102,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_DoseAware_Presentation_Global__v1_20220223_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-335",
      "title": "HS_IGT_Azurion 3.0 SmartPath Catalyst L4L TechMax PPT_April 2024_1.pptx",
      "updatedAt": "2024-04-23T16:19:56Z",
      "sizeBytes": 6532720,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Azurion 3.0 SmartPath Catalyst L4L TechMax PPT_April 2024_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-336",
      "title": "HS_IGT_Azurion_R3.0_ MarCom Toolkit 1.1_April 2024_V2 with updates_FINAL.pdf",
      "updatedAt": "2024-06-10T13:21:34Z",
      "sizeBytes": 7653763,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Azurion_R3.0_ MarCom Toolkit 1.1_April 2024_V2 with updates_FINAL.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-337",
      "title": "HS_IGT_Azurion_Technology_Maximizer_Essential_Leaflet_Apr 25.pdf",
      "updatedAt": "2025-04-10T14:13:27Z",
      "sizeBytes": 549127,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Azurion_Technology_Maximizer_Essential_Leaflet_Apr 25.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-338",
      "title": "HS_IGT_Cardiology__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf",
      "updatedAt": "2026-06-26T07:13:19Z",
      "sizeBytes": null,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/HS_IGT_Cardiology__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-339",
      "title": "HS_IGT_Neuro__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf",
      "updatedAt": "2021-08-12T09:23:18Z",
      "sizeBytes": 140491,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Neuro__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-340",
      "title": "HS_IGT_Radiology__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf",
      "updatedAt": "2021-08-12T09:23:57Z",
      "sizeBytes": 158062,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Radiology__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-341",
      "title": "HS_IGT_Surgery__FlexArm_Opragon_Brochure_Global__v2_20220321.pdf",
      "updatedAt": "2022-03-30T11:35:25Z",
      "sizeBytes": 3978777,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Surgery__FlexArm_Opragon_Brochure_Global__v2_20220321.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-342",
      "title": "HS_IGT_Surgery__FlexArm_Opragon_Brochure_Global__v2_20221105.pdf",
      "updatedAt": "2022-03-30T11:35:25Z",
      "sizeBytes": 3978777,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Surgery__FlexArm_Opragon_Brochure_Global__v2_20221105.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-343",
      "title": "HS- IGT- Azurion timeline R1-2-3_FINAL_Jan2026_1.pptx",
      "updatedAt": "2026-01-12T09:20:14Z",
      "sizeBytes": 673328,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS- IGT- Azurion timeline R1-2-3_FINAL_Jan2026_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-344",
      "title": "HS-IGT_Azurion R3.1 Marcom toolkit - May '25.pdf",
      "updatedAt": "2025-06-02T07:23:00Z",
      "sizeBytes": 1904849,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS-IGT_Azurion R3.1 Marcom toolkit - May '25.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-345",
      "title": "HS-IGT_Azurion sustainability-Leaflet HR_May '25.pdf",
      "updatedAt": "2025-05-20T10:10:49Z",
      "sizeBytes": 321667,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS-IGT_Azurion sustainability-Leaflet HR_May '25.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-346",
      "title": "HS-IGT_Azurion sustainability-leaflet LR-Digital_May '25.pdf",
      "updatedAt": "2025-05-20T10:11:03Z",
      "sizeBytes": 976690,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS-IGT_Azurion sustainability-leaflet LR-Digital_May '25.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-347",
      "title": "HS-IGT_Philips SmartCT R3.0_ MarCom Toolkit _ May'25.pdf",
      "updatedAt": "2025-06-03T13:46:31Z",
      "sizeBytes": 5045360,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS-IGT_Philips SmartCT R3.0_ MarCom Toolkit _ May'25.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-348",
      "title": "IGT clinical suites toolkit January 2021_1.pptx",
      "updatedAt": "2021-05-28T11:08:54Z",
      "sizeBytes": 16343690,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IGT clinical suites toolkit January 2021_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-349",
      "title": "IGT_MobileSurgery_StentBoost Mobile.pdf",
      "updatedAt": "2021-04-28T09:05:40Z",
      "sizeBytes": 2807616,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IGT_MobileSurgery_StentBoost Mobile.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-350",
      "title": "IGT-PLCEnrollment-CustomerLeaflet-EN-v01-w.pdf",
      "updatedAt": "2024-07-01T08:00:18Z",
      "sizeBytes": 1514898,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IGT-PLCEnrollment-CustomerLeaflet-EN-v01-w.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-351",
      "title": "IGT-WirelessFootSwitch-QuickReferenceCard-4522 204 12481-EN-v02-p.pdf",
      "updatedAt": "2023-01-11T12:22:15Z",
      "sizeBytes": 330530,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IGT-WirelessFootSwitch-QuickReferenceCard-4522 204 12481-EN-v02-p.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-352",
      "title": "IHE Integration Statement Azurion R3.0.pdf",
      "updatedAt": "2023-07-03T06:58:55Z",
      "sizeBytes": 660636,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Azurion R3.0.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-353",
      "title": "IHE Integration Statement Azurion R3.1.pdf",
      "updatedAt": "2024-07-16T12:11:05Z",
      "sizeBytes": 319609,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Azurion R3.1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-354",
      "title": "IHE Integration Statement Dynamic Coronary Roadmap R3.1.pdf",
      "updatedAt": "2023-07-27T16:30:35Z",
      "sizeBytes": 309580,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Dynamic Coronary Roadmap R3.1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-355",
      "title": "IHE Integration Statement Interventional Workspot R1.8.pdf",
      "updatedAt": "2023-09-29T11:46:52Z",
      "sizeBytes": 256837,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Interventional Workspot R1.8.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-356",
      "title": "IHE Integration Statement Interventional Workspot-R1.8.pdf",
      "updatedAt": "2024-08-20T17:15:50Z",
      "sizeBytes": 272962,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Interventional Workspot-R1.8.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-357",
      "title": "IHE Integration Statement Zenition 10 R8.1.pdf",
      "updatedAt": "2024-04-12T09:54:19Z",
      "sizeBytes": 656376,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Zenition 10 R8.1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-358",
      "title": "IHE Integration Statement Zenition 30 R6.1.pdf",
      "updatedAt": "2024-04-12T09:57:29Z",
      "sizeBytes": 656566,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Zenition 30 R6.1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-359",
      "title": "IHE Integration Statement Zention 90 R7.1.pdf",
      "updatedAt": "2024-04-12T10:00:10Z",
      "sizeBytes": 889136,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement Zention 90 R7.1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-360",
      "title": "IHE Integration Statement-StentBoost Live R2.1.pdf",
      "updatedAt": "2023-07-27T16:35:58Z",
      "sizeBytes": 273760,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE Integration Statement-StentBoost Live R2.1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-361",
      "title": "IHE_Conformance_Statement_StentBoost_Live.pdf",
      "updatedAt": "2016-11-24T09:40:45Z",
      "sizeBytes": 211315,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Conformance_Statement_StentBoost_Live.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-362",
      "title": "IHE_Integration_Statement_Allura_Centron_Release_1_0.pdf",
      "updatedAt": "2016-12-06T07:02:12Z",
      "sizeBytes": 260203,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Allura_Centron_Release_1_0.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-363",
      "title": "IHE_Integration_Statement_Allura_CV20_R1.pdf",
      "updatedAt": "2008-11-04T13:00:23Z",
      "sizeBytes": 107226,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Allura_CV20_R1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-364",
      "title": "IHE_Integration_Statement_Allura_Xper_FD10_Release_2.pdf",
      "updatedAt": "2005-11-16T11:30:53Z",
      "sizeBytes": 81131,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Allura_Xper_FD10_Release_2.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-365",
      "title": "IHE_Integration_Statement_Allura_Xper_Release_8_1.pdf",
      "updatedAt": "2016-12-06T07:04:47Z",
      "sizeBytes": 289979,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Allura_Xper_Release_8_1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-366",
      "title": "IHE_Integration_Statement_Azurion_2_0.pdf",
      "updatedAt": "2018-10-10T09:59:22Z",
      "sizeBytes": 634907,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Azurion_2_0.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-367",
      "title": "IHE_Integration_Statement_Azurion_2_1.pdf",
      "updatedAt": "2020-10-15T13:58:10Z",
      "sizeBytes": 653479,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Azurion_2_1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-368",
      "title": "IHE_Integration_Statement_Azurion_2_2.pdf",
      "updatedAt": "2021-06-30T12:55:00Z",
      "sizeBytes": 779891,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Azurion_2_2.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-369",
      "title": "IHE_Integration_Statement_Dynamic_Coronary_Roadmap_1_1.pdf",
      "updatedAt": "2017-07-14T08:53:02Z",
      "sizeBytes": 420701,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Dynamic_Coronary_Roadmap_1_1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-370",
      "title": "IHE_Integration_Statement_Dynamic_Coronary_Roadmap_R2_1.pdf",
      "updatedAt": "2018-12-11T10:15:42Z",
      "sizeBytes": 277052,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Dynamic_Coronary_Roadmap_R2_1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-371",
      "title": "IHE_Integration_Statement_IntelliSpace_Cardiovascular_3_2.pdf",
      "updatedAt": "2018-10-24T08:09:44Z",
      "sizeBytes": 604457,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_IntelliSpace_Cardiovascular_3_2.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-372",
      "title": "IHE_Integration_Statement_IntelliSpace_Cardiovascular_4_1.pdf",
      "updatedAt": "2019-05-02T12:45:26Z",
      "sizeBytes": 747042,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_IntelliSpace_Cardiovascular_4_1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-373",
      "title": "IHE_Integration_Statement_IntelliSpace_Cardiovascular_4_2.pdf",
      "updatedAt": "2019-11-27T12:43:05Z",
      "sizeBytes": 735455,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_IntelliSpace_Cardiovascular_4_2.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-374",
      "title": "IHE_Integration_Statement_IntelliSpace_Cardiovascular_5_1.pdf",
      "updatedAt": "2020-06-19T09:43:02Z",
      "sizeBytes": 618971,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_IntelliSpace_Cardiovascular_5_1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-375",
      "title": "IHE_Integration_Statement_Interventional_Workspot_1_5.pdf",
      "updatedAt": "2020-02-28T09:41:03Z",
      "sizeBytes": 555792,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Interventional_Workspot_1_5.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-376",
      "title": "IHE_Integration_Statement_Interventional_Workspot_1_6.pdf",
      "updatedAt": "2020-10-15T13:55:08Z",
      "sizeBytes": 715692,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_Interventional_Workspot_1_6.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-377",
      "title": "IHE_Integration_Statement_StentBoost_Live_1_1.pdf",
      "updatedAt": "2017-07-22T19:50:54Z",
      "sizeBytes": 408744,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_StentBoost_Live_1_1.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-378",
      "title": "IHE_Integration_Statement_StentBoost_Live_R1_2.pdf",
      "updatedAt": "2018-12-11T10:16:51Z",
      "sizeBytes": 270415,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_StentBoost_Live_R1_2.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-379",
      "title": "IHE_Integration_Statement_UNIQ_Release_1_0.pdf",
      "updatedAt": "2016-12-06T07:09:49Z",
      "sizeBytes": 289644,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_UNIQ_Release_1_0.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-380",
      "title": "IHE_Integration_Statement_XtraVision_R8_3.pdf",
      "updatedAt": "2011-03-09T11:56:55Z",
      "sizeBytes": 85673,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/IHE_Integration_Statement_XtraVision_R8_3.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-381",
      "title": "INFOGRAPHIC_Stroke_297x210_PRINT_HR.pdf",
      "updatedAt": "2024-07-02T13:54:33Z",
      "sizeBytes": 692026,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/INFOGRAPHIC_Stroke_297x210_PRINT_HR.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-382",
      "title": "Karolinska case study slide - Prostate cancer care_1.pptx",
      "updatedAt": "2022-04-15T10:37:28Z",
      "sizeBytes": 2388667,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Karolinska case study slide - Prostate cancer care_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-383",
      "title": "Lateral_stand___4522_901_00140___Passport.pdf",
      "updatedAt": "2006-11-20T20:00:07Z",
      "sizeBytes": 176542,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Lateral_stand___4522_901_00140___Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-384",
      "title": "LCD_Displays_9919_320_5112x_Passport.pdf",
      "updatedAt": "2006-11-20T19:56:34Z",
      "sizeBytes": 157267,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/LCD_Displays_9919_320_5112x_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-385",
      "title": "LCD_Displays_9919_320_5117x_Passport.pdf",
      "updatedAt": "2006-11-20T19:59:01Z",
      "sizeBytes": 145479,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/LCD_Displays_9919_320_5117x_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-386",
      "title": "M-Cabinet_Passport.pdf",
      "updatedAt": "2006-11-20T20:05:57Z",
      "sizeBytes": 127414,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/M-Cabinet_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-387",
      "title": "MASTER_HS-IGT_Azurion-Legacy of continues innovation_themed topics pptx_Aug 25_1.pptx",
      "updatedAt": "2025-08-27T09:48:31Z",
      "sizeBytes": 41608849,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/MASTER_HS-IGT_Azurion-Legacy of continues innovation_themed topics pptx_Aug 25_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-388",
      "title": "MAT-5874_Philips_Dose_Management_Radiation_Safety_IGT_Nov2025.pdf",
      "updatedAt": "2025-11-20T10:29:48Z",
      "sizeBytes": 1294816,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/MAT-5874_Philips_Dose_Management_Radiation_Safety_IGT_Nov2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-389",
      "title": "MAT-5874_Philips_Radiation Safety & Dose Management_nov_2025_1.pptx",
      "updatedAt": "2025-11-21T14:38:48Z",
      "sizeBytes": 3404622,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/MAT-5874_Philips_Radiation Safety & Dose Management_nov_2025_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-390",
      "title": "MAT4612_Azurion_with_SmartIQ_product_overview.pdf",
      "updatedAt": "2026-09-11T07:03:11Z",
      "sizeBytes": null,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/MAT4612_Azurion_with_SmartIQ_product_overview.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-391",
      "title": "MCS___4522_901_00530.pdf",
      "updatedAt": "2006-10-27T13:25:12Z",
      "sizeBytes": 88303,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/MCS___4522_901_00530.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-392",
      "title": "MoS_IB_conversation_ starter_1.pptx",
      "updatedAt": "2024-10-28T10:07:09Z",
      "sizeBytes": 4487566,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/MoS_IB_conversation_ starter_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-393",
      "title": "MR-CT Roadmap 2013 03.pdf",
      "updatedAt": "2013-03-20T11:15:44Z",
      "sizeBytes": 270804,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/MR-CT Roadmap 2013 03.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-394",
      "title": "Nicolab - StrokeViewer flyer (final).pdf",
      "updatedAt": "2022-06-16T13:42:14Z",
      "sizeBytes": 4424130,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Nicolab - StrokeViewer flyer (final).pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-395",
      "title": "Nicolab FAQ.pdf",
      "updatedAt": "2021-09-24T10:11:20Z",
      "sizeBytes": 125496,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Nicolab FAQ.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-396",
      "title": "NL16-P00000032_LEAFLET_IGT_Learning_A4_digital.pdf",
      "updatedAt": "2025-04-10T14:14:06Z",
      "sizeBytes": 584108,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/NL16-P00000032_LEAFLET_IGT_Learning_A4_digital.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-397",
      "title": "NL16-P00000216_LEAFLET_Azurion_DCR_A4_print_HR_no_cropmarks.pdf",
      "updatedAt": "2025-07-01T09:15:17Z",
      "sizeBytes": 1355238,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/NL16-P00000216_LEAFLET_Azurion_DCR_A4_print_HR_no_cropmarks.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-398",
      "title": "NL16-P00000216_LEAFLET_Azurion_GLOBAL_A4_digital.pdf",
      "updatedAt": "2025-04-11T08:28:57Z",
      "sizeBytes": 515073,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/NL16-P00000216_LEAFLET_Azurion_GLOBAL_A4_digital.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-399",
      "title": "NL16-P00000216_LEAFLET_Azurion_NAM_A4_digital.pdf",
      "updatedAt": "2025-04-11T08:09:18Z",
      "sizeBytes": 524791,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/NL16-P00000216_LEAFLET_Azurion_NAM_A4_digital.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-400",
      "title": "One IGT Web - Market Toolkit_1.pptx",
      "updatedAt": "2021-04-28T14:03:52Z",
      "sizeBytes": 3876456,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/One IGT Web - Market Toolkit_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-401",
      "title": "Philips Azurion Energy consumption presentation_april2023_1.pptx",
      "updatedAt": "2023-03-31T11:40:19Z",
      "sizeBytes": 15596129,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Azurion Energy consumption presentation_april2023_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-402",
      "title": "Philips Azurion Energy consumption presentation_april2023_DE_1.pptx",
      "updatedAt": "2023-08-09T11:33:16Z",
      "sizeBytes": 14688953,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Azurion Energy consumption presentation_april2023_DE_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-403",
      "title": "Philips Azurion FlexArm proofpoint deck FINAL 031219_1.pptx",
      "updatedAt": "2019-12-03T10:56:59Z",
      "sizeBytes": 10901272,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Azurion FlexArm proofpoint deck FINAL 031219_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-404",
      "title": "Philips Azurion monitor boom solutions for FlexVision_1.pptx",
      "updatedAt": "2023-12-18T09:28:21Z",
      "sizeBytes": 4338032,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Azurion monitor boom solutions for FlexVision_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-405",
      "title": "Philips Press Release_Global IGT Launch_FINAL_FINAL.docx",
      "updatedAt": "2017-02-20T21:07:00Z",
      "sizeBytes": 746075,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Press Release_Global IGT Launch_FINAL_FINAL.docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-406",
      "title": "Philips Press Release_Global Philips Azurion Launch_One pager.docx",
      "updatedAt": "2017-04-12T13:07:00Z",
      "sizeBytes": 25491,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Press Release_Global Philips Azurion Launch_One pager.docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-407",
      "title": "Philips Vesselnavigator 2014 12.pdf",
      "updatedAt": "2014-12-17T13:42:24Z",
      "sizeBytes": 398940,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Vesselnavigator 2014 12.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-408",
      "title": "Philips Zenition messaging roll up banners.pdf",
      "updatedAt": "2019-02-26T15:30:21Z",
      "sizeBytes": 19445161,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Zenition messaging roll up banners.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-409",
      "title": "Philips Zenition Sustainability Brochure.pdf",
      "updatedAt": "2024-08-13T08:22:28Z",
      "sizeBytes": 1545945,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips Zenition Sustainability Brochure.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-410",
      "title": "Philips__OneIGT_Presentation_Global_Non-US_FINAL_Customer facing_MAT6066V1 2.pptx",
      "updatedAt": "2026-09-07T08:28:14Z",
      "sizeBytes": 98086555,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips__OneIGT_Presentation_Global_Non-US_FINAL_Customer facing_MAT6066V1 2.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-411",
      "title": "Philips_Azurion_FlexArm_Economic_Value_1pager_FINAL.pdf",
      "updatedAt": "2019-12-16T11:18:47Z",
      "sizeBytes": 2061731,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_Azurion_FlexArm_Economic_Value_1pager_FINAL.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-412",
      "title": "Philips_Brochure_EchoNavigator_452299104031.pdf",
      "updatedAt": "2014-07-22T14:55:44Z",
      "sizeBytes": 1602488,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_Brochure_EchoNavigator_452299104031.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-413",
      "title": "Philips_Corindus_CorPath_Brochure.pdf",
      "updatedAt": "2013-03-25T19:37:13Z",
      "sizeBytes": 1016037,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_Corindus_CorPath_Brochure.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-414",
      "title": "Philips_IGT_Zenition_StentBoost Mobile_Customer presentation_1.pptx",
      "updatedAt": "2021-05-31T10:26:20Z",
      "sizeBytes": 23627814,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_IGT_Zenition_StentBoost Mobile_Customer presentation_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-415",
      "title": "Philips_SmartIQ_Technology_Product_Brochure_MAT-6197.pdf",
      "updatedAt": "2026-09-11T07:03:10Z",
      "sizeBytes": null,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/Philips_SmartIQ_Technology_Product_Brochure_MAT-6197.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-416",
      "title": "Philips_XperGuide_Ablation_clinical_case_report.pdf",
      "updatedAt": "2024-06-18T20:34:11Z",
      "sizeBytes": 176407,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_XperGuide_Ablation_clinical_case_report.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-417",
      "title": "Philips_Zenition_roll-up_banners_freestanding_product_HR.pdf",
      "updatedAt": "2020-01-07T16:11:58Z",
      "sizeBytes": 26989131,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_Zenition_roll-up_banners_freestanding_product_HR.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-418",
      "title": "Philips_Zenition_roll-up_banners_update_HR.pdf",
      "updatedAt": "2020-01-07T16:13:15Z",
      "sizeBytes": 27088566,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_Zenition_roll-up_banners_update_HR.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-419",
      "title": "Philips-Azurion-Whitepaper-EV-FINAL.pdf",
      "updatedAt": "2019-12-20T14:53:25Z",
      "sizeBytes": 1267114,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips-Azurion-Whitepaper-EV-FINAL.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-420",
      "title": "PhilipsCardiology_MessagingGuide_1.pptx",
      "updatedAt": "2021-06-08T04:07:47Z",
      "sizeBytes": 53563020,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/PhilipsCardiology_MessagingGuide_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-421",
      "title": "PhilipsEchonavigator.pdf",
      "updatedAt": "2014-07-21T12:04:41Z",
      "sizeBytes": 1609300,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/PhilipsEchonavigator.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-422",
      "title": "Pre-Launch_Landingpage_1_Info (Readme).docx",
      "updatedAt": "2017-01-04T09:02:00Z",
      "sizeBytes": 78936,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Pre-Launch_Landingpage_1_Info (Readme).docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-423",
      "title": "Product_overview_VesselNavigator.pdf",
      "updatedAt": "2015-10-19T20:02:16Z",
      "sizeBytes": 6111344,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Product_overview_VesselNavigator.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-424",
      "title": "Reveal by Ronald Tabaksblat_Final.docx",
      "updatedAt": "2017-01-12T13:00:00Z",
      "sizeBytes": 24542,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Reveal by Ronald Tabaksblat_Final.docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-425",
      "title": "SHD IVP Customer Deck_1.pptx",
      "updatedAt": "2021-05-14T08:56:19Z",
      "sizeBytes": 24676502,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/SHD IVP Customer Deck_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-426",
      "title": "Staging links to cardiology and IVP website pages_1.pptx",
      "updatedAt": "2021-05-14T09:05:53Z",
      "sizeBytes": 49259,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Staging links to cardiology and IVP website pages_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-427",
      "title": "Stroke Advocacy Presentation Dec 2024_1.pptx",
      "updatedAt": "2024-12-05T10:49:51Z",
      "sizeBytes": 51511625,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Stroke Advocacy Presentation Dec 2024_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-428",
      "title": "Surgery Campaign Toolkit I, 2023_Z10_1.pptx",
      "updatedAt": "2023-05-31T09:25:47Z",
      "sizeBytes": 63201849,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Surgery Campaign Toolkit I, 2023_Z10_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-429",
      "title": "Surgery Campaign Toolkit II, 2023_Z10 and Z30_1.pptx",
      "updatedAt": "2023-08-29T10:24:23Z",
      "sizeBytes": 71467665,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Surgery Campaign Toolkit II, 2023_Z10 and Z30_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-430",
      "title": "Surgery Campaign Toolkit II, 2023_Z10 and Z30_update_1.pptx",
      "updatedAt": "2023-10-12T10:52:19Z",
      "sizeBytes": 76470273,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Surgery Campaign Toolkit II, 2023_Z10 and Z30_update_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-431",
      "title": "Surgery_Customer Presentation_1.pptx",
      "updatedAt": "2022-04-01T14:40:44Z",
      "sizeBytes": 9225773,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Surgery_Customer Presentation_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-432",
      "title": "User_Interfaces___4522_901_00540__Passport.pdf",
      "updatedAt": "2006-11-20T19:54:54Z",
      "sizeBytes": 115070,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/User_Interfaces___4522_901_00540__Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-433",
      "title": "Veradius_Recycling_Passport.pdf",
      "updatedAt": "2013-02-07T14:57:13Z",
      "sizeBytes": 1249692,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Veradius_Recycling_Passport.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-434",
      "title": "World Heart Day Article FINAL.docx",
      "updatedAt": "2021-09-28T13:31:00Z",
      "sizeBytes": 38373,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/World Heart Day Article FINAL.docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-435",
      "title": "World Heart Day Article_FINAL.docx",
      "updatedAt": "2021-09-24T14:31:00Z",
      "sizeBytes": 37510,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/World Heart Day Article_FINAL.docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-436",
      "title": "Zenition 10 Customer Presentation_1.pptx",
      "updatedAt": "2023-03-23T09:13:12Z",
      "sizeBytes": 23183588,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 10 Customer Presentation_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-437",
      "title": "Zenition 10 Marcom Toolkit_May'25.pdf",
      "updatedAt": "2025-05-06T11:15:47Z",
      "sizeBytes": 1517300,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 10 Marcom Toolkit_May'25.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-438",
      "title": "Zenition 10 messaging playbook HR.pdf",
      "updatedAt": "2023-03-20T12:33:43Z",
      "sizeBytes": 14290013,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 10 messaging playbook HR.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-439",
      "title": "Zenition 10 Product Brochure HR.pdf",
      "updatedAt": "2023-03-20T13:22:10Z",
      "sizeBytes": 10874152,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 10 Product Brochure HR.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-440",
      "title": "Zenition 10 Product Brochure LR.pdf.pdf",
      "updatedAt": "2023-03-20T13:22:26Z",
      "sizeBytes": 2150072,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 10 Product Brochure LR.pdf.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-441",
      "title": "Zenition 10 Roll-ups_85x200cm_PRINT.pdf",
      "updatedAt": "2023-03-21T08:18:28Z",
      "sizeBytes": 10126916,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 10 Roll-ups_85x200cm_PRINT.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-442",
      "title": "Zenition 10_OnePager_Orthopedics.pdf",
      "updatedAt": "2023-07-04T08:29:28Z",
      "sizeBytes": 830480,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 10_OnePager_Orthopedics.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-443",
      "title": "Zenition 30 Brochure - Full Version - NA.pdf",
      "updatedAt": "2024-02-28T03:43:47Z",
      "sizeBytes": 8324080,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Brochure - Full Version - NA.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-444",
      "title": "Zenition 30 Brochure - Orthopedics Surgery - NA.pdf",
      "updatedAt": "2024-02-28T03:51:15Z",
      "sizeBytes": 1089673,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Brochure - Orthopedics Surgery - NA.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-445",
      "title": "Zenition 30 Customer Presentation_1.pptx",
      "updatedAt": "2024-08-21T09:01:55Z",
      "sizeBytes": 81518225,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Customer Presentation_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-446",
      "title": "Zenition 30 Marcom Toolkit_Aug'23.pdf",
      "updatedAt": "2023-08-23T06:40:33Z",
      "sizeBytes": 4939570,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Marcom Toolkit_Aug'23.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-447",
      "title": "Zenition 30 Messaging Playbook.pdf",
      "updatedAt": "2024-08-20T13:47:46Z",
      "sizeBytes": 13557205,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Messaging Playbook.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-448",
      "title": "Zenition 30 Ortho One Pager.pdf",
      "updatedAt": "2024-08-20T14:03:32Z",
      "sizeBytes": 1020341,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Ortho One Pager.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-449",
      "title": "Zenition 30 Pain Management One Pager.pdf",
      "updatedAt": "2024-08-20T14:16:28Z",
      "sizeBytes": 901383,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Pain Management One Pager.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-450",
      "title": "Zenition 30 Product Brochure.pdf",
      "updatedAt": "2024-08-13T14:34:58Z",
      "sizeBytes": 1731196,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Product Brochure.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-451",
      "title": "Zenition 30 Roll-ups_85x200cm_PRINT.pdf",
      "updatedAt": "2023-03-21T08:19:44Z",
      "sizeBytes": 21077555,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Roll-ups_85x200cm_PRINT.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-452",
      "title": "Zenition 30 Usability Claims One Pager.pdf",
      "updatedAt": "2024-08-20T14:24:48Z",
      "sizeBytes": 1309046,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Usability Claims One Pager.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-453",
      "title": "Zenition 50_70_EcoPassportUpdate_2024.pdf",
      "updatedAt": "2024-04-24T08:48:44Z",
      "sizeBytes": 202732,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 50_70_EcoPassportUpdate_2024.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-454",
      "title": "Zenition 50_EcoPassportUpdate_2024.pdf",
      "updatedAt": "2024-10-17T06:42:50Z",
      "sizeBytes": 220490,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 50_EcoPassportUpdate_2024.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-455",
      "title": "Zenition 70 Product Brochure_Update_July_2024.pdf",
      "updatedAt": "2024-07-23T14:51:28Z",
      "sizeBytes": 16525688,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 70 Product Brochure_Update_July_2024.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-456",
      "title": "Zenition 70_EcoPassportUpdate_2024.pdf",
      "updatedAt": "2024-10-17T06:43:20Z",
      "sizeBytes": 215929,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 70_EcoPassportUpdate_2024.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-457",
      "title": "Zenition 70_FD 30 x 30_Product Brochure_ LR_Updated.pdf",
      "updatedAt": "2022-02-23T09:48:59Z",
      "sizeBytes": 1177884,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 70_FD 30 x 30_Product Brochure_ LR_Updated.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-458",
      "title": "Zenition 90 Motorized and Zenition 90 toolkit_updated_Jan_2026 (1).pdf",
      "updatedAt": "2026-01-08T11:15:25Z",
      "sizeBytes": 3527407,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 90 Motorized and Zenition 90 toolkit_updated_Jan_2026 (1).pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-459",
      "title": "Zenition 90 Motorized Eco passport September 2025.pdf",
      "updatedAt": "2025-09-29T08:17:10Z",
      "sizeBytes": 209449,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 90 Motorized Eco passport September 2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-460",
      "title": "Zenition 90 Motorized Vascular One Pager_June_2025.pdf",
      "updatedAt": "2025-06-23T12:42:18Z",
      "sizeBytes": 1429795,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 90 Motorized Vascular One Pager_June_2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-461",
      "title": "Zenition 90 Non Motorized Eco passport Sept 2025.pdf",
      "updatedAt": "2025-09-26T10:57:11Z",
      "sizeBytes": 244234,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 90 Non Motorized Eco passport Sept 2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-462",
      "title": "Zenition launch video on screen copy and voice over.docx",
      "updatedAt": "2019-02-18T14:33:00Z",
      "sizeBytes": 36126,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition launch video on screen copy and voice over.docx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-463",
      "title": "Zenition Marcom Toolkit_April2024_1.pptx",
      "updatedAt": "2024-04-29T05:47:37Z",
      "sizeBytes": 80764222,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition Marcom Toolkit_April2024_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-464",
      "title": "Zenition Portfolio Toolkit 1.0_1.pptx",
      "updatedAt": "2024-09-17T07:15:45Z",
      "sizeBytes": 11455097,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition Portfolio Toolkit 1.0_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-465",
      "title": "Zenition_10_Ecopassport_May_2025.pdf",
      "updatedAt": "2025-05-06T06:42:47Z",
      "sizeBytes": 203167,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_10_Ecopassport_May_2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-466",
      "title": "Zenition_30_Specification_Sheet_Dec_2025.pdf",
      "updatedAt": "2025-12-05T13:22:20Z",
      "sizeBytes": 11230440,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_30_Specification_Sheet_Dec_2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-467",
      "title": "Zenition_90 Motorized playbook_June_2025.pdf",
      "updatedAt": "2025-06-05T07:51:50Z",
      "sizeBytes": 4616715,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_90 Motorized playbook_June_2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-468",
      "title": "Zenition_90_Motorized_Brochure_May_2025.pdf",
      "updatedAt": "2025-05-08T07:34:03Z",
      "sizeBytes": 3443450,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_90_Motorized_Brochure_May_2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-469",
      "title": "Zenition_90_Non_Motorized_Brochure_May_2025.pdf",
      "updatedAt": "2025-05-08T07:36:55Z",
      "sizeBytes": 3322852,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_90_Non_Motorized_Brochure_May_2025.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-470",
      "title": "Zenition_CMOS_ASI_Whitpaper.pdf",
      "updatedAt": "2024-08-08T06:56:55Z",
      "sizeBytes": 1790345,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_CMOS_ASI_Whitpaper.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-471",
      "title": "Zenition_MetalSmart_case_study.pdf",
      "updatedAt": "2024-09-11T10:26:09Z",
      "sizeBytes": 5800085,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_MetalSmart_case_study.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-472",
      "title": "Zenition_Technology_Maximizer_Plus.pdf",
      "updatedAt": "2020-11-20T13:52:07Z",
      "sizeBytes": 725236,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_Technology_Maximizer_Plus.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-473",
      "title": "Zenition_Technology_Maximizer-Essential.pdf",
      "updatedAt": "2021-01-12T10:48:02Z",
      "sizeBytes": 698017,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition_Technology_Maximizer-Essential.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-474",
      "title": "Zenition70_FD 30 x 30_Customer Presentation_updated_March 2022_1.pptx",
      "updatedAt": "2022-03-03T06:21:17Z",
      "sizeBytes": 6635852,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition70_FD 30 x 30_Customer Presentation_updated_March 2022_1.pptx?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-475",
      "title": "Zenition70_MobileSurgery_TSM_Brochure.pdf",
      "updatedAt": "2020-04-14T06:49:17Z",
      "sizeBytes": 953959,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition70_MobileSurgery_TSM_Brochure.pdf?web=1",
      "source": "site-search"
    },
    {
      "id": "sp-manifest-476",
      "title": "Zenition70_MobileSurgery_TSM_Customer_Slides_1.pptx",
      "updatedAt": "2022-03-15T06:59:04Z",
      "sizeBytes": 4229105,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition70_MobileSurgery_TSM_Customer_Slides_1.pptx?web=1",
      "source": "site-search"
    }
  ]
};
