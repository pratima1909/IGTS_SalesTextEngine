window.SHAREPOINT_PRODUCT_FACTS = {
  "metadata": {
    "sourceName": "IGT-S Strategy Execution & Transformation SharePoint",
    "folderName": "Data Analytics/SSA_PAL_Filterted",
    "folderUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FIGT%2DSStrategyExecutionTransformation%2FShared%20Documents%2FData%20Analytics%2FSSA%5FPAL%5FFilterted",
    "snapshotDate": "2026-09-28",
    "inspectedFileCount": 476,
    "observedFileCount": 476,
    "listedFileCount": 200,
    "continuationAvailable": true,
    "documentCount": 65,
    "factCount": 116,
    "selectionPolicy": "Every observed file is retained in the source manifest. Draft claims use only content-indexed English product documentation; duplicate, testimonial, research, manual, incompatible-language, market-restricted, disclaimer and low-quality OCR passages are excluded.",
    "searchDiscoveredFileCount": 276,
    "contentReadDocumentCount": 65,
    "refreshNote": "The 2026-09-28 refresh expanded the register to 476 unique observed files and 65 successfully content-read documents. Files that were throttled, unsupported or not yet content-indexed remain register-only and never contribute claims."
  },
  "documents": [
    {
      "id": "sp-azurion-7",
      "title": "452299122941_Philips_Azurion_7_brochure_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:33Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299122941_Philips_Azurion_7_brochure_FINAL.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-azurion-3",
      "title": "452299122381_Philips_Azurion_3_brochure_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:31Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299122381_Philips_Azurion_3_brochure_FINAL.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-smartct",
      "title": "191028_SmartCT NPI Leave Behind_A5_LS_03.pdf",
      "updatedAt": "2026-06-26T04:42:22Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/191028_SmartCT%20NPI%20Leave%20Behind_A5_LS_03.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-doseaware",
      "title": "4522 203 75734 DoseAware_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:57Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2075734%20DoseAware_en-US.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-3d-roadmap",
      "title": "4522 203 80001_3D Roadmap_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:09Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2080001_3D%20Roadmap_en-US.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-stentboost-live",
      "title": "4523 001 00401_StentBoost Live_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:23Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2000401_StentBoost%20Live_en-US.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-dynamic-coronary-roadmap",
      "title": "4523 001 00771_Dynamic Coronary Roadmap_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:24Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2000771_Dynamic%20Coronary%20Roadmap_en-US.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-clarifeye",
      "title": "452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final (1).pdf",
      "updatedAt": "2026-06-26T04:46:59Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final%20(1).pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-azurion-7-m20-flexarm",
      "title": "452299178781_MAT-5693_Philips_Azurion_7_M20_Monoplane_Ceiling_Mounted_with_FlexArm_Specifications_LR.pdf",
      "updatedAt": "2026-06-26T04:47:17Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299178781_MAT-5693_Philips_Azurion_7_M20_Monoplane_Ceiling_Mounted_with_FlexArm_Specifications_LR.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-echonavigator",
      "title": "4523 001 00051_EchoNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:22Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4523%20001%2000051_EchoNavigator_en-US.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-clarityiq-cardio-article",
      "title": "HS_IGT_Cardiology__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf",
      "updatedAt": "2026-06-26T07:13:19Z",
      "market": "Global, non-US",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/HS_IGT_Cardiology__Azurion_ClarityIQ_Article_Global-Non-US__v1_20240620.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-clarityiq-global-whitepaper",
      "title": "HS_IGT___Azurion_ClarityIQ_White-Paper_Global-Non-US__v2_20220318.pdf",
      "updatedAt": "2026-06-26T07:13:13Z",
      "market": "Global, non-US",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_ClarityIQ_White-Paper_Global-Non-US__v2_20220318.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-clarityiq-us-whitepaper",
      "title": "HS_IGT___Azurion_ClarityIQ_White-Paper_US__v1_20220318.pdf",
      "updatedAt": "2026-06-26T07:13:13Z",
      "market": "US",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/HS_IGT___Azurion_ClarityIQ_White-Paper_US__v1_20220318.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-smartiq-brochure",
      "title": "Philips_SmartIQ_Technology_Product_Brochure_MAT-6197.pdf",
      "updatedAt": "2026-09-11T07:03:10Z",
      "market": "Global, check local availability",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/Philips_SmartIQ_Technology_Product_Brochure_MAT-6197.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-azurion-smartiq-overview",
      "title": "MAT4612_Azurion_with_SmartIQ_product_overview.pdf",
      "updatedAt": "2026-09-11T07:03:11Z",
      "market": "Global, non-US",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/MAT4612_Azurion_with_SmartIQ_product_overview.pdf?web=1",
      "indexMode": "curated"
    },
    {
      "id": "sp-indexed-16",
      "title": "131120_Neurosuite_Brochure_LR_spread.pdf",
      "updatedAt": "2026-06-26T04:42:20Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/131120_Neurosuite_Brochure_LR_spread.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-17",
      "title": "200214_Evolution messaging guide_A4_09_Final.pdf",
      "updatedAt": "2026-06-26T04:42:23Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/200214_Evolution%20messaging%20guide_A4_09_Final.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-18",
      "title": "210714_Azurion FlexArm Opragon leaflet MA_03 HR.pdf",
      "updatedAt": "2026-06-26T04:42:25Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/210714_Azurion%20FlexArm%20Opragon%20leaflet%20MA_03%20HR.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-19",
      "title": "210714_Azurion FlexArm Opragon leaflet MA_03 LR.pdf",
      "updatedAt": "2026-06-26T04:42:24Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/210714_Azurion%20FlexArm%20Opragon%20leaflet%20MA_03%20LR.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-20",
      "title": "240501_03 Azurion Tech Max Program Leaflet_NA_L&R approved.pdf",
      "updatedAt": "2026-06-26T04:42:26Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/240501_03%20Azurion%20Tech%20Max%20Program%20Leaflet_NA_L%26R%20approved.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-21",
      "title": "4322 070 33942_AltaTrack_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:54Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2033942_AltaTrack_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-22",
      "title": "4322 070 36041_LumiGuide Equipment _en-US.pdf",
      "updatedAt": "2026-06-26T04:40:55Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2036041_LumiGuide%20Equipment%20_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-23",
      "title": "4322 070 38863 2023-06 LumiGuide Navigation Wire EN-US.pdf",
      "updatedAt": "2026-06-26T04:40:56Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4322%20070%2038863%202023-06%20LumiGuide%20Navigation%20Wire%20EN-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-24",
      "title": "4522 203 58523_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:57Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2058523_Philips%20Hemodynamic%20Application_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-25",
      "title": "4522 203 66871_SmartCT_en-US.pdf",
      "updatedAt": "2026-06-26T04:40:58Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2066871_SmartCT_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-26",
      "title": "4522 203 78552_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:01Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078552_Azurion_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-27",
      "title": "4522 203 78553_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:03Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078553_Azurion_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-28",
      "title": "4522 203 78554_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:04Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078554_Azurion_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-29",
      "title": "4522 203 78555_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:05Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078555_Azurion_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-30",
      "title": "4522 203 78556_Azurion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:07Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078556_Azurion_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-31",
      "title": "4522 203 78931_ClarifEye_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:06Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078931_ClarifEye_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-32",
      "title": "4522 203 78932_ClarifEye_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:06Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078932_ClarifEye_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-33",
      "title": "4522 203 78933_ClarifEye_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:09Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2078933_ClarifEye_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-34",
      "title": "4522 203 79301_Interventional Workspot_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:09Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2079301_Interventional%20Workspot_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-35",
      "title": "4522 203 79651_3D-RA_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:08Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2079651_3D-RA_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-36",
      "title": "4522 203 80351_MR-CT Roadmap_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:11Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2080351_MR-CT%20Roadmap_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-37",
      "title": "4522 203 80701_XperCT Dual_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:12Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2080701_XperCT%20Dual_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-38",
      "title": "4522 203 81051_XperGuide_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:13Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2081051_XperGuide_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-39",
      "title": "4522 203 81401_EmboGuide_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:12Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2081401_EmboGuide_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-40",
      "title": "4522 203 81751_StentBoost_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:14Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2081751_StentBoost_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-41",
      "title": "4522 203 82451_VesselNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:15Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2082451_VesselNavigator_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-42",
      "title": "4522 203 82801_AneurysmFlow_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:15Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2082801_AneurysmFlow_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-43",
      "title": "4522 203 83151_EP navigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:17Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2083151_EP%20navigator_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-44",
      "title": "4522 203 83501_HeartNavigator_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:16Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2083501_HeartNavigator_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-45",
      "title": "4522 203 83851_SmartPerfusion_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:17Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2083851_SmartPerfusion_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-46",
      "title": "4522 203 85721_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:17Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2085721_Philips%20Hemodynamic%20Application_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-47",
      "title": "4522 203 85722_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:20Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2085722_Philips%20Hemodynamic%20Application_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-48",
      "title": "4522 203 85723_Philips Hemodynamic Application_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:20Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20203%2085723_Philips%20Hemodynamic%20Application_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-49",
      "title": "4522 204 14481-QuickReferenceCard-PatientTable_en-US.pdf",
      "updatedAt": "2026-06-26T04:41:20Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522%20204%2014481-QuickReferenceCard-PatientTable_en-US.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-50",
      "title": "4522_991_17551_Philips_brochure_Neurosuite_FINAL.pdf",
      "updatedAt": "2026-06-26T04:41:20Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522_991_17551_Philips_brochure_Neurosuite_FINAL.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-51",
      "title": "4522_991_20861_Philips_Brochure_DCR_and_Stentboost.pdf",
      "updatedAt": "2026-06-26T04:41:23Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/4522_991_20861_Philips_Brochure_DCR_and_Stentboost.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-52",
      "title": "452296278537_LR_EPnav_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:26Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296278537_LR_EPnav_brochure.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-53",
      "title": "452299108181_Philips_Allura_Centron_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:28Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299108181_Philips_Allura_Centron_brochure.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-54",
      "title": "452299132691_Mobile_Surgery_Solutions_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:43Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299132691_Mobile_Surgery_Solutions_brochure.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-55",
      "title": "452299165021_Philips_Spine_suite_brochure_V10_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:55Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299165021_Philips_Spine_suite_brochure_V10_FINAL.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-56",
      "title": "452299168991_Philips_Neuro_Suite_brochure_Global incl US_final.pdf",
      "updatedAt": "2026-06-26T04:47:00Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299168991_Philips_Neuro_Suite_brochure_Global%20incl%20US_final.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-57",
      "title": "452299172491_Hybrid OR product brochure_LR.pdf",
      "updatedAt": "2026-06-26T04:47:08Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299172491_Hybrid%20OR%20product%20brochure_LR.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-58",
      "title": "452299183751_Philips_SmartCT_brochure_HR_NC.pdf",
      "updatedAt": "2026-06-26T04:47:55Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299183751_Philips_SmartCT_brochure_HR_NC.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-59",
      "title": "452299176331__Philips_Zenition_50_brochure_May 2022_Updated_LR.pdf",
      "updatedAt": "2026-06-26T04:47:12Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299176331__Philips_Zenition_50_brochure_May%202022_Updated_LR.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-60",
      "title": "Zenition 70 Product Brochure_Update_July_2024.pdf",
      "updatedAt": "2026-06-26T11:25:17Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/Zenition%2070%20Product%20Brochure_Update_July_2024.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-61",
      "title": "Zenition 10 Product Brochure LR.pdf.pdf",
      "updatedAt": "2026-06-26T11:24:59Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/Zenition%2010%20Product%20Brochure%20LR.pdf.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-62",
      "title": "Zenition 30 Product Brochure.pdf",
      "updatedAt": "2026-06-26T11:25:09Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/Zenition%2030%20Product%20Brochure.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-63",
      "title": "Zenition_90_Motorized_Brochure_May_2025.pdf",
      "updatedAt": "2026-06-26T11:25:25Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/Zenition_90_Motorized_Brochure_May_2025.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-64",
      "title": "Zenition_90_Non_Motorized_Brochure_May_2025.pdf",
      "updatedAt": "2026-06-26T11:25:27Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/Zenition_90_Non_Motorized_Brochure_May_2025.pdf?web=1",
      "indexMode": "content-extracted"
    },
    {
      "id": "sp-indexed-65",
      "title": "452299181971_Philips_Azurion_7_brochure_July 2023.pdf",
      "updatedAt": "2026-06-26T04:47:45Z",
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299181971_Philips_Azurion_7_brochure_July%202023.pdf?web=1",
      "indexMode": "content-extracted"
    }
  ],
  "facts": [
    {
      "sourceId": "sp-azurion-7",
      "product": "Azurion 7",
      "topic": "platform",
      "text": "Azurion 7 is an image guided therapy platform designed to support a wide range of routine and complex procedures."
    },
    {
      "sourceId": "sp-azurion-7",
      "product": "Azurion 7",
      "topic": "multi-workspot technology",
      "text": "ConnectOS provides real-time multi-workspot technology designed specifically for the Azurion interventional suite."
    },
    {
      "sourceId": "sp-azurion-7",
      "product": "Azurion 7",
      "topic": "workflow",
      "text": "Flexible workspots enable applications to be viewed, controlled and run where they are needed in the interventional suite."
    },
    {
      "sourceId": "sp-azurion-7",
      "product": "Azurion 7",
      "topic": "clinical workflow",
      "text": "Advanced interventional tools are integrated into Azurion 7 to support the clinical workflow."
    },
    {
      "sourceId": "sp-azurion-3",
      "product": "Azurion 3",
      "topic": "platform",
      "text": "Azurion 3 is an image guided therapy platform designed to support routine and complex procedures."
    },
    {
      "sourceId": "sp-azurion-3",
      "product": "Azurion 3",
      "topic": "clinical workflow",
      "text": "Advanced interventional tools are integrated into Azurion 3 to support the clinical workflow."
    },
    {
      "sourceId": "sp-azurion-3",
      "product": "Azurion 3",
      "topic": "imaging",
      "text": "The Azurion 15-inch flat detector with the swivel option supports head-to-toe imaging during interventions."
    },
    {
      "sourceId": "sp-smartct",
      "product": "SmartCT",
      "topic": "3D imaging",
      "text": "SmartCT supports acquisition and interaction with 3D images from the Azurion touchscreen."
    },
    {
      "sourceId": "sp-smartct",
      "product": "SmartCT",
      "topic": "workflow guidance",
      "text": "SmartCT provides guided room preparation, protocol selection, isocentering and 3D acquisition."
    },
    {
      "sourceId": "sp-smartct",
      "product": "SmartCT",
      "topic": "sterile field",
      "text": "SmartCT provides control of 3D features within the sterile field."
    },
    {
      "sourceId": "sp-doseaware",
      "product": "DoseAware",
      "topic": "dose monitoring",
      "text": "DoseAware is an X-ray dose monitoring system for hospital staff."
    },
    {
      "sourceId": "sp-doseaware",
      "product": "DoseAware",
      "topic": "real-time visualization",
      "text": "DoseAware visualizes X-ray dose in real time to support effective use of radiation protection."
    },
    {
      "sourceId": "sp-doseaware",
      "product": "DoseAware",
      "topic": "personal dose",
      "text": "DoseAware displays individual dose rates on the base station and provides access to personal dose history."
    },
    {
      "sourceId": "sp-3d-roadmap",
      "product": "3D Roadmap",
      "topic": "image overlay",
      "text": "3D Roadmap overlays live 2D fluoroscopic images on a 3D reconstruction of the vessel tree."
    },
    {
      "sourceId": "sp-3d-roadmap",
      "product": "3D Roadmap",
      "topic": "catheter guidance",
      "text": "The composite roadmap supports catheter guidance during interventional procedures."
    },
    {
      "sourceId": "sp-3d-roadmap",
      "product": "3D Roadmap",
      "topic": "live fluoroscopy",
      "text": "The software continuously matches the orientation of the 3D volume with the live fluoroscopy image."
    },
    {
      "sourceId": "sp-stentboost-live",
      "product": "StentBoost Live",
      "topic": "stent visualization",
      "text": "StentBoost Live provides real-time enhanced visualization of stents in coronary vessels."
    },
    {
      "sourceId": "sp-stentboost-live",
      "product": "StentBoost Live",
      "topic": "stent placement",
      "text": "StentBoost Live supports the physician in placing and deploying coronary stents."
    },
    {
      "sourceId": "sp-dynamic-coronary-roadmap",
      "product": "Dynamic Coronary Roadmap",
      "topic": "angiographic roadmap",
      "text": "Dynamic Coronary Roadmap provides a real-time dynamic angiographic roadmap of the coronary arteries."
    },
    {
      "sourceId": "sp-dynamic-coronary-roadmap",
      "product": "Dynamic Coronary Roadmap",
      "topic": "device navigation",
      "text": "The angiographic roadmap is overlaid on live 2D fluoroscopy to support navigation of guide wires and catheters through the coronary arteries."
    },
    {
      "sourceId": "sp-dynamic-coronary-roadmap",
      "product": "Dynamic Coronary Roadmap",
      "topic": "roadmap generation",
      "text": "The roadmap is generated from diagnostic coronary angiograms acquired during the same procedure."
    },
    {
      "sourceId": "sp-clarifeye",
      "product": "ClarifEye",
      "topic": "augmented reality navigation",
      "text": "ClarifEye combines imaging and augmented reality navigation in one system."
    },
    {
      "sourceId": "sp-clarifeye",
      "product": "ClarifEye",
      "topic": "spine procedures",
      "text": "ClarifEye supports procedure planning and device guidance for the placement of pedicle screws."
    },
    {
      "sourceId": "sp-clarifeye",
      "product": "ClarifEye",
      "topic": "hybrid operating room",
      "text": "ClarifEye is a video-based navigation system integrated into the Philips Azurion Hybrid OR."
    },
    {
      "sourceId": "sp-azurion-7-m20-flexarm",
      "product": "Touch Screen Module Pro",
      "aliases": [
        "Touchscreen Module Pro",
        "TSM Pro"
      ],
      "topic": "image review",
      "text": "Touch Screen Module Pro supports visualization of acquired images at tableside."
    },
    {
      "sourceId": "sp-azurion-7-m20-flexarm",
      "product": "Touch Screen Module Pro",
      "aliases": [
        "Touchscreen Module Pro",
        "TSM Pro"
      ],
      "topic": "collimation control",
      "text": "The module enables collimator and wedge adjustment through drag-and-drop interaction on clinical images."
    },
    {
      "sourceId": "sp-azurion-7-m20-flexarm",
      "product": "Touch Screen Module Pro",
      "aliases": [
        "Touchscreen Module Pro",
        "TSM Pro"
      ],
      "topic": "image interaction",
      "text": "The interventional room pointer highlights details on clinical images, while pinch gestures support zooming and panning."
    },
    {
      "sourceId": "sp-azurion-7-m20-flexarm",
      "product": "Azurion 7 M20 with FlexArm",
      "aliases": [
        "FlexArm"
      ],
      "topic": "tableside control",
      "text": "A single touchscreen provides control of relevant applications at tableside."
    },
    {
      "sourceId": "sp-echonavigator",
      "product": "EchoNavigator",
      "topic": "image guidance",
      "text": "EchoNavigator supports image guidance during cardiovascular procedures that use live X-ray and live echo imaging."
    },
    {
      "sourceId": "sp-echonavigator",
      "product": "EchoNavigator",
      "topic": "image fusion",
      "text": "EchoNavigator can display an ultrasound image or volume as an overlay on the X-ray view."
    },
    {
      "sourceId": "sp-clarityiq-global-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "image quality and dose",
      "text": "ClarityIQ is an image-processing technology for Philips Azurion image-guided therapy systems that supports lower X-ray dose while maintaining equivalent image quality."
    },
    {
      "sourceId": "sp-clarityiq-global-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "technology architecture",
      "text": "ClarityIQ combines powerful image processing, a flexible digital imaging pipeline and clinically fine-tuned parameters across the imaging chain."
    },
    {
      "sourceId": "sp-clarityiq-global-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "automatic motion control",
      "text": "Automatic Motion Control reduces motion artifacts in digital subtraction angiography and Roadmap Pro."
    },
    {
      "sourceId": "sp-clarityiq-global-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "motion compensation",
      "text": "Motion compensation aligns moving structures before frame averaging, enabling stronger temporal noise reduction for stationary and moving anatomy."
    },
    {
      "sourceId": "sp-clarityiq-global-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "spatial noise reduction",
      "text": "Spatial noise reduction uses larger image neighborhoods and signal recognition to reduce noise while preserving relevant structures."
    },
    {
      "sourceId": "sp-clarityiq-global-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "real-time processing",
      "text": "ClarityIQ image processing works in real time to correct patient or table motion, reduce noise and artifacts, and enhance image edges."
    },
    {
      "sourceId": "sp-clarityiq-global-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "application tuning",
      "text": "More than 500 tube, detector and image-processing parameters are fine-tuned for each application area."
    },
    {
      "sourceId": "sp-clarityiq-us-whitepaper",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "US"
      ],
      "topic": "clinical evidence",
      "text": "The US ClarityIQ white paper reports clinical evidence from 37 peer-reviewed comparative studies involving 19,668 patients."
    },
    {
      "sourceId": "sp-clarityiq-cardio-article",
      "product": "ClarityIQ",
      "aliases": [
        "Azurion with ClarityIQ",
        "AlluraClarity"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "interventional cardiology evidence",
      "text": "The interventional cardiology evidence collection includes peer-reviewed studies of image noise reduction, patient radiation dose and diagnostic image quality."
    },
    {
      "sourceId": "sp-smartiq-brochure",
      "product": "SmartIQ",
      "aliases": [
        "Azurion with SmartIQ"
      ],
      "topic": "coronary imaging",
      "text": "SmartIQ is a next-generation coronary imaging technology designed for integration into existing interventional cardiology workflows."
    },
    {
      "sourceId": "sp-smartiq-brochure",
      "product": "SmartIQ",
      "aliases": [
        "Azurion with SmartIQ"
      ],
      "topic": "image presentation",
      "text": "SmartIQ provides contrast-rich images with less background noise to improve differentiation of clinical details."
    },
    {
      "sourceId": "sp-smartiq-brochure",
      "product": "SmartIQ",
      "aliases": [
        "Azurion with SmartIQ"
      ],
      "topic": "ultra-low dose protocol",
      "text": "The SmartIQ ultra-low dose protocol uses more than 50% less X-ray radiation dose than the referenced low ClarityIQ setting for the specified coronary imaging conditions."
    },
    {
      "sourceId": "sp-azurion-smartiq-overview",
      "product": "SmartIQ",
      "aliases": [
        "Azurion with SmartIQ"
      ],
      "markets": [
        "Global, non-US"
      ],
      "topic": "ClarityIQ foundation",
      "text": "SmartIQ builds on the image-quality and dose-management foundation established by Azurion with ClarityIQ."
    },
    {
      "sourceId": "sp-indexed-16",
      "product": "Allura FD20/15",
      "topic": "product capability",
      "text": "The PerfectFit design of the Allura FD20/15 simplifies access to the patient to help reduce the chance of retakes.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-16",
      "product": "Allura",
      "topic": "workflow",
      "text": "For hybrid and open procedures, the Allura systems seamlessly integrate the Allura X-ray and MAQUET operating table.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-17",
      "product": "SmartCT",
      "topic": "imaging",
      "text": "SmartCT offers metal artifact and noise reduction filters to improve anatomical visualization.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-21",
      "product": "AltaTrack",
      "topic": "imaging",
      "text": "AltaTrack images can be viewed on monitors in the control room, where data preparation tasks can also be performed.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-22",
      "product": "LumiGuide",
      "topic": "imaging",
      "text": "LumiGuide images can be viewed on monitors in the control room, where data preparation tasks can also be performed.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-22",
      "product": "LumiGuide",
      "topic": "imaging",
      "text": "LumiGuide allows for real time, 3D reconstruction of the shape of that fiber optic sensor, when connected to LumiGuide Equipment containing software and electronic components.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-23",
      "product": "LumiGuide",
      "topic": "imaging",
      "text": "LumiGuide enables the LumiGuide Equipment to create a 3D image of the LumiGuide Wire in real time.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-23",
      "product": "LumiGuide",
      "topic": "imaging",
      "text": "When connected to the LumiGuide Equipment, the LumiGuide Navigation Wire 3D Plus can be visualized as an overlay to X-ray images.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-25",
      "product": "SmartCT",
      "topic": "control",
      "text": "SmartCT can be controlled from both the control room and the examination room.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-25",
      "product": "SmartCT",
      "topic": "imaging",
      "text": "SmartCT provides overlays of live 2D fluoroscopic images with a 3D reconstruction of the vessel tree.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-25",
      "product": "SmartCT",
      "topic": "workflow",
      "text": "SmartCT provides workflow guidance to support the physician in the workflow of acquiring and processing 3D images.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-25",
      "product": "SmartCT",
      "topic": "product capability",
      "text": "SmartCT also offers a vessel analysis tool that provides automatic measurements of the diameter of a segmented vessel.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-doseaware",
      "product": "DoseAware",
      "topic": "dose management",
      "text": "The Live screen, which can be viewed on the monitor that is connected to the DoseAware network video adapter, displays a maximum of 8 PDMs at a time.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-26",
      "product": "FlexArm",
      "topic": "product capability",
      "text": "The FlexArm stand provides longitudinal and transverse movements, and free detector rotation.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-31",
      "product": "ClarifEye",
      "topic": "imaging",
      "text": "ClarifEye provides assistance to the performing physician to align a device with a virtual path that is planned on a 3D volume of the anatomy.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-31",
      "product": "ClarifEye",
      "topic": "product capability",
      "text": "ClarifEye is designed to be used for procedures where a straight, rigid device is placed in a bony anatomy, such as sacral, lumbar and thoracic pedicle screw placement and biopsy.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-32",
      "product": "ClarifEye",
      "topic": "product capability",
      "text": "ClarifEye is designed to be used for procedures where a straight, rigid device is placed in the spine, such as sacral, lumbar and thoracic pedicle screw placement.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-34",
      "product": "Interventional Workspot",
      "topic": "workflow",
      "text": "Interventional Workspot provides common functionalities (e.g. import / export and data handling functions) that are required by the Interventional Tools to support the physician with performing the interventional procedure.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-35",
      "product": "3D-RA",
      "topic": "imaging",
      "text": "3D-RA provides operators with several processing tools for performing analysis on 3D volumes.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-36",
      "product": "MR-CT Roadmap",
      "topic": "imaging",
      "text": "MR-CT Roadmap overlays live 2D fluoroscopic images on a previously acquired MRA or CTA volume, which is registered with the X-ray system using a rotational scan.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-37",
      "product": "XperCT Dual",
      "topic": "imaging",
      "text": "XperCT Dual provides Dual View and specific protocols for Dual Phase Image Acquisition.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-37",
      "product": "XperCT Dual",
      "topic": "product capability",
      "text": "XperCT Dual provides operators with several processing tools for performing analysis on XperCT volumes.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-37",
      "product": "XperCT Dual",
      "topic": "imaging",
      "text": "XperCT Dual allows the user to review the reconstructed 3D model.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-38",
      "product": "XperGuide",
      "topic": "imaging",
      "text": "XperGuide overlays live 2D fluoroscopic images on a 3D reconstruction of the anatomy.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-38",
      "product": "XperGuide",
      "topic": "product capability",
      "text": "XperGuide provides real-time feedback on needle position with respect to the planned path.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-39",
      "product": "EmboGuide",
      "topic": "imaging",
      "text": "EmboGuide provides tools to help the user with the analysis of 3D rotational angiography images.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-39",
      "product": "EmboGuide",
      "topic": "imaging",
      "text": "EmboGuide automatically switches to full-screen mode and overlays the live X-ray images on the 3D volume.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-39",
      "product": "EmboGuide",
      "topic": "product capability",
      "text": "EmboGuide allows the physician to see and understand the exact nature and location of the lesion, and to create a plan for the most appropriate treatment.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-40",
      "product": "StentBoost",
      "topic": "imaging",
      "text": "StentBoost provides high image quality visualization of stents in relation to vessels.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-40",
      "product": "StentBoost",
      "topic": "product capability",
      "text": "StentBoost calculates the boundaries of the catheter section and attempts to trace the edges of the section in the main display area.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-41",
      "product": "VesselNavigator",
      "topic": "control",
      "text": "Operating principle VesselNavigator is intended to be used in the control room and in the exam room of an interventional suite or hybrid operating room.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-41",
      "product": "3D-RA",
      "topic": "imaging",
      "text": "VesselNavigator supports all standard non-neuro and non-intercranial 3D-RA, XperCT, and CBCT scans that have been created with the frontal stand of a compatible X-ray system.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-43",
      "product": "EP navigator",
      "topic": "imaging",
      "text": "EP navigator uses live fluoroscopy combined with a 3D overlay to assist with catheter/device navigation.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-43",
      "product": "EP navigator",
      "topic": "product capability",
      "text": "EP navigator supports EP procedures in an interventional clinical environment.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-44",
      "product": "HeartNavigator",
      "topic": "imaging",
      "text": "HeartNavigator extends control of HeartNavigator to the examination room and removes the need to leave the patient during examinations to view images.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-44",
      "product": "HeartNavigator",
      "topic": "product capability",
      "text": "HeartNavigator is designed to support interventional procedures.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-45",
      "product": "SmartPerfusion",
      "topic": "navigation",
      "text": "SmartPerfusion starts automatically and acquisition guidance is displayed in the main display area.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-45",
      "product": "SmartPerfusion",
      "topic": "product capability",
      "text": "SmartPerfusion provides time-density information for a selected region of interest.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-51",
      "product": "StentBoost Live",
      "topic": "imaging",
      "text": "StentBoost Live features instantaneous processing, eliminating the need to wait for new images before stent repositioning.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-52",
      "product": "EP navigator",
      "topic": "dose management",
      "text": "EP navigator provides detailed 3D anatomy, which can be overlaid onto live fluoroscopy, removing the need for a mapping system, or exported to a compatible mapping system to help minimize dose and reduce mapping time.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-52",
      "product": "EP navigator",
      "topic": "imaging",
      "text": "Point Tagging In combination with the 3D overlay functionality, EP navigator offers Point Tagging to accurately mark ablation points.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-53",
      "product": "Allura",
      "topic": "product capability",
      "text": "Allura, coupled with Allura Centron’s three side positioning provides flexibility and allows patient access from all sides.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-53",
      "product": "3D-RA",
      "topic": "imaging",
      "text": "3D-RA Philips Allura 3D-RA provides extensive 3D visualization of vascular pathologies from a single rotational angiography run.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-53",
      "product": "Allura",
      "topic": "product capability",
      "text": "Designed for Cardiac and Electrophysiology procedures, Allura Centron also offers the flexibility for use in Neuro and Vascular procedures.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-azurion-3",
      "product": "Azurion",
      "topic": "product capability",
      "text": "Azurion, coupled with three-side positioning provides flexibility and allows patient access from all sides.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-azurion-3",
      "product": "Azurion 3",
      "topic": "workflow",
      "text": "Azurion 3 is powered by ConnectOS, a real-time multi-workspot technology designed specifically for the Azurion interventional suite.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-azurion-3",
      "product": "Azurion",
      "topic": "product capability",
      "text": "The Azurion 15\" Flat Detector combined with the swivel option supports head-to toe imaging during interventions.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-55",
      "product": "Azurion Spine suite",
      "topic": "workflow",
      "text": "Azurion Spine suite combines surgical table options, workflow features, and dedicated 2D and 3D image guidance tools to support device placement.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-56",
      "product": "3D-RA",
      "topic": "imaging",
      "text": "3D-RA provides high spatial resolution volumes and automatically compensates for patient movement.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-56",
      "product": "SmartCT Vaso IV",
      "topic": "imaging",
      "text": "SmartCT Vaso IV supports visualization beyond a clot with peri-procedural imaging of distal vessel anatomy in ischemic stroke.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-56",
      "product": "Azurion",
      "topic": "workflow",
      "text": "Azurion includes workflow features designed to help on-call staff work efficiently during acute ischemic stroke interventions.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-56",
      "product": "SmartCT Roadmap",
      "topic": "navigation",
      "text": "SmartCT Roadmap provides dynamic 3D image guidance through neurovascular structures and enhances visualization of overlapping vessels during guidewire and catheter navigation.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-57",
      "product": "Azurion",
      "topic": "workflow",
      "text": "Azurion image-guided therapy systems integrate with the Getinge Maquet Magnus OR table and the Hillrom TS7500 OR System Table to support a range of procedures.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-58",
      "product": "SmartCT Dual Phase Cerebral",
      "topic": "imaging",
      "text": "SmartCT Dual Phase Cerebral provides two consecutive contrast-enhanced cone-beam CT scans of the brain.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-58",
      "product": "SmartCT Roadmap",
      "topic": "navigation",
      "text": "SmartCT Roadmap provides a live 3D image overlay that can be segmented to emphasize targeted vessels and lesions.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-58",
      "product": "SmartCT Vessel Analysis",
      "topic": "measurement",
      "text": "SmartCT Vessel Analysis provides straightened, curved, and cross-section reformats for vessel inspection and device positioning during treatment planning.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-58",
      "product": "SmartCT Roadmap",
      "topic": "navigation",
      "text": "SmartCT Roadmap overlays a 3D reconstruction of the vessel tree, vessel segments, or annotations with live fluoroscopy images.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-58",
      "product": "SmartCT Dual Viewer",
      "topic": "control",
      "text": "SmartCT Dual Viewer enables viewing and manipulation of volumes at tableside using the touchscreen module or mouse and keyboard.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-59",
      "product": "Zenition",
      "topic": "control",
      "text": "Zenition flat detector and image intensifier systems share a consistent control and handling approach.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-59",
      "product": "Zenition 50",
      "topic": "configuration",
      "text": "Zenition 50 system settings can be customized and exported to other Zenition 50 systems through Philips Support Connect.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-59",
      "product": "Zenition",
      "topic": "platform",
      "text": "Zenition systems use a common Windows platform designed to support evolving clinical applications and service technologies.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-60",
      "product": "Zenition 70",
      "topic": "platform",
      "text": "Zenition 70 uses a Windows platform designed to support evolving clinical applications and service technologies.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-60",
      "product": "Zenition 70",
      "topic": "configuration",
      "text": "Zenition 70 system settings can be customized and exported to other Zenition 70 systems through Philips Support Connect.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-60",
      "product": "Zenition 70",
      "topic": "continuous imaging",
      "text": "Zenition 70 is engineered for continuous imaging with a tank design that supports heat management during longer procedures.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-61",
      "product": "Zenition 10",
      "topic": "workflow",
      "text": "Zenition 10 provides a consistent workflow with intuitive control and handling to support teamwork.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-61",
      "product": "Zenition 10",
      "topic": "control",
      "text": "Zenition 10 uses a uniform design and user interface intended to make system operation familiar to users.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-62",
      "product": "Zenition 30",
      "topic": "clinical application",
      "text": "Zenition 30 supports orthopedic, trauma, spine, pain-management, and other surgical procedures.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-63",
      "product": "Zenition 90 Motorized",
      "topic": "control",
      "text": "Zenition 90 Motorized provides user-friendly controls and time-saving workflow features on a platform designed for continuous use.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-63",
      "product": "Zenition 90 Motorized",
      "topic": "platform",
      "text": "Zenition 90 Motorized supports additional software options through its Windows platform.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-63",
      "product": "Zenition 90 Motorized",
      "topic": "workflow",
      "text": "Zenition 90 Motorized includes technical features intended to reduce workflow distractions during procedures.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-64",
      "product": "Zenition",
      "topic": "control",
      "text": "Zenition systems use a uniform control design across the product series for operators with different experience levels.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-64",
      "product": "Zenition 90",
      "topic": "workflow",
      "text": "Zenition 90 is engineered to support a controllable workflow during surgical procedures.",
      "indexMode": "content-extracted"
    },
    {
      "sourceId": "sp-indexed-65",
      "product": "Azurion 7",
      "topic": "platform",
      "text": "Azurion 7 is powered by ConnectOS, a real-time multi-workspot technology designed for the Azurion Image Guided Therapy platform.",
      "indexMode": "content-extracted"
    }
  ]
};
