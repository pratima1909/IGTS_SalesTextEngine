import assert from "node:assert/strict";
import JSZip from "jszip";
import * as XLSX from "xlsx";
import { extractDocumentText } from "../document-extraction.mjs";

const textResult = await extractDocumentText({
  name: "product-brief.txt",
  buffer: Buffer.from("NovaGuide provides live image guidance for interventional workflows."),
});
assert.match(textResult.text, /live image guidance/);
assert.equal(textResult.extension, ".txt");

const workbook = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([
  ["Product", "Approved fact"],
  ["NovaGuide", "Supports image-guided device navigation"],
]), "Facts");
const workbookResult = await extractDocumentText({
  name: "approved-facts.xlsx",
  buffer: XLSX.write(workbook, { type: "buffer", bookType: "xlsx" }),
});
assert.match(workbookResult.text, /Facts/);
assert.match(workbookResult.text, /image-guided device navigation/);

const presentation = new JSZip();
presentation.file("ppt/slides/slide1.xml", "<p:sld xmlns:p=\"p\" xmlns:a=\"a\"><a:p><a:r><a:t>NovaGuide workflow integration</a:t></a:r></a:p></p:sld>");
const presentationResult = await extractDocumentText({
  name: "product-overview.pptx",
  buffer: await presentation.generateAsync({ type: "nodebuffer" }),
});
assert.match(presentationResult.text, /NovaGuide workflow integration/);

await assert.rejects(
  extractDocumentText({ name: "unsupported.exe", buffer: Buffer.from("test") }),
  /Unsupported file type/,
);

console.log("Document extraction test passed.");
