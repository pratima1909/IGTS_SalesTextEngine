import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const c=vm.createContext({console,document:{querySelector:()=>({})},window:{}});
const code=fs.readFileSync('app.js','utf8').replace(/initialise\(\);\s*$/,'')+'\nglobalThis.api={state,prepareSharePointManifest,prepareSharePointSource,prepareSalesPortalSource,buildLocalDraft};';
vm.runInContext(code,c);
for(const file of ['sharepoint-source-manifest.js','sharepoint-product-facts.js','sales-portal-source.js']) vm.runInContext(fs.readFileSync('public/data/'+file,'utf8'),c);
const api=c.api;
api.prepareSharePointManifest(c.window.SHAREPOINT_SOURCE_MANIFEST);
api.prepareSharePointSource(c.window.SHAREPOINT_PRODUCT_FACTS);
api.prepareSalesPortalSource(c.window.IGT_SALES_PORTAL_SOURCE);
for(const itemName of ['Azurion 7','HeartNavigator','SmartIQ','EchoNavigator','Allura 3D-RA']) {
  const result=api.buildLocalDraft({itemName,keywords:'',facts:'',audience:''});
  const facts=[...result.sharePointSource.facts,...result.salesPortalSource.facts];
  assert.ok(facts.length>0,`${itemName} should retain eligible current evidence`);
  for(const fact of facts) {
    assert.equal(fact.evidence.reviewStatus,'screened');
    assert.equal(fact.evidence.sourceUrl,fact.source.url);
    assert.equal(fact.source.contentStatus,'indexed');
  }
}
for(const itemName of ['Touch Screen Module Pro','ClarityIQ','Zenition 90']) {
  const result=api.buildLocalDraft({itemName,keywords:'',facts:'',audience:''});
  assert.equal(result.sharePointSource.facts.filter(f=>f.product===itemName).length,0,`${itemName} must not regain withheld source passages`);
  assert.equal(result.salesPortalSource.facts.filter(f=>f.product===itemName).length,0);
}
console.log('Refreshed draft evidence test passed.');
