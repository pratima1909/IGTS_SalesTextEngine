// Screened SharePoint refresh 2026-10-05; observed coverage is not an authoritative total.
window.SHAREPOINT_PRODUCT_FACTS = {
  "metadata": {
    "sourceName": "IGT-S Strategy Execution & Transformation SharePoint",
    "folderName": "Data Analytics/SSA_PAL_Filterted",
    "folderUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FIGT%2DSStrategyExecutionTransformation%2FShared%20Documents%2FData%20Analytics%2FSSA%5FPAL%5FFilterted",
    "snapshotDate": "2026-10-05",
    "inspectedFileCount": 690,
    "observedFileCount": 690,
    "listedFileCount": 200,
    "continuationAvailable": true,
    "documentCount": 12,
    "factCount": 24,
    "selectionPolicy": "Register every observed identity and attempt readable-content extraction. Only individually screened English product passages from suitable customer-facing or approved documents contribute claims. Internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported, incompatible-language and market-restricted content is excluded.",
    "searchDiscoveredFileCount": 490,
    "contentReadDocumentCount": 684,
    "refreshNote": "Refreshed 2026-10-05; extraction outcomes and evidence passages verified for this run.",
    "observedDocumentCount": 690,
    "registeredDocumentCount": 690,
    "reachableDocumentCount": 685,
    "contentExtractionAttemptedDocumentCount": 690,
    "contentIndexedDocumentCount": 684,
    "extractionFailedDocumentCount": 5,
    "unreadableDocumentCount": 1,
    "factBackedDocumentCount": 12,
    "enumerationComplete": false,
    "authoritativeLibraryTotal": null,
    "searchQueries": [
      "*",
      ".pdf",
      ".pptx",
      ".docx",
      ".xlsx",
      ".csv",
      ".txt",
      "path:\"https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted\"",
      "path scope AND filetype:pdf",
      "path scope AND filetype:pptx",
      "path scope AND filetype:docx",
      "path scope AND filetype:xlsx",
      "path scope AND filetype:csv",
      "path scope AND filetype:txt",
      "folder-path AND (SmartIQ OR Zenition OR Allura_XPER_FD10_20 OR DHF250148)"
    ],
    "coverageNote": "2026-10-05: 690 unique connector-observed files registered; extraction attempted for 690. 684 returned readable text (99.1%); 1 returned no text and 5 failed. 24 screened facts from 12 documents. The folder listing returned 200 files and a continuation URL, but the connector exposes no continuation input. Site and folder-path searches supplement that first page. Search supports text-friendly formats only; other file types may be absent from search discovery. Search coverage is not an authoritative SharePoint library total; exhaustive enumeration cannot be certified. Failure reasons: file too large: 5.",
    "enumerationAudit": {
      "source": 0,
      "site": "/sites/IGT-SStrategyExecutionTransformation",
      "siteDrives": [
        {
          "id": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
          "name": "Documents",
          "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents"
        }
      ],
      "listing": {
        "returned": 200,
        "continuationAvailable": true,
        "requestedTop": 1000,
        "actualTop": 200
      },
      "queries": [
        {
          "query": "*",
          "scope": "site",
          "returned": 318
        },
        {
          "query": ".pdf",
          "scope": "site",
          "returned": 351
        },
        {
          "query": ".pptx",
          "scope": "site",
          "returned": 133
        },
        {
          "query": ".docx",
          "scope": "site",
          "returned": 70
        },
        {
          "query": ".xlsx",
          "scope": "site",
          "returned": 10
        },
        {
          "query": ".csv",
          "scope": "site",
          "returned": 235
        },
        {
          "query": ".txt",
          "scope": "site",
          "returned": 500
        },
        {
          "query": "path:\"https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted\"",
          "returned": 337
        },
        {
          "query": "path scope AND filetype:pdf",
          "returned": 351
        },
        {
          "query": "path scope AND filetype:pptx",
          "returned": 47
        },
        {
          "query": "path scope AND filetype:docx",
          "returned": 6
        },
        {
          "query": "path scope AND filetype:xlsx",
          "returned": 0
        },
        {
          "query": "path scope AND filetype:csv",
          "returned": 0
        },
        {
          "query": "path scope AND filetype:txt",
          "returned": 0
        },
        {
          "query": "folder-path AND (SmartIQ OR Zenition OR Allura_XPER_FD10_20 OR DHF250148)",
          "returned": 122
        }
      ],
      "observed": 690,
      "authoritativeLibraryTotal": null,
      "enumerationComplete": false
    },
    "extractionFailureCounts": {
      "FILE_TOO_LARGE": 5
    },
    "previouslyObservedNotReobservedCount": 1
  },
  "documents": [
    {
      "id": "strategy-01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
      "title": "452296278537_LR_EPnav_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:26Z",
      "sizeBytes": 2056457,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296278537_LR_EPnav_brochure.pdf",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "folder-page",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:43:53.313Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 1,
      "extractedCharacterCount": 17941,
      "contentSha256": "c186680ba3ccf2fe7c4038e01cb4c84104476a8d1a47eb6d7a1c57530a9b5767",
      "factCount": 2,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
      "title": "452299108181_Philips_Allura_Centron_brochure.pdf",
      "updatedAt": "2026-06-26T04:46:28Z",
      "sizeBytes": 803957,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299108181_Philips_Allura_Centron_brochure.pdf",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "folder-page",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:41:38.639Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 2,
      "extractedCharacterCount": 16578,
      "contentSha256": "1fa1622f538fffdfe8cb438c02d805fae8913926debc615ee30e6fd9fdaa4926",
      "factCount": 2,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXPQIYMAXEHIW5FY56ZUAGZFA7UV",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXPQIYMAXEHIW5FY56ZUAGZFA7UV",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXPQIYMAXEHIW5FY56ZUAGZFA7UV",
      "title": "452299122381_Philips_Azurion_3_brochure_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:31Z",
      "sizeBytes": 633799,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299122381_Philips_Azurion_3_brochure_FINAL.pdf",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXPQIYMAXEHIW5FY56ZUAGZFA7UV",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "folder-page",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:43:53.503Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 1,
      "extractedCharacterCount": 14721,
      "contentSha256": "662419dd612858bc24ad380b85dd5994902fb3e99e6c575290269a7f0ef02e00",
      "factCount": 1,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXNHIJKJZY2JX5BJ7CFMTT4WFWKM",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNHIJKJZY2JX5BJ7CFMTT4WFWKM",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXNHIJKJZY2JX5BJ7CFMTT4WFWKM",
      "title": "452299122941_Philips_Azurion_7_brochure_FINAL.pdf",
      "updatedAt": "2026-06-26T04:46:33Z",
      "sizeBytes": 643407,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299122941_Philips_Azurion_7_brochure_FINAL.pdf",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNHIJKJZY2JX5BJ7CFMTT4WFWKM",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "folder-page",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:41:38.748Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 2,
      "extractedCharacterCount": 13831,
      "contentSha256": "8378d9959dad69f19fa8d616b62da93c1cbee2c3aea8bb13050a295231928abd",
      "factCount": 1,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
      "title": "452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final (1).pdf",
      "updatedAt": "2026-06-26T04:46:59Z",
      "sizeBytes": 529985,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final%20(1).pdf",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "folder-page",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:41:25.489Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 2,
      "extractedCharacterCount": 10970,
      "contentSha256": "32f1e6bc7fdfb11a2ab0bc11ccd447cb3d8844b62242f0c0749fe6c0dd59e2d7",
      "factCount": 3,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
      "title": "452299176331__Philips_Zenition_50_brochure_May 2022_Updated_LR.pdf",
      "updatedAt": "2026-06-26T04:47:12Z",
      "sizeBytes": 3132059,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299176331__Philips_Zenition_50_brochure_May%202022_Updated_LR.pdf",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "folder-page",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:41:46.178Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 2,
      "extractedCharacterCount": 12413,
      "contentSha256": "733f87e77cad9558c7a713cceb2a6c45ab7d6f35936375838b02b6961b5a72f0",
      "factCount": 3,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXMMRQP33PAUYRB2OICGXZFJ3ZZE",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXMMRQP33PAUYRB2OICGXZFJ3ZZE",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXMMRQP33PAUYRB2OICGXZFJ3ZZE",
      "title": "452299181971_Philips_Azurion_7_brochure_July 2023.pdf",
      "updatedAt": "2026-06-26T04:47:45Z",
      "sizeBytes": 17484679,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299181971_Philips_Azurion_7_brochure_July%202023.pdf",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXMMRQP33PAUYRB2OICGXZFJ3ZZE",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "folder-page",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:41:47.324Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 2,
      "extractedCharacterCount": 25173,
      "contentSha256": "891ceab454168a079b0d6d97ae13013fbbffba756a525d3d2335d0fb2524039e",
      "factCount": 1,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
      "title": "B1_Brochure_4522_962_93921_3D-RA_2013_05.pdf",
      "updatedAt": "2013-04-29T07:07:50Z",
      "sizeBytes": 451239,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/B1_Brochure_4522_962_93921_3D-RA_2013_05.pdf?web=1",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "search",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T13:10:12.440Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 1,
      "extractedCharacterCount": 6884,
      "contentSha256": "86f8db4f2977770fedda5361b08f5a67e1cabbc55f3622e8ede11dc1ab4ce28e",
      "factCount": 2,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "title": "HS_IGT_Cardiology__EchoNavigator__Brochure_Global__v1_20170914.pdf",
      "updatedAt": "2014-07-22T14:55:44Z",
      "sizeBytes": 1602488,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Cardiology__EchoNavigator__Brochure_Global__v1_20170914.pdf?web=1",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "search",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T13:10:01.024Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 1,
      "extractedCharacterCount": 5363,
      "contentSha256": "8b4b7ed30a5aae7e5b4cfc08e2da111339c9417e23baa1a00a2f3feb058d6712",
      "factCount": 4,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXO26VOJCYWF5RGJBRQADEAM3QLK",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXO26VOJCYWF5RGJBRQADEAM3QLK",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXO26VOJCYWF5RGJBRQADEAM3QLK",
      "title": "Philips_SmartIQ_Technology_Product_Brochure_MAT-6197.pdf",
      "updatedAt": "2026-02-10T13:22:42Z",
      "sizeBytes": 610239,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_SmartIQ_Technology_Product_Brochure_MAT-6197.pdf?web=1",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXO26VOJCYWF5RGJBRQADEAM3QLK",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "search",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:44:05.389Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 1,
      "extractedCharacterCount": 12587,
      "contentSha256": "dc7dc4f25cd7eada4ae6a79623095e4fefb51c4fbdca5fa5030c8beb154052e9",
      "factCount": 1,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXOEMDUPGB3AOZAJMLB6H5SL6O4J",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXOEMDUPGB3AOZAJMLB6H5SL6O4J",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXOEMDUPGB3AOZAJMLB6H5SL6O4J",
      "title": "Zenition 30 Product Brochure.pdf",
      "updatedAt": "2024-08-13T14:34:58Z",
      "sizeBytes": 1731196,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Product Brochure.pdf?web=1",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXOEMDUPGB3AOZAJMLB6H5SL6O4J",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "search",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:44:11.091Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 1,
      "extractedCharacterCount": 11606,
      "contentSha256": "e1707acf409a704944c428f4aceb971e98ddaedeff83f71313c89ca1f07ec1e1",
      "factCount": 1,
      "selectionStatus": "selected",
      "exclusionReason": null
    },
    {
      "id": "strategy-01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
      "stableIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
      "driveId": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit",
      "itemId": "01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
      "title": "Zenition 70 Product Brochure_Update_July_2024.pdf",
      "updatedAt": "2024-07-23T14:51:28Z",
      "sizeBytes": 16525688,
      "url": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 70 Product Brochure_Update_July_2024.pdf?web=1",
      "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
      "mimeType": "application/pdf",
      "observedAt": "2026-10-05",
      "source": "search",
      "contentStatus": "indexed",
      "extractionAttemptedAt": "2026-10-05T12:44:11.673Z",
      "extractionErrorCode": null,
      "extractionAttemptCount": 1,
      "extractedCharacterCount": 12317,
      "contentSha256": "42a47eca6c61254284bd18bd22ed7b95fef97865d45f79f3b2a930a54b4855a3",
      "factCount": 3,
      "selectionStatus": "selected",
      "exclusionReason": null
    }
  ],
  "facts": [
    {
      "sourceId": "strategy-01J4NUPXNHIJKJZY2JX5BJ7CFMTT4WFWKM",
      "product": "Azurion 7",
      "topic": "platform",
      "text": "Azurion 7 is an image guided therapy platform designed to support a wide range of routine and complex procedures.",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNHIJKJZY2JX5BJ7CFMTT4WFWKM",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299122941_Philips_Azurion_7_brochure_FINAL.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNHIJKJZY2JX5BJ7CFMTT4WFWKM",
        "quote": "This new-generation image guided therapy platform allows you to easily and confidently perform a wide range of routine and complex procedures with a unique user experience, helping you optimize your lab performance and provide superior care.",
        "normalizedStart": 305,
        "contentSha256": "8378d9959dad69f19fa8d616b62da93c1cbee2c3aea8bb13050a295231928abd",
        "verifiedAt": "2026-10-05T12:41:38.748Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXPQIYMAXEHIW5FY56ZUAGZFA7UV",
      "product": "Azurion 3",
      "topic": "workflow",
      "text": "Azurion 3 is powered by ConnectOS, a real-time multi-workspot technology designed specifically for the Azurion interventional suite.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXPQIYMAXEHIW5FY56ZUAGZFA7UV",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299122381_Philips_Azurion_3_brochure_FINAL.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXPQIYMAXEHIW5FY56ZUAGZFA7UV",
        "quote": "Azurion 3 is powered by ConnectOS, a real-time multi-workspot technology designed specifically for the Azurion interventional suite.",
        "normalizedStart": 343,
        "contentSha256": "662419dd612858bc24ad380b85dd5994902fb3e99e6c575290269a7f0ef02e00",
        "verifiedAt": "2026-10-05T12:43:53.503Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXMMRQP33PAUYRB2OICGXZFJ3ZZE",
      "product": "Azurion 7",
      "topic": "platform",
      "text": "Azurion 7 is powered by ConnectOS, a real-time multi-workspot technology designed for the Azurion Image Guided Therapy platform.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXMMRQP33PAUYRB2OICGXZFJ3ZZE",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299181971_Philips_Azurion_7_brochure_July%202023.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXMMRQP33PAUYRB2OICGXZFJ3ZZE",
        "quote": "Azurion is powered by ConnectOS, a real-time multi-workspot technology designed specifically for the Azurion Image Guided Therapy platform.",
        "normalizedStart": 537,
        "contentSha256": "891ceab454168a079b0d6d97ae13013fbbffba756a525d3d2335d0fb2524039e",
        "verifiedAt": "2026-10-05T12:41:47.324Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
      "product": "ClarifEye",
      "topic": "augmented reality navigation",
      "text": "ClarifEye combines imaging and augmented reality navigation in one system.",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final%20(1).pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
        "quote": "ClarifEye is an industry-first solution that combines imaging and augmented reality (AR) navigation into one system, to support precise planning and effective device guidance for accurate1 placement of pedicle screws.",
        "normalizedStart": 632,
        "contentSha256": "32f1e6bc7fdfb11a2ab0bc11ccd447cb3d8844b62242f0c0749fe6c0dd59e2d7",
        "verifiedAt": "2026-10-05T12:41:25.489Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
      "product": "ClarifEye",
      "topic": "spine procedures",
      "text": "ClarifEye supports procedure planning and device guidance for the placement of pedicle screws.",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final%20(1).pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
        "quote": "ClarifEye is an industry-first solution that combines imaging and augmented reality (AR) navigation into one system, to support precise planning and effective device guidance for accurate1 placement of pedicle screws.",
        "normalizedStart": 632,
        "contentSha256": "32f1e6bc7fdfb11a2ab0bc11ccd447cb3d8844b62242f0c0749fe6c0dd59e2d7",
        "verifiedAt": "2026-10-05T12:41:25.489Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
      "product": "ClarifEye",
      "topic": "hybrid operating room",
      "text": "ClarifEye is a video-based navigation system integrated into the Philips Azurion Hybrid OR.",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299167761_Philips_IGT_ClarifEye_brochure_v2_global_final%20(1).pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXK7JMEUR76VDZG36CCKON6OC3MK",
        "quote": "With ClarifEye, a video-based navigation system is built into the Philips Azurion Hybrid OR.",
        "normalizedStart": 1235,
        "contentSha256": "32f1e6bc7fdfb11a2ab0bc11ccd447cb3d8844b62242f0c0749fe6c0dd59e2d7",
        "verifiedAt": "2026-10-05T12:41:25.489Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXO26VOJCYWF5RGJBRQADEAM3QLK",
      "product": "SmartIQ",
      "aliases": [
        "Azurion with SmartIQ"
      ],
      "topic": "coronary imaging",
      "text": "SmartIQ is designed to integrate into existing clinical workflows.",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXO26VOJCYWF5RGJBRQADEAM3QLK",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Philips_SmartIQ_Technology_Product_Brochure_MAT-6197.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXO26VOJCYWF5RGJBRQADEAM3QLK",
        "quote": "SmartIQ has been specifically designed to seamlessly integrate into your existing workflows.",
        "normalizedStart": 8443,
        "contentSha256": "dc7dc4f25cd7eada4ae6a79623095e4fefb51c4fbdca5fa5030c8beb154052e9",
        "verifiedAt": "2026-10-05T12:44:05.389Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
      "product": "EP navigator",
      "topic": "dose management",
      "text": "EP navigator provides 3D anatomy that can be overlaid onto live fluoroscopy or exported to a compatible mapping system.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296278537_LR_EPnav_brochure.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
        "quote": "It provides detailed 3D anatomy, which can be overlaid onto live fl uoroscopy, removing the need for a mapping system, or exported to a compatible mapping system to help minimize dose and reduce mapping time.",
        "normalizedStart": 4039,
        "contentSha256": "c186680ba3ccf2fe7c4038e01cb4c84104476a8d1a47eb6d7a1c57530a9b5767",
        "verifiedAt": "2026-10-05T12:43:53.313Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
      "product": "EP navigator",
      "topic": "imaging",
      "text": "EP navigator combines 3D overlay functionality with Point Tagging to mark ablation points.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452296278537_LR_EPnav_brochure.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXLNPWS4NBLVSNFY5GEHLETO6UYW",
        "quote": "Point Tagging In combination with the 3D overlay functionality, EP navigator offers Point Tagging to accurately mark ablation points.",
        "normalizedStart": 6978,
        "contentSha256": "c186680ba3ccf2fe7c4038e01cb4c84104476a8d1a47eb6d7a1c57530a9b5767",
        "verifiedAt": "2026-10-05T12:43:53.313Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
      "product": "Allura Centron",
      "topic": "product capability",
      "text": "Allura Centron supports three-side positioning and patient access from all sides.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299108181_Philips_Allura_Centron_brochure.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
        "quote": "This, coupled with Allura Centron’s three side positioning provides flexibility and allows patient access from all sides.",
        "normalizedStart": 7772,
        "contentSha256": "1fa1622f538fffdfe8cb438c02d805fae8913926debc615ee30e6fd9fdaa4926",
        "verifiedAt": "2026-10-05T12:41:38.639Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
      "product": "Allura Centron",
      "topic": "product capability",
      "text": "Designed for Cardiac and Electrophysiology procedures, Allura Centron also offers the flexibility for use in Neuro and Vascular procedures.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299108181_Philips_Allura_Centron_brochure.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXKR6OVXVD64IJCYMJBRL4T7JR6L",
        "quote": "Designed for Cardiac and Electrophysiology procedures, Allura Centron also offers the flexibility for use in Neuro and Vascular procedures.",
        "normalizedStart": 1425,
        "contentSha256": "1fa1622f538fffdfe8cb438c02d805fae8913926debc615ee30e6fd9fdaa4926",
        "verifiedAt": "2026-10-05T12:41:38.639Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
      "product": "Zenition",
      "topic": "control",
      "text": "Zenition flat detector and image intensifier systems share a consistent control and handling approach.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299176331__Philips_Zenition_50_brochure_May%202022_Updated_LR.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
        "quote": "Experience the same intuitive control and handling on the Zenition Flat Detector and image intensifier systems.",
        "normalizedStart": 993,
        "contentSha256": "733f87e77cad9558c7a713cceb2a6c45ab7d6f35936375838b02b6961b5a72f0",
        "verifiedAt": "2026-10-05T12:41:46.178Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
      "product": "Zenition 50",
      "topic": "configuration",
      "text": "Zenition 50 system settings can be customized and exported to other Zenition 50 systems through Philips Support Connect.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299176331__Philips_Zenition_50_brochure_May%202022_Updated_LR.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
        "quote": "Customizing and exporting system settings to other Zenition 50 systems is simple with the embedded Philips Support Connect tool.",
        "normalizedStart": 2693,
        "contentSha256": "733f87e77cad9558c7a713cceb2a6c45ab7d6f35936375838b02b6961b5a72f0",
        "verifiedAt": "2026-10-05T12:41:46.178Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
      "product": "Zenition",
      "topic": "platform",
      "text": "Zenition systems use a standard Windows platform.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared%20Documents/Data%20Analytics/SSA_PAL_Filterted/452299176331__Philips_Zenition_50_brochure_May%202022_Updated_LR.pdf",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNNXPFLL6U5OFBZYGSQXPKO2CVJ",
        "quote": "Every Zenition system shares a standard Windows® platform and is ready to embrace new clinical applications and service and support technologies as they evolve.",
        "normalizedStart": 7677,
        "contentSha256": "733f87e77cad9558c7a713cceb2a6c45ab7d6f35936375838b02b6961b5a72f0",
        "verifiedAt": "2026-10-05T12:41:46.178Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
      "product": "Zenition 70",
      "topic": "platform",
      "text": "Zenition 70 uses a standard Windows platform.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 70 Product Brochure_Update_July_2024.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
        "quote": "Zenition 70, like every Zenition system, uses a standard Windows® platform, and is ready to embrace new clinical applications, service and support technologies as they evolve.",
        "normalizedStart": 1452,
        "contentSha256": "42a47eca6c61254284bd18bd22ed7b95fef97865d45f79f3b2a930a54b4855a3",
        "verifiedAt": "2026-10-05T12:44:11.673Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
      "product": "Zenition 70",
      "topic": "configuration",
      "text": "Zenition 70 system settings can be customized and exported to other Zenition 70 systems through Philips Support Connect.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 70 Product Brochure_Update_July_2024.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
        "quote": "System settings can be customized and exported to other Zenition 70 systems with the embedded Philips Support Connect tool.",
        "normalizedStart": 3176,
        "contentSha256": "42a47eca6c61254284bd18bd22ed7b95fef97865d45f79f3b2a930a54b4855a3",
        "verifiedAt": "2026-10-05T12:44:11.673Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
      "product": "Zenition 70",
      "topic": "continuous imaging",
      "text": "Zenition 70 is engineered for continuous imaging with a tank design that supports heat management during longer procedures.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 70 Product Brochure_Update_July_2024.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXNL423OBEFDZZE22C2ZZDEET4NP",
        "quote": "Zenition 70 is engineered for continuous imaging, with a tank design that helps enhance heat management.",
        "normalizedStart": 6022,
        "contentSha256": "42a47eca6c61254284bd18bd22ed7b95fef97865d45f79f3b2a930a54b4855a3",
        "verifiedAt": "2026-10-05T12:44:11.673Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "sourceId": "strategy-01J4NUPXOEMDUPGB3AOZAJMLB6H5SL6O4J",
      "product": "Zenition 30",
      "topic": "clinical application",
      "text": "Zenition 30 supports orthopedic, trauma, spine, pain-management, and other surgical procedures.",
      "indexMode": "content-extracted",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXOEMDUPGB3AOZAJMLB6H5SL6O4J",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/Zenition 30 Product Brochure.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXOEMDUPGB3AOZAJMLB6H5SL6O4J",
        "quote": "Leveraging Zenition’s well-established ease of use and workflow efficiency, Zenition 30 offers versatility for a range of clinical procedures which include orthopedics, trauma, spine, pain management and other surgical procedures.",
        "normalizedStart": 692,
        "contentSha256": "e1707acf409a704944c428f4aceb971e98ddaedeff83f71313c89ca1f07ec1e1",
        "verifiedAt": "2026-10-05T12:44:11.091Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "product": "EchoNavigator",
      "topic": "live image fusion",
      "text": "EchoNavigator fuses live transesophageal echocardiography and live fluoroscopic images in real time.",
      "aliases": [],
      "sourceId": "strategy-01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Cardiology__EchoNavigator__Brochure_Global__v1_20170914.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "quote": "EchoNavigator tackles this issue head-on by automatically fusing live TEE and live fluoroscopic images, in real-time.",
        "normalizedStart": 1778,
        "contentSha256": "8b4b7ed30a5aae7e5b4cfc08e2da111339c9417e23baa1a00a2f3feb058d6712",
        "verifiedAt": "2026-10-05T13:10:01.024Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "product": "EchoNavigator",
      "topic": "image alignment",
      "text": "EchoNavigator tracks the transesophageal echocardiography transducer so echo and X-ray images move together when the C-arm is repositioned.",
      "aliases": [],
      "sourceId": "strategy-01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Cardiology__EchoNavigator__Brochure_Global__v1_20170914.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "quote": "The TEE transducer position and orientation is automatically tracked in the X-ray image, allowing the echo and X-ray images to move in sync when the C-arm is repositioned.",
        "normalizedStart": 2012,
        "contentSha256": "8b4b7ed30a5aae7e5b4cfc08e2da111339c9417e23baa1a00a2f3feb058d6712",
        "verifiedAt": "2026-10-05T13:10:01.024Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "product": "EchoNavigator",
      "topic": "anatomical markers",
      "text": "EchoNavigator displays markers placed on soft-tissue structures in the echo image on the X-ray image for context and guidance.",
      "aliases": [],
      "sourceId": "strategy-01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Cardiology__EchoNavigator__Brochure_Global__v1_20170914.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "quote": "Markers placed on the soft tissue structures within the echo image automatically appear on the X-ray for context and guidance.",
        "normalizedStart": 2184,
        "contentSha256": "8b4b7ed30a5aae7e5b4cfc08e2da111339c9417e23baa1a00a2f3feb058d6712",
        "verifiedAt": "2026-10-05T13:10:01.024Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "product": "EchoNavigator",
      "topic": "tableside viewing",
      "text": "EchoNavigator allows views of anatomical structures in echo data to be changed from tableside.",
      "aliases": [],
      "sourceId": "strategy-01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/HS_IGT_Cardiology__EchoNavigator__Brochure_Global__v1_20170914.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXIE5HZOFWM5DZCKZACR63IIYJBM",
        "quote": "Changing views of the anatomical structures in the echo data can be carried out from tableside as required.",
        "normalizedStart": 2742,
        "contentSha256": "8b4b7ed30a5aae7e5b4cfc08e2da111339c9417e23baa1a00a2f3feb058d6712",
        "verifiedAt": "2026-10-05T13:10:01.024Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "product": "Allura 3D-RA",
      "topic": "3D visualization",
      "text": "Allura 3D-RA provides 3D visualization of vascular and cardiac pathologies from a single rotational angiographic X-ray acquisition.",
      "aliases": [
        "3D-RA"
      ],
      "sourceId": "strategy-01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/B1_Brochure_4522_962_93921_3D-RA_2013_05.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
        "quote": "Philips Allura 3D-RA provides extensive 3D visualization of vascular and cardiac pathologies from a single rotational angiographic X-ray acquisition.",
        "normalizedStart": 94,
        "contentSha256": "86f8db4f2977770fedda5361b08f5a67e1cabbc55f3622e8ede11dc1ab4ce28e",
        "verifiedAt": "2026-10-05T13:10:12.440Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    },
    {
      "product": "Allura 3D-RA",
      "topic": "user interface",
      "text": "Allura 3D-RA provides a menu wizard for navigating the user interface.",
      "aliases": [
        "3D-RA"
      ],
      "sourceId": "strategy-01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
      "evidence": {
        "sourceIdentity": "b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
        "sourceUrl": "https://share.philips.com/sites/IGT-SStrategyExecutionTransformation/Shared Documents/Data Analytics/SSA_PAL_Filterted/B1_Brochure_4522_962_93921_3D-RA_2013_05.pdf?web=1",
        "fetchUrl": "https://graph.microsoft.com/v1.0/drives/b!xWw3Q9nIpk-SKgsL9obn0yxOlcKsMcpFhmHyM0dPM3_eNZT54XnwSqtx7cAhQAit/items/01J4NUPXL63FJDXL2LZJGJALETAXWRSAKO",
        "quote": "Allura 3D-RA’s intuitive user interface includes a menu wizard for quick and easy navigation.",
        "normalizedStart": 1740,
        "contentSha256": "86f8db4f2977770fedda5361b08f5a67e1cabbc55f3622e8ede11dc1ab4ce28e",
        "verifiedAt": "2026-10-05T13:10:12.440Z",
        "reviewStatus": "screened",
        "reviewNote": "Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded."
      }
    }
  ]
};
