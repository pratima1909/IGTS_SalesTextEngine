"""Build the browser-ready DHF source index from the approved workbook."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "DHF373049_Azurion_Technical_Data_V8_final.xlsx"
OUTPUT = ROOT / "public" / "data" / "azurion-technical-facts.js"
TECHNICAL_SHEET = "Technical Data"
NON_FACT_SHEETS = {
    "Frontpage": "Workbook administration",
    "Revision History": "Revision administration",
}


def clean(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.9f}".rstrip("0").rstrip(".")
    return re.sub(r"\s+", " ", str(value)).strip()


def is_placeholder(value: str) -> bool:
    return value.lower().startswith("tag:") or (
        len(value) <= 2 and not any(character.isalnum() for character in value)
    )


def row_cells(values: tuple[object, ...]) -> list[dict[str, str]]:
    return [
        {"column": get_column_letter(index), "value": clean(value)}
        for index, value in enumerate(values, start=1)
        if clean(value)
    ]


def classify_sheet(name: str) -> str:
    lowered = name.lower()
    if "clarity" in lowered:
        return "Clarity dose reference"
    if lowered.startswith("fd"):
        return "Detector dose reference"
    if "air kerma" in lowered or "2gy" in lowered or "field size" in lowered:
        return "Dose reference"
    if lowered in {"x-ray protocol selection", "patient type", "oblique"}:
        return "Protocol dose reference"
    return "Technical reference"


value_book = openpyxl.load_workbook(SOURCE, data_only=True, read_only=True)
formula_book = openpyxl.load_workbook(SOURCE, data_only=False, read_only=True)

technical = value_book[TECHNICAL_SHEET]
applicability_headers = [clean(technical.cell(1, column).value) for column in range(2, 14)]
facts: list[dict[str, object]] = []

for row_number, values in enumerate(technical.iter_rows(values_only=True), start=1):
    item = clean(values[0] if len(values) > 0 else None)
    subitem = clean(values[14] if len(values) > 14 else None)
    parameter = clean(values[15] if len(values) > 15 else None)
    value = clean(values[16] if len(values) > 16 else None)
    if row_number == 1 or not all((item, subitem, parameter, value)) or is_placeholder(value):
        continue
    applicability = [
        applicability_headers[index]
        for index in range(12)
        if len(values) > index + 1 and clean(values[index + 1]).lower() == "x"
    ]
    facts.append(
        {
            "id": f"TD-{row_number}",
            "sheet": TECHNICAL_SHEET,
            "row": row_number,
            "item": item,
            "subitem": subitem,
            "parameter": parameter,
            "value": value,
            "applicability": applicability,
            "sourceKind": "product-fact",
        }
    )

supplemental_facts: list[dict[str, object]] = []
sheet_coverage: list[dict[str, object]] = []
populated_cell_count = 0
indexed_populated_cell_count = 0

for value_sheet, formula_sheet in zip(value_book.worksheets, formula_book.worksheets):
    populated_cells = 0
    formula_cells = 0
    indexed_rows = 0
    for row in formula_sheet.iter_rows():
        for cell in row:
            if cell.value not in (None, ""):
                populated_cells += 1
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    formula_cells += 1
    populated_cell_count += populated_cells

    if value_sheet.title not in NON_FACT_SHEETS and value_sheet.title != TECHNICAL_SHEET:
        for row_number, values in enumerate(value_sheet.iter_rows(values_only=True), start=1):
            cells = row_cells(values)
            if not cells:
                continue
            indexed_rows += 1
            indexed_populated_cell_count += len(cells)
            text = " | ".join(f"{cell['column']}: {cell['value']}" for cell in cells)
            supplemental_facts.append(
                {
                    "id": f"DHF-{len(supplemental_facts) + 1}",
                    "sheet": value_sheet.title,
                    "row": row_number,
                    "item": value_sheet.title,
                    "subitem": cells[0]["value"],
                    "parameter": cells[1]["value"] if len(cells) > 1 else value_sheet.title,
                    "value": text,
                    "applicability": [],
                    "sourceKind": "reference-row",
                    "category": classify_sheet(value_sheet.title),
                    "cells": cells,
                }
            )
    elif value_sheet.title == TECHNICAL_SHEET:
        indexed_rows = len(facts)
        indexed_populated_cell_count += populated_cells

    status = "Indexed"
    exclusion_reason = ""
    if value_sheet.title in NON_FACT_SHEETS:
        status = "Administrative"
        exclusion_reason = NON_FACT_SHEETS[value_sheet.title]
    sheet_coverage.append(
        {
            "name": value_sheet.title,
            "rows": value_sheet.max_row,
            "columns": value_sheet.max_column,
            "populatedCells": populated_cells,
            "formulaCells": formula_cells,
            "indexedRows": indexed_rows,
            "status": status,
            "category": "Administration" if status == "Administrative" else classify_sheet(value_sheet.title),
            "exclusionReason": exclusion_reason,
        }
    )

stat = SOURCE.stat()
payload = {
    "metadata": {
        "sourceFile": SOURCE.name,
        "sheetName": TECHNICAL_SHEET,
        "workbookRevision": "V8 final",
        "sourceModifiedAt": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
        "snapshotDate": datetime.now(timezone.utc).date().isoformat(),
        "workbookSheetCount": len(value_book.sheetnames),
        "indexedSheetCount": len(value_book.sheetnames) - len(NON_FACT_SHEETS),
        "administrativeSheetCount": len(NON_FACT_SHEETS),
        "populatedCellCount": populated_cell_count,
        "indexedPopulatedCellCount": indexed_populated_cell_count,
        "technicalFactCount": len(facts),
        "supplementalFactCount": len(supplemental_facts),
        "extractedFactCount": len(facts) + len(supplemental_facts),
        "generatedFromWorkbook": True,
        "coveragePolicy": "All substantive worksheets are indexed. Frontpage and Revision History are scanned for coverage but excluded from product-fact retrieval.",
        "sheetCoverage": sheet_coverage,
    },
    "facts": facts,
    "supplementalFacts": supplemental_facts,
}

OUTPUT.write_text(
    "// Generated locally from the complete DHF workbook; do not edit by hand.\n"
    "window.AZURION_TECHNICAL_DATA = "
    + json.dumps(payload, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
print(
    json.dumps(
        {
            "output": str(OUTPUT),
            "sheetsScanned": len(value_book.sheetnames),
            "sheetsIndexed": len(value_book.sheetnames) - len(NON_FACT_SHEETS),
            "technicalFacts": len(facts),
            "supplementalFacts": len(supplemental_facts),
            "populatedCells": populated_cell_count,
        }
    )
)
