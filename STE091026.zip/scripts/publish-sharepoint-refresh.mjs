// Publish only explicitly reviewed passages supported by this run's readable text.
// Usage: node scripts/publish-sharepoint-refresh.mjs <audit-directory> [--preview]
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const dir = process.argv[2] || 'tmp/refresh-2026-10-05';
const preview = process.argv.includes('--preview');
const date = path.basename(dir).replace(/^refresh-/,'');
assert.match(date,/^\d{4}-\d{2}-\d{2}$/);
const read = name=>JSON.parse(fs.readFileSync(`${dir}/${name}`,'utf8'));
const load = (name,key)=>{const c={window:{}};vm.runInNewContext(fs.readFileSync(`${dir}/before-${name}`,'utf8'),c);return c.window[key];};
const old = [load('sharepoint-product-facts.js','SHAREPOINT_PRODUCT_FACTS'),load('sales-portal-source.js','IGT_SALES_PORTAL_SOURCE')];
const priorRegisters = [load('sharepoint-source-manifest.js','SHAREPOINT_SOURCE_MANIFEST'),old[1]];
const observed = read('observed-final.json');
const decisions = read('decisions.json');
const enumeration = read('enumeration-audit.json');
const runs = fs.readdirSync(dir).filter(n=>/^(extraction|paced|retry)-.*\.json$/.test(n)).flatMap(n=>read(n)).sort((a,b)=>a.attemptedAt.localeCompare(b.attemptedAt));
const extracts = new Map(runs.map(r=>[r.itemId,r]));
const norm = s=>s.replace(/\s+/g,' ').trim();
const digest = s=>createHash('sha256').update(s).digest('hex');
function failure(error,code) {
  if(!error) return null;
  if(/413|file too large|104857600-byte/i.test(error)) return {code:'FILE_TOO_LARGE',reason:'Connector fetch limit: file exceeds 100 MiB'};
  if(/429|too many requests/i.test(error)) return {code:'RATE_LIMITED',reason:'Connector throttled extraction; no claims selected'};
  if(/Transport send error|ClientConnectorError|Cannot connect to host/i.test(error)) return {code:'CONNECTOR_CONNECTION_FAILED',reason:'Connector connection failed; no claims selected'};
  if(/401|403|forbidden|access denied/i.test(error)) return {code:'ACCESS_DENIED',reason:'Connector could not access file content'};
  if(/unsupported/i.test(error)) return {code:'UNSUPPORTED_FORMAT',reason:'Connector cannot extract this file format'};
  return {code:code||'EXTRACTION_FAILED',reason:'Connector extraction failed; no claims selected'};
}
function exclusion(title,text) {
  if (/internal|competition|competitive|competitor|counter|sales.?toolkit|messaging.?guide|battle.?card/i.test(title) || /(?:for )?internal use only|confidential.{0,15}internal/i.test(text)) return 'Internal or competitive content';
  if (/testimonial|customer.?story|case.?study|research|white.?paper|journal|clinical.?study|article|publication/i.test(title)) return 'Testimonial or research content';
  if (/training|education|cookbook|user.?guide|quick.?reference|mentice|manual|\bIFU\b/i.test(title) || /instructions for use/i.test(text.slice(0,600))) return 'Training, instructions or regulatory-use content';
  if (/declaration|conformity|\bMDS2\b|regulatory|certificate|DoComp|compatibility.?statement/i.test(title)) return 'Regulatory or compatibility document';
  if (/global.?non.?us|non.?us|\bUS.?only\b/i.test(title) || /not\s+(?:available\s+for\s+sale|available\s+in\s+(?:the\s+)?(?:U\.?S|United States|Europe|China|all (?:markets|countries|regions))|for\s+(?:use\s+or\s+)?(?:distribution|sale|use)\s+in|approved\s+in\s+all countries)|(?:cannot|can not)\s+be\s+distributed|limited number of countries|not CE marked|work in progress/i.test(text)) return 'Market-restricted or uncleared product content';
  if (/[_ -](?:zh|ja|ko|de|fr|es|pt|it|ru|vi|nl|pl|tr|ar)[_-][a-z]{2}\b/i.test(title)) return 'Incompatible language';
  if (!/brochure|specification|product[ _-]*overview|leaflet|leave[ _-]*behind|one[ _-]*pager/i.test(title)) return 'Document suitability not established';
  return null;
}
const review = [];
const output = observed.map((records,collection)=>{
  const documents = records.map(r=>{
    const e=extracts.get(r.item_id);
    if (!preview) {
      assert.ok(e,`No extraction attempt: ${r.title}`);
      assert.ok(e.attemptedAt.slice(0,10)>=date,`Stale extraction attempt: ${r.title}`);
    }
    const text=norm(e?.text||'');
    const error=e?.error;
    const errorInfo=failure(error,e?.errorCode);
    const reason=errorInfo?errorInfo.reason:!text?'No readable text returned':exclusion(r.title,text)||'No screened product passage selected';
    return {id:(collection?'portal-':'strategy-')+r.item_id,stableIdentity:r.drive_id+'/'+r.item_id,driveId:r.drive_id,itemId:r.item_id,title:r.title,updatedAt:r.updated_at,sizeBytes:r.size_bytes,url:r.web_url,fetchUrl:r.url,mimeType:r.mimetype,observedAt:date,source:r.listed?'folder-page':'search',contentStatus:!e?'pending':error?'failed':text?'indexed':'unreadable',extractionAttemptedAt:e?.attemptedAt||null,extractionErrorCode:errorInfo?.code||null,extractionAttemptCount:runs.filter(x=>x.itemId===r.item_id).length,extractedCharacterCount:text.length,contentSha256:text?digest(e.text):null,factCount:0,selectionStatus:'excluded',exclusionReason:reason};
  }).sort((a,b)=>a.title.localeCompare(b.title)||a.id.localeCompare(b.id));
  const facts=[];
  for (const decision of decisions.filter(d=>Number(d.key.split(':')[0])===collection)) {
    const priorFact=decision.itemId ? {product:decision.product,topic:decision.topic,text:decision.text,aliases:decision.aliases||[]} : old[collection].facts[Number(decision.key.split(':')[1])];
    assert.ok(priorFact?.product && priorFact?.topic && priorFact?.text,`Unknown or incomplete review key ${decision.key}`);
    const priorDoc=decision.itemId?null:old[collection].documents.find(d=>d.id===priorFact.sourceId);
    const matches=documents.filter(d=>decision.itemId?d.itemId===decision.itemId:d.title===priorDoc.title);
    assert.equal(matches.length,1,`Ambiguous or absent identity for ${decision.itemId||priorDoc.title}`);
    const doc=matches[0],e=extracts.get(doc.itemId),text=norm(e?.text||'');
    const blocked=doc.contentStatus!=='indexed'?doc.exclusionReason:exclusion(doc.title,text);
    assert.ok(!blocked,`Reviewed document fails gate: ${doc.title}: ${blocked}`);
    const quote=norm(decision.quote),offset=text.indexOf(quote);
    assert.ok(offset>=0,`Supporting quote missing for ${decision.key}`);
    const fact={...priorFact,sourceId:doc.id,...(decision.product?{product:decision.product}:{}),...(decision.text?{text:decision.text}:{})};
    delete fact.markets;
    assert.doesNotMatch(fact.text,/\b(?:optional|option|options|best|superior|unique|guarantee|competitor)\b/i);
    assert.doesNotMatch(quote,/\b(?:optional|option)\b/i);
    fact.evidence={sourceIdentity:doc.stableIdentity,sourceUrl:doc.url,fetchUrl:doc.fetchUrl,quote,normalizedStart:offset,contentSha256:doc.contentSha256,verifiedAt:e.attemptedAt,reviewStatus:'screened',reviewNote:'Product-specific English passage reviewed in customer-facing documentation; internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported and market-restricted claims excluded.'};
    facts.push(fact);doc.factCount++;doc.selectionStatus='selected';doc.exclusionReason=null;
    if(decision.itemId) review.push({key:decision.key,product:fact.product,text:fact.text,sourceIdentity:doc.stableIdentity,sourceTitle:doc.title,decision:'new selected fact',reason:'Newly observed customer-facing source; exact product passage reviewed'});
  }
  old[collection].facts.forEach((f,index)=>{const d=old[collection].documents.find(d=>d.id===f.sourceId);const current=documents.find(x=>x.title===d.title);review.push({previousKey:`${collection}:${index}`,product:f.product,previousText:f.text,sourceTitle:d.title,decision:decisions.some(x=>x.key===`${collection}:${index}`)?'selected or narrowed':'withheld',reason:decisions.some(x=>x.key===`${collection}:${index}`)?'Verified against an exact readable passage':current?.exclusionReason||'Passage not retained: optional, unsupported, duplicate or insufficiently specific evidence'});});
  const indexed=documents.filter(d=>d.contentStatus==='indexed').length;
  const failed=documents.filter(d=>d.contentStatus==='failed').length;
  const unreadable=documents.filter(d=>d.contentStatus==='unreadable').length;
  const factDocs=documents.filter(d=>d.factCount>0).length;
  const attempt=documents.filter(d=>d.extractionAttemptedAt).length;
  const limitation=(collection?'The connector cannot address All Sales Assets through folder listing; site and library-path search result sets were combined. A PDF search hit the 500-result cap.':'The folder listing returned 200 files and a continuation URL, but the connector exposes no continuation input. Site and folder-path searches supplement that first page.')+' Search supports text-friendly formats only; other file types may be absent from search discovery.';
  const metadata={...old[collection].metadata,snapshotDate:date,observedDocumentCount:documents.length,observedFileCount:documents.length,registeredDocumentCount:documents.length,reachableDocumentCount:documents.filter(d=>d.contentStatus==='indexed'||d.contentStatus==='unreadable').length,inspectedFileCount:attempt,contentExtractionAttemptedDocumentCount:attempt,contentIndexedDocumentCount:indexed,contentReadDocumentCount:indexed,extractionFailedDocumentCount:failed,unreadableDocumentCount:unreadable,factBackedDocumentCount:factDocs,documentCount:factDocs,factCount:facts.length,enumerationComplete:false,authoritativeLibraryTotal:null,continuationAvailable:collection?false:true,searchQueries:enumeration[collection].queries.map(q=>q.query),selectionPolicy:'Register every observed identity and attempt readable-content extraction. Only individually screened English product passages from suitable customer-facing or approved documents contribute claims. Internal, competitive, testimonial, research, training, regulatory, optional-feature, unsupported, incompatible-language and market-restricted content is excluded.',coverageNote:`${date}: ${documents.length} unique connector-observed files registered; extraction attempted for ${attempt}. ${indexed} returned readable text (${(100*indexed/documents.length).toFixed(1)}%); ${unreadable} returned no text and ${failed} failed. ${facts.length} screened facts from ${factDocs} documents. ${limitation} Search coverage is not an authoritative SharePoint library total; exhaustive enumeration cannot be certified.`,refreshNote:`Refreshed ${date}; extraction outcomes and evidence passages verified for this run.`,enumerationAudit:enumeration[collection]};
  if(!collection){metadata.listedFileCount=documents.filter(d=>d.source==='folder-page').length;metadata.searchDiscoveredFileCount=documents.length-metadata.listedFileCount;}
  metadata.extractionFailureCounts=documents.filter(d=>d.contentStatus==='failed').reduce((counts,d)=>({...counts,[d.extractionErrorCode]:(counts[d.extractionErrorCode]||0)+1}),{});
  const failedQueries=enumeration[collection].queries.filter(q=>q.returned===null);
  if(failedQueries.length) metadata.coverageNote += ` ${failedQueries.length} search partition failed after retry (${failedQueries.map(q=>q.outcome).join('; ')}).`;
  metadata.coverageNote += ` Failure reasons: ${Object.entries(metadata.extractionFailureCounts).map(([reason,count])=>`${reason.replace(/_/g,' ').toLowerCase()}: ${count}`).join('; ') || 'none'}.`;
  const historicalDocuments=priorRegisters[collection].documents.filter(d=>!documents.some(x=>x.title===d.title||x.id===d.id)).map(d=>({...d,status:'Previously observed; not reobserved this run',previousSnapshotDate:priorRegisters[collection].metadata.snapshotDate}));
  metadata.previouslyObservedNotReobservedCount=historicalDocuments.length;
  return {metadata,documents,facts,historicalDocuments};
});
const stage=path.join(dir,'validated');fs.mkdirSync(stage,{recursive:true});
const write=(name,key,data)=>fs.writeFileSync(path.join(stage,name),`// Screened SharePoint refresh ${date}; observed coverage is not an authoritative total.\nwindow.${key} = ${JSON.stringify(data,null,2)};\n`);
write('sharepoint-source-manifest.js','SHAREPOINT_SOURCE_MANIFEST',{metadata:output[0].metadata,documents:output[0].documents,historicalDocuments:output[0].historicalDocuments});
write('sharepoint-product-facts.js','SHAREPOINT_PRODUCT_FACTS',{metadata:output[0].metadata,documents:output[0].documents.filter(d=>d.factCount>0),facts:output[0].facts});
write('sales-portal-source.js','IGT_SALES_PORTAL_SOURCE',output[1]);
fs.writeFileSync(path.join(stage,'sharepoint-refresh-review.json'),JSON.stringify({date,review},null,2));
if(!preview) {
  for(const file of fs.readdirSync(stage))fs.copyFileSync(path.join(stage,file),path.join('public/data',file));
  // A new script URL bypasses prior one-hour browser caches when the local app reloads.
  let html=fs.readFileSync('index.html','utf8');
  for(const name of ['sharepoint-source-manifest.js','sharepoint-product-facts.js','sales-portal-source.js']) {
    const version=digest(fs.readFileSync(path.join(stage,name))).slice(0,12);
    const pattern=new RegExp(`public/data/${name.replace(/\./g,'\\.')}[^"']*`,'g');
    html=html.replace(pattern,`public/data/${name}?v=${date}-${version}`);
  }
  fs.writeFileSync('index.html',html);
}
console.log(JSON.stringify(output.map(s=>({source:s.metadata.sourceName,observed:s.documents.length,attempted:s.metadata.contentExtractionAttemptedDocumentCount,readable:s.metadata.contentIndexedDocumentCount,failed:s.metadata.extractionFailedDocumentCount,unreadable:s.metadata.unreadableDocumentCount,factDocuments:s.metadata.factBackedDocumentCount,facts:s.facts.length,historical:s.historicalDocuments.length,published:!preview})),null,2));
