import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import XLSX from "xlsx";

const ROOT = path.resolve(import.meta.dirname, "..");
const DEFAULT_SOURCE = "Sales Text Data September 2026.xlsx";
const SOURCE = path.resolve(ROOT, process.argv[2] || DEFAULT_SOURCE);
const OUTPUT_DIR = path.resolve(ROOT, "public", "data");

const FIELDS = [
  ["Business", "business"],
  ["Business Unit", "businessUnit"],
  ["Business Category", "businessCategory"],
  ["MRU", "mru"],
  ["MAG Code", "magCode"],
  ["MAG Name", "magName"],
  ["AG Code", "agCode"],
  ["AG Name", "agName"],
  ["ID", "id"],
  ["Name", "name"],
  ["Item type", "itemType"],
  ["Short Sales Text", "shortText"],
  ["Length Short Sales text", "shortLength", "number"],
  ["Short Sales Text Bucket", "shortBucket"],
  ["Long Sales Text", "longText"],
  ["Length Long Sales text", "longLength", "number"],
  ["Long Sales Text Bucket", "longBucket"],
  ["Sales text flag", "salesTextFlag"],
  ["Ownership", "ownership"],
];

function cleanText(value) {
  return String(value ?? "")
    .replace(/\u00a0/g, " ")
    .replace(/\r\n?/g, "\n")
    .split("\n")
    .map((line) => line.trim())
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function numericValue(value) {
  if (value === "" || value == null) return 0;
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) throw new Error(`Expected a number but received “${value}”.`);
  return parsed;
}

if (!fs.existsSync(SOURCE)) throw new Error(`Source workbook not found: ${SOURCE}`);

const workbook = XLSX.readFile(SOURCE, { raw: false });
if (!workbook.SheetNames.length) throw new Error("The source workbook does not contain a worksheet.");
const sourceSheet = workbook.SheetNames[0];
const rows = XLSX.utils.sheet_to_json(workbook.Sheets[sourceSheet], { defval: "", raw: false });
const headers = Object.keys(rows[0] || {});
const requiredHeaders = FIELDS.map(([header]) => header);
const missingHeaders = requiredHeaders.filter((header) => !headers.includes(header));
if (missingHeaders.length) throw new Error(`Missing required columns: ${missingHeaders.join(", ")}`);

const items = rows.map((row, rowIndex) => Object.fromEntries(FIELDS.map(([header, key, type]) => {
  const value = type === "number" ? numericValue(row[header]) : cleanText(row[header]);
  if (key === "id" && !value) throw new Error(`Missing item ID on workbook row ${rowIndex + 2}.`);
  return [key, value];
})));

const duplicateIds = items
  .map((item) => item.id)
  .filter((id, index, allIds) => allIds.indexOf(id) !== index);
if (duplicateIds.length) throw new Error(`Duplicate item IDs found: ${[...new Set(duplicateIds)].slice(0, 10).join(", ")}`);

const sourceStats = fs.statSync(SOURCE);
const payload = {
  metadata: {
    source: path.basename(SOURCE),
    sourceSheet,
    sourceModifiedAt: sourceStats.mtime.toISOString(),
    itemCount: items.length,
    fields: requiredHeaders,
  },
  items,
};

fs.mkdirSync(OUTPUT_DIR, { recursive: true });
fs.writeFileSync(path.join(OUTPUT_DIR, "items.json"), JSON.stringify(payload));
fs.writeFileSync(path.join(OUTPUT_DIR, "items-data.js"), `window.SALES_DATA = ${JSON.stringify(payload)};\n`);

const withShortText = items.filter((item) => item.shortText && item.shortText !== "-").length;
const withLongText = items.filter((item) => item.longText && item.longText !== "-").length;
console.log(JSON.stringify({
  source: payload.metadata.source,
  sheet: sourceSheet,
  itemCount: items.length,
  withShortText,
  withLongText,
  outputs: ["public/data/items.json", "public/data/items-data.js"],
}, null, 2));
