// Prepare evidence candidates for human/agent review; this never publishes facts.
import fs from 'node:fs';
import vm from 'node:vm';
const dir = process.argv[2] || 'tmp/refresh-2026-10-05';
const load = (name, key) => { const c = {window:{}}; vm.runInNewContext(fs.readFileSync(`${dir}/before-${name}`, 'utf8'), c); return c.window[key]; };
const sources = [load('sharepoint-product-facts.js','SHAREPOINT_PRODUCT_FACTS'),load('sales-portal-source.js','IGT_SALES_PORTAL_SOURCE')];
const observed = JSON.parse(fs.readFileSync(`${dir}/observed-final.json`, 'utf8'));
const runs = fs.readdirSync(dir).filter(n=>/^(extraction|paced|retry)-.*\.json$/.test(n)).flatMap(n=>JSON.parse(fs.readFileSync(`${dir}/${n}`,'utf8'))).sort((a,b)=>a.attemptedAt.localeCompare(b.attemptedAt));
const extracts = new Map(runs.map(r=>[r.itemId,r]));
const norm = s=>s.replace(/\s+/g,' ').trim();
const words = s=>new Set(s.toLowerCase().match(/[a-z0-9]+/g)?.filter(w=>w.length>3)||[]);
const report = [];
sources.forEach((source,collection)=>source.facts.forEach((fact,index)=>{
  const doc = source.documents.find(d=>d.id===fact.sourceId);
  const record = observed[collection].find(r=>r.title===doc?.title);
  const extract = record && extracts.get(record.item_id);
  const text = norm(extract?.text||'');
  const tokens = words(fact.text);
  const chunks = text.match(/[^.!?]+[.!?]+(?:\s|$)|[^.!?]+$/g)||[];
  const candidates = chunks.map((s,i)=>({quote:chunks.slice(Math.max(0,i-1),i+2).join('').trim(),score:[...tokens].filter(w=>words(s).has(w)).length/tokens.size})).sort((a,b)=>b.score-a.score).slice(0,2);
  const restriction = text.match(/.{0,70}(?:not (?:for (?:distribution|sale|use)|available|commercially available) (?:in |for )?(?:the )?(?:US|USA|United States)|internal use only|for internal use|for training|instructions for use|competitive intelligence).{0,80}/ig)||[];
  report.push({key:`${collection}:${index}`,collection,title:doc?.title,product:fact.product,fact:fact.text,itemId:record?.item_id,status:extract?.error||(!text?'pending':'readable'),restriction:[...new Set(restriction)].slice(0,6),candidates});
}));
fs.writeFileSync(`${dir}/candidates.json`,JSON.stringify(report,null,2));
console.log(JSON.stringify({candidates:report.length,readable:report.filter(x=>x.status==='readable').length,observed:observed.map(a=>a.length),attempted:extracts.size,readableDocuments:[...extracts.values()].filter(r=>r.text.trim()).length}));
