const elements = {
  search: document.querySelector("#searchInput"),
  clearSearch: document.querySelector("#clearSearch"),
  typeFilter: document.querySelector("#typeFilter"),
  availabilityFilter: document.querySelector("#availabilityFilter"),
  resetFilters: document.querySelector("#resetFilters"),
  resultCount: document.querySelector("#resultCount"),
  resultList: document.querySelector("#resultList"),
  emptyResults: document.querySelector("#emptyResults"),
  loadMore: document.querySelector("#loadMore"),
  sourceLabel: document.querySelector("#sourceLabel"),
  openCoverage: document.querySelector("#openCoverage"),
  closeCoverage: document.querySelector("#closeCoverage"),
  coverageBackdrop: document.querySelector("#coverageBackdrop"),
  coveragePanel: document.querySelector("#coveragePanel"),
  coverageAsOf: document.querySelector("#coverageAsOf"),
  coverageSummary: document.querySelector("#coverageSummary"),
  dhfCoverageBadge: document.querySelector("#dhfCoverageBadge"),
  dhfCoverageKpis: document.querySelector("#dhfCoverageKpis"),
  dhfCoverageNote: document.querySelector("#dhfCoverageNote"),
  spCoverageBadge: document.querySelector("#spCoverageBadge"),
  spCoverageKpis: document.querySelector("#spCoverageKpis"),
  spCoverageNote: document.querySelector("#spCoverageNote"),
  portalCoverageBadge: document.querySelector("#portalCoverageBadge"),
  portalCoverageKpis: document.querySelector("#portalCoverageKpis"),
  portalCoverageNote: document.querySelector("#portalCoverageNote"),
  coverageSheetCount: document.querySelector("#coverageSheetCount"),
  coverageSheetList: document.querySelector("#coverageSheetList"),
  coverageDocumentCount: document.querySelector("#coverageDocumentCount"),
  coverageDocumentList: document.querySelector("#coverageDocumentList"),
  portalDocumentCount: document.querySelector("#portalDocumentCount"),
  portalDocumentList: document.querySelector("#portalDocumentList"),
  loadingState: document.querySelector("#loadingState"),
  detailEmpty: document.querySelector("#detailEmpty"),
  detailContent: document.querySelector("#detailContent"),
  breadcrumb: document.querySelector("#breadcrumb"),
  itemId: document.querySelector("#itemId"),
  itemType: document.querySelector("#itemType"),
  itemName: document.querySelector("#itemName"),
  quickMeta: document.querySelector("#quickMeta"),
  shortTab: document.querySelector("#shortTab"),
  longTab: document.querySelector("#longTab"),
  textLength: document.querySelector("#textLength"),
  salesText: document.querySelector("#salesText"),
  copyCurrent: document.querySelector("#copyCurrent"),
  copyCurrentTop: document.querySelector("#copyCurrentTop"),
  salesFlag: document.querySelector("#salesFlag"),
  detailsGrid: document.querySelector("#detailsGrid"),
  toast: document.querySelector("#toast"),
  openComposer: document.querySelector("#openComposer"),
  closeComposer: document.querySelector("#closeComposer"),
  composerBackdrop: document.querySelector("#composerBackdrop"),
  composerPanel: document.querySelector("#composerPanel"),
  historyList: document.querySelector("#historyList"),
  historyEmpty: document.querySelector("#historyEmpty"),
  historyCount: document.querySelector("#historyCount"),
  composerForm: document.querySelector("#composerForm"),
  localStatus: document.querySelector("#localStatus"),
  generateDraft: document.querySelector("#generateDraft"),
  generateLabel: document.querySelector(".generate-label"),
  generateLoading: document.querySelector(".generate-loading"),
  draftItemName: document.querySelector("#draftItemName"),
  draftKeywords: document.querySelector("#draftKeywords"),
  draftDocuments: document.querySelector("#draftDocuments"),
  draftDocumentList: document.querySelector("#draftDocumentList"),
  draftDocumentStatus: document.querySelector("#draftDocumentStatus"),
  draftFacts: document.querySelector("#draftFacts"),
  sourceFactStatus: document.querySelector("#sourceFactStatus"),
  draftAudience: document.querySelector("#draftAudience"),
  draftFeedback: document.querySelector("#draftFeedback"),
  draftFeedbackStatus: document.querySelector("#draftFeedbackStatus"),
  generateActionText: document.querySelector("#generateActionText"),
  draftEmpty: document.querySelector("#draftEmpty"),
  draftResult: document.querySelector("#draftResult"),
  draftError: document.querySelector("#draftError"),
  draftShortTab: document.querySelector("#draftShortTab"),
  draftLongTab: document.querySelector("#draftLongTab"),
  draftEditor: document.querySelector("#draftEditor"),
  draftCount: document.querySelector("#draftCount"),
  copyDraft: document.querySelector("#copyDraft"),
  draftModel: document.querySelector("#draftModel"),
  draftTrace: document.querySelector("#draftTrace"),
  draftReferences: document.querySelector("#draftReferences"),
  technicalSourceSummary: document.querySelector("#technicalSourceSummary"),
  technicalFacts: document.querySelector("#technicalFacts"),
  localDocumentSourceSummary: document.querySelector("#localDocumentSourceSummary"),
  localDocumentFacts: document.querySelector("#localDocumentFacts"),
  sharePointSourceSummary: document.querySelector("#sharePointSourceSummary"),
  sharePointFacts: document.querySelector("#sharePointFacts"),
  salesPortalSourceSummary: document.querySelector("#salesPortalSourceSummary"),
  salesPortalFacts: document.querySelector("#salesPortalFacts"),
  factWarnings: document.querySelector("#factWarnings"),
};

const state = {
  items: [],
  filtered: [],
  selected: null,
  activeText: "short",
  visible: 50,
  query: "",
  type: "all",
  availability: "all",
  drafts: null,
  activeDraft: "short",
  technicalSource: null,
  technicalFacts: [],
  sharePointSource: null,
  sharePointManifest: null,
  sharePointDocuments: new Map(),
  sharePointFacts: [],
  salesPortalSource: null,
  salesPortalManifest: null,
  salesPortalDocuments: new Map(),
  salesPortalFacts: [],
  supportingFiles: [],
  history: [],
  currentHistoryId: null,
};

const normalize = (value) => String(value ?? "")
  .normalize("NFKD")
  .replace(/[\u0300-\u036f]/g, "")
  .toLowerCase();

const GUIDANCE_STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is", "it",
  "of", "on", "or", "that", "the", "this", "to", "with", "your", "new", "item", "product",
]);

const TECHNICAL_STOP_WORDS = new Set([
  ...GUIDANCE_STOP_WORDS,
  "azurion", "philips", "system", "systems", "offering", "solution", "equipment", "feature", "features",
]);

const formatNumber = new Intl.NumberFormat("en-US");
const historyDateFormat = new Intl.DateTimeFormat("en-GB", {
  day: "2-digit",
  month: "short",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
});
const HISTORY_STORAGE_KEY = "igt-sales-text-history-v1";
const HISTORY_LIMIT = 100;
const MAX_SUPPORTING_FILES = 10;
const MAX_SUPPORTING_FILE_BYTES = 10 * 1024 * 1024;
const MAX_SUPPORTING_TOTAL_BYTES = 25 * 1024 * 1024;
const SUPPORTED_SUPPORTING_EXTENSIONS = new Set(["csv", "docx", "json", "md", "pdf", "pptx", "txt", "xlsx"]);
const GUIDANCE_LABEL = "Product Description and Sales Text Guidelines, pages 15-29";
const displayValue = (value) => value || "—";
let toastTimer;
let searchTimer;
let historyUpdateTimer;

function catalogueSourceLabel(metadata) {
  const count = formatNumber.format(metadata?.itemCount || 0);
  const vintage = String(metadata?.source || "").match(/([A-Za-z]+\s+\d{4})\.xlsx$/i)?.[1];
  return `${count} catalogue items${vintage ? ` · ${vintage}` : ""}`;
}

function makeSearchIndex(item) {
  return normalize([
    item.id, item.name, item.shortText, item.longText, item.magCode, item.magName,
    item.agCode, item.agName, item.itemType, item.businessCategory, item.mru,
  ].join(" \u241f "));
}

function scoreItem(item, normalizedQuery, tokens) {
  if (!tokens.every((token) => item._search.includes(token))) return -1;
  if (!normalizedQuery) return 0;

  const id = normalize(item.id);
  const name = normalize(item.name);
  const shortText = normalize(item.shortText);
  const longText = normalize(item.longText);
  const mag = normalize(`${item.magCode} ${item.magName}`);
  const ag = normalize(`${item.agCode} ${item.agName}`);

  let score = 0;
  if (id === normalizedQuery) score += 1200;
  else if (id.startsWith(normalizedQuery)) score += 780;
  else if (id.includes(normalizedQuery)) score += 520;
  if (name === normalizedQuery) score += 1000;
  else if (name.startsWith(normalizedQuery)) score += 720;
  else if (name.includes(normalizedQuery)) score += 460;
  if (shortText.includes(normalizedQuery)) score += 270;
  if (longText.includes(normalizedQuery)) score += 180;
  if (mag.includes(normalizedQuery)) score += 160;
  if (ag.includes(normalizedQuery)) score += 130;
  score += tokens.reduce((total, token) => total + (name.includes(token) ? 35 : 0) + (shortText.includes(token) ? 20 : 0), 0);
  return score;
}

function hasRequestedText(item) {
  const hasShort = Boolean(item.shortText.trim());
  const hasLong = Boolean(item.longText.trim());
  if (state.availability === "both") return hasShort && hasLong;
  if (state.availability === "short") return hasShort;
  if (state.availability === "long") return hasLong;
  return true;
}

function applySearch({ preserveSelection = true } = {}) {
  const normalizedQuery = normalize(state.query.trim());
  const tokens = normalizedQuery.split(/\s+/).filter(Boolean);

  state.filtered = state.items
    .filter((item) => state.type === "all" || item.itemType === state.type)
    .filter(hasRequestedText)
    .map((item) => ({ item, score: scoreItem(item, normalizedQuery, tokens) }))
    .filter((result) => result.score >= 0)
    .sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name))
    .map((result) => result.item);

  state.visible = 50;
  elements.resultCount.textContent = formatNumber.format(state.filtered.length);
  elements.clearSearch.hidden = !state.query;
  elements.resetFilters.hidden = !(state.query || state.type !== "all" || state.availability !== "all");
  elements.emptyResults.hidden = state.filtered.length > 0;
  elements.resultList.hidden = state.filtered.length === 0;

  if (!preserveSelection || (state.selected && !state.filtered.includes(state.selected))) {
    state.selected = null;
    showEmptyDetail();
  }

  renderResults();
}

function getSnippet(item) {
  const query = normalize(state.query.trim());
  const candidates = [
    { label: "Long", text: item.longText },
    { label: "Short", text: item.shortText },
  ];
  const source = candidates.find(({ text }) => query && normalize(text).includes(query))
    || candidates.find(({ text }) => text.trim())
    || { label: "Text", text: "No sales text available" };
  const compact = source.text.replace(/\s+/g, " ").trim();
  const matchIndex = query ? normalize(compact).indexOf(query) : 0;
  const start = Math.max(0, matchIndex - 55);
  const excerpt = compact.slice(start, start + 170);
  return `${source.label}: ${start > 0 ? "…" : ""}${excerpt}${start + 170 < compact.length ? "…" : ""}`;
}

function renderResults() {
  const visibleItems = state.filtered.slice(0, state.visible);
  const fragment = document.createDocumentFragment();

  visibleItems.forEach((item) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "result-item";
    button.setAttribute("role", "option");
    button.setAttribute("aria-selected", String(state.selected?.id === item.id));
    button.dataset.id = item.id;

    const kicker = document.createElement("div");
    kicker.className = "result-kicker";
    const id = document.createElement("span");
    id.className = "result-id";
    id.textContent = item.id || "No ID";
    const type = document.createElement("span");
    type.textContent = item.itemType.replaceAll("_", " ") || "Item";
    kicker.append(id, type);

    const title = document.createElement("h3");
    title.textContent = item.name || "Unnamed item";
    const snippet = document.createElement("p");
    snippet.className = "result-snippet";
    snippet.textContent = getSnippet(item);

    const tags = document.createElement("div");
    tags.className = "result-tags";
    const group = document.createElement("span");
    group.className = "mini-tag";
    group.textContent = item.agName || item.magName || item.businessCategory || "Uncategorised";
    tags.append(group);
    if (item.longText) {
      const textStatus = document.createElement("span");
      textStatus.className = "text-dot";
      textStatus.textContent = "Long text";
      tags.append(textStatus);
    }

    button.append(kicker, title, snippet, tags);
    button.addEventListener("click", () => selectItem(item));
    fragment.append(button);
  });

  elements.resultList.replaceChildren(fragment);
  elements.loadMore.hidden = state.visible >= state.filtered.length || state.filtered.length === 0;
  if (!elements.loadMore.hidden) {
    elements.loadMore.textContent = `Show more · ${formatNumber.format(state.filtered.length - state.visible)} remaining`;
  }
}

function selectItem(item, { updateHash = true } = {}) {
  state.selected = item;
  const query = normalize(state.query.trim());
  const longMatches = query && normalize(item.longText).includes(query);
  const shortMatches = query && normalize(item.shortText).includes(query);
  state.activeText = longMatches && !shortMatches ? "long" : item.shortText ? "short" : "long";
  renderResults();
  renderDetail();
  if (updateHash) history.replaceState(null, "", `#id=${encodeURIComponent(item.id)}`);
  if (window.innerWidth <= 900) document.querySelector(".detail-panel").scrollIntoView({ behavior: "smooth" });
}

function createBreadcrumb(item) {
  const values = [item.businessUnit, item.businessCategory, item.mru].filter(Boolean);
  const fragment = document.createDocumentFragment();
  values.forEach((value) => {
    const span = document.createElement("span");
    span.textContent = value;
    fragment.append(span);
  });
  return fragment;
}

function renderQuickMeta(item) {
  const entries = [
    ["MAG", [item.magCode, item.magName].filter(Boolean).join(" · ")],
    ["AG", [item.agCode, item.agName].filter(Boolean).join(" · ")],
    ["Owner", item.ownership],
  ].filter(([, value]) => value);
  const fragment = document.createDocumentFragment();
  entries.forEach(([label, value]) => {
    const span = document.createElement("span");
    span.className = "quick-meta-item";
    const strong = document.createElement("strong");
    strong.textContent = `${label}:`;
    span.append(strong, document.createTextNode(value));
    fragment.append(span);
  });
  elements.quickMeta.replaceChildren(fragment);
  elements.quickMeta.hidden = entries.length === 0;
}

function renderDetails(item) {
  const entries = [
    ["Business", item.business],
    ["Business unit", item.businessUnit],
    ["Business category", item.businessCategory],
    ["MRU", item.mru],
    ["MAG", [item.magCode, item.magName].filter(Boolean).join(" — ")],
    ["AG", [item.agCode, item.agName].filter(Boolean).join(" — ")],
    ["Item type", item.itemType.replaceAll("_", " ")],
    ["Ownership", item.ownership],
    ["Short text bucket", item.shortBucket],
    ["Long text bucket", item.longBucket],
  ];
  const fragment = document.createDocumentFragment();
  entries.forEach(([label, value]) => {
    const wrapper = document.createElement("div");
    const term = document.createElement("dt");
    const description = document.createElement("dd");
    term.textContent = label;
    description.textContent = displayValue(value);
    wrapper.append(term, description);
    fragment.append(wrapper);
  });
  elements.detailsGrid.replaceChildren(fragment);
}

function renderDetail() {
  const item = state.selected;
  if (!item) return showEmptyDetail();
  elements.loadingState.hidden = true;
  elements.detailEmpty.hidden = true;
  elements.detailContent.hidden = false;
  elements.breadcrumb.replaceChildren(createBreadcrumb(item));
  elements.itemId.textContent = `ID ${item.id}`;
  elements.itemType.textContent = item.itemType.replaceAll("_", " ");
  elements.itemName.textContent = item.name || "Unnamed item";
  elements.shortTab.disabled = !item.shortText;
  elements.longTab.disabled = !item.longText;
  elements.salesFlag.textContent = item.salesTextFlag;
  renderQuickMeta(item);
  renderDetails(item);
  renderActiveText();
}

function renderActiveText() {
  if (!state.selected) return;
  const isShort = state.activeText === "short";
  const text = isShort ? state.selected.shortText : state.selected.longText;
  elements.shortTab.setAttribute("aria-selected", String(isShort));
  elements.longTab.setAttribute("aria-selected", String(!isShort));
  elements.salesText.textContent = text || `No ${isShort ? "short" : "long"} sales text is available for this item.`;
  elements.salesText.classList.toggle("is-empty", !text);
  const actualLength = text.length;
  elements.textLength.textContent = `${formatNumber.format(actualLength)} characters`;
  const label = `Copy ${isShort ? "short" : "long"} text`;
  elements.copyCurrent.setAttribute("aria-label", label);
  elements.copyCurrentTop.querySelector("span").textContent = label;
  elements.copyCurrent.disabled = !text;
  elements.copyCurrentTop.disabled = !text;
}

function showEmptyDetail() {
  elements.loadingState.hidden = true;
  elements.detailContent.hidden = true;
  elements.detailEmpty.hidden = false;
  history.replaceState(null, "", location.pathname + location.search);
}

async function copyActiveText() {
  if (!state.selected) return;
  const text = state.activeText === "short" ? state.selected.shortText : state.selected.longText;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.append(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }
  showToast(`${state.activeText === "short" ? "Short" : "Long"} text copied`);
}

function showToast(message) {
  elements.toast.querySelector("span").textContent = message;
  elements.toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => elements.toast.classList.remove("is-visible"), 2200);
}

function clearAllFilters() {
  state.query = "";
  state.type = "all";
  state.availability = "all";
  elements.search.value = "";
  elements.typeFilter.value = "all";
  elements.availabilityFilter.value = "all";
  applySearch({ preserveSelection: false });
  elements.search.focus();
}

function setComposerOpen(open) {
  if (open && !elements.coveragePanel.hidden) setCoverageOpen(false, { returnFocus: false });
  elements.composerPanel.hidden = !open;
  elements.composerBackdrop.hidden = !open;
  elements.openComposer.setAttribute("aria-expanded", String(open));
  if (open) {
    setTimeout(() => elements.draftKeywords.focus(), 0);
  } else {
    elements.openComposer.focus();
  }
}

function setCoverageOpen(open, options = {}) {
  if (open && !elements.composerPanel.hidden) setComposerOpen(false);
  elements.coveragePanel.hidden = !open;
  elements.coverageBackdrop.hidden = !open;
  elements.openCoverage.setAttribute("aria-expanded", String(open));
  if (open) {
    renderCoverageDashboard();
    setTimeout(() => elements.closeCoverage.focus(), 0);
  } else if (options.returnFocus !== false) {
    elements.openCoverage.focus();
  }
}

function makeCoverageKpi(value, label) {
  const card = document.createElement("div");
  card.className = "coverage-kpi";
  const number = document.createElement("strong");
  number.textContent = value;
  const description = document.createElement("span");
  description.textContent = label;
  card.append(number, description);
  return card;
}

function renderCoverageDashboard() {
  const dhf = state.technicalSource || {};
  const sharePoint = state.sharePointSource || {};
  const manifest = state.sharePointManifest?.metadata || {};
  const observedDocuments = manifest.observedDocumentCount || sharePoint.observedFileCount || sharePoint.inspectedFileCount || 0;
  const factDocuments = new Set(state.sharePointFacts.filter((fact) => fact._collection !== "sales-portal").map((fact) => fact.sourceId)).size;
  const indexedDocuments = manifest.contentIndexedDocumentCount ?? sharePoint.contentReadDocumentCount ?? 0;
  const factCoverage = observedDocuments ? (indexedDocuments / observedDocuments) * 100 : 0;
  const strategyComplete = manifest.enumerationComplete === true && indexedDocuments === observedDocuments;
  const portal = state.salesPortalSource || {};
  const portalManifest = state.salesPortalManifest?.metadata || {};
  const portalObserved = portalManifest.observedDocumentCount || portal.observedDocumentCount || 0;
  const portalIndexed = portalManifest.contentIndexedDocumentCount || portal.contentIndexedDocumentCount || 0;
  const portalCoverage = portalObserved ? (portalIndexed / portalObserved) * 100 : 0;
  const portalComplete = Boolean(portalManifest.enumerationComplete && portalIndexed === portalObserved);
  const anyCoverageGap = !strategyComplete || !portalComplete;

  elements.coverageAsOf.textContent = `Local snapshots · Strategy ${manifest.snapshotDate || sharePoint.snapshotDate || "unavailable"} · Sales Portal ${portal.snapshotDate || "unavailable"}`;
  elements.coverageSummary.classList.toggle("is-warning", anyCoverageGap);
  elements.coverageSummary.textContent = anyCoverageGap
    ? "The DHF workbook is completely indexed. Each SharePoint source has its own audited register; documents without readable, approved product content remain visible but cannot contribute claims. A complete badge is withheld wherever enumeration or content extraction is not proven."
    : "The workbook and both SharePoint source snapshots are fully indexed for the available source sets.";

  elements.dhfCoverageBadge.textContent = dhf.workbookSheetCount ? "Complete" : "Unavailable";
  elements.dhfCoverageBadge.classList.toggle("is-warning", !dhf.workbookSheetCount);
  elements.dhfCoverageKpis.replaceChildren(
    makeCoverageKpi(`${dhf.workbookSheetCount || 0}/${dhf.workbookSheetCount || 0}`, "Worksheets scanned"),
    makeCoverageKpi(formatNumber.format(dhf.indexedSheetCount || 0), "Substantive sheets indexed"),
    makeCoverageKpi(formatNumber.format(dhf.extractedFactCount || state.technicalFacts.length), "Searchable workbook rows"),
  );
  elements.dhfCoverageNote.textContent = dhf.coveragePolicy || "Workbook coverage information is unavailable.";

  elements.spCoverageBadge.textContent = strategyComplete ? "Complete snapshot" : "Audited, gaps remain";
  elements.spCoverageBadge.classList.toggle("is-warning", !strategyComplete);
  elements.spCoverageKpis.replaceChildren(
    makeCoverageKpi(formatNumber.format(observedDocuments), "Documents observed"),
    makeCoverageKpi(formatNumber.format(indexedDocuments), "Readable documents"),
    makeCoverageKpi(`${factCoverage.toFixed(1)}%`, "Readable-text coverage"),
    makeCoverageKpi(formatNumber.format(manifest.contentExtractionAttemptedDocumentCount || 0), "Extraction attempted"),
    makeCoverageKpi(formatNumber.format(state.sharePointFacts.filter((fact) => fact._collection !== "sales-portal").length), "Selected facts"),
    makeCoverageKpi(formatNumber.format(manifest.extractionFailedDocumentCount || 0), "Extraction failures"),
  );
  elements.spCoverageNote.textContent = manifest.coverageNote || sharePoint.refreshNote || "Coverage information unavailable.";

  elements.portalCoverageBadge.textContent = portalComplete ? "Complete snapshot" : "Audited, gaps remain";
  elements.portalCoverageBadge.classList.toggle("is-warning", !portalComplete);
  elements.portalCoverageKpis.replaceChildren(
    makeCoverageKpi(`${formatNumber.format(state.salesPortalManifest?.documents?.length || 0)}/${formatNumber.format(portalObserved)}`, "Observed files registered"),
    makeCoverageKpi(formatNumber.format(portalIndexed), "Readable documents"),
    makeCoverageKpi(`${portalCoverage.toFixed(1)}%`, "Readable-text coverage"),
    makeCoverageKpi(formatNumber.format(portal.contentExtractionAttemptedDocumentCount || 0), "Extraction attempted"),
    makeCoverageKpi(formatNumber.format(portal.factCount || 0), "Selected facts"),
    makeCoverageKpi(formatNumber.format(portal.extractionFailedDocumentCount || 0), "Extraction failures"),
  );
  elements.portalCoverageNote.textContent = portal.coverageNote || "The Sales Portal source is unavailable.";

  const sheetCoverage = dhf.sheetCoverage || [];
  elements.coverageSheetCount.textContent = `${sheetCoverage.length} worksheets`;
  const sheetFragment = document.createDocumentFragment();
  sheetCoverage.forEach((sheet) => {
    const row = document.createElement("tr");
    const name = document.createElement("td");
    name.textContent = sheet.name;
    const status = document.createElement("td");
    const statusLabel = document.createElement("span");
    statusLabel.className = `coverage-row-status${sheet.status === "Administrative" ? " is-admin" : ""}`;
    statusLabel.textContent = sheet.status;
    status.append(statusLabel);
    const indexed = document.createElement("td");
    indexed.textContent = formatNumber.format(sheet.indexedRows || 0);
    const cells = document.createElement("td");
    cells.textContent = formatNumber.format(sheet.populatedCells || 0);
    row.append(name, status, indexed, cells);
    sheetFragment.append(row);
  });
  elements.coverageSheetList.replaceChildren(sheetFragment);

  const manifestDocuments = state.sharePointManifest?.documents || [];
  const factDocumentsById = new Map([...state.sharePointDocuments.values()]
    .filter((source) => source._collection !== "sales-portal")
    .map((source) => [source.id, source]));
  const registeredDocuments = manifestDocuments.length ? manifestDocuments : [...state.sharePointDocuments.values()];
  elements.coverageDocumentCount.textContent = `${registeredDocuments.length} observed · ${indexedDocuments} readable · ${factDocuments} fact-backed`;
  const documentFragment = document.createDocumentFragment();
  registeredDocuments.forEach((registeredSource) => {
    const verifiedSource = factDocumentsById.get(registeredSource.id);
    const source = verifiedSource || registeredSource;
    const item = source.url ? document.createElement("a") : document.createElement("div");
    item.className = "coverage-document";
    if (source.url) {
      item.href = source.url;
      item.target = "_blank";
      item.rel = "noreferrer";
    }
    const title = document.createElement("strong");
    title.textContent = source.title;
    const meta = document.createElement("span");
    const status = registeredSource.factCount > 0 ? "Readable and fact-backed" : registeredSource.contentStatus === "indexed" ? "Readable — no claim selected" : registeredSource.contentStatus === "failed" ? "Extraction failed — not used for claims" : "Register only — no readable text";
    meta.textContent = [status, registeredSource.exclusionReason, source.updatedAt ? `Updated ${source.updatedAt.slice(0, 10)}` : "", registeredSource.extractionAttemptedAt ? `Checked ${registeredSource.extractionAttemptedAt.slice(0, 10)}` : ""].filter(Boolean).join(" · ");
    item.append(title, meta);
    documentFragment.append(item);
  });
  elements.coverageDocumentList.replaceChildren(documentFragment);

  const portalDocuments = state.salesPortalManifest?.documents || [];
  elements.portalDocumentCount.textContent = `${portalDocuments.length} observed · ${portalIndexed} readable`;
  const portalFragment = document.createDocumentFragment();
  portalDocuments.forEach((source) => {
    const item = source.url ? document.createElement("a") : document.createElement("div");
    item.className = "coverage-document";
    if (source.url) {
      item.href = source.url;
      item.target = "_blank";
      item.rel = "noreferrer";
    }
    const title = document.createElement("strong");
    title.textContent = source.title;
    const meta = document.createElement("span");
    const status = source.contentStatus === "indexed"
      ? source.factCount ? "Content-indexed and fact-backed" : "Content-indexed — no approved claim selected"
      : source.contentStatus === "failed" ? "Extraction failed — not used for claims" : "Registered — no readable text returned";
    meta.textContent = [status, source.exclusionReason, source.updatedAt ? `Updated ${source.updatedAt.slice(0, 10)}` : "", source.extractionAttemptedAt ? `Checked ${source.extractionAttemptedAt.slice(0, 10)}` : ""].filter(Boolean).join(" · ");
    item.append(title, meta);
    portalFragment.append(item);
  });
  elements.portalDocumentList.replaceChildren(portalFragment);
}

function setDraftLoading(loading) {
  elements.generateDraft.disabled = loading;
  elements.generateLabel.hidden = loading;
  elements.generateLoading.hidden = !loading;
}

function formatFileSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function supportingFileExtension(name) {
  return String(name || "").toLowerCase().match(/\.([a-z0-9]+)$/)?.[1] || "";
}

function setDocumentStatus(message, mode = "default") {
  elements.draftDocumentStatus.textContent = message;
  elements.draftDocumentStatus.classList.toggle("is-error", mode === "error");
  elements.draftDocumentStatus.classList.toggle("is-working", mode === "working");
}

function renderSupportingFiles() {
  const fragment = document.createDocumentFragment();
  state.supportingFiles.forEach((file, index) => {
    const row = document.createElement("div");
    row.className = "document-file";
    const details = document.createElement("span");
    const name = document.createElement("strong");
    name.textContent = file.name;
    const meta = document.createElement("small");
    meta.textContent = `${supportingFileExtension(file.name).toUpperCase()} · ${formatFileSize(file.size)}`;
    details.append(name, meta);
    const remove = document.createElement("button");
    remove.type = "button";
    remove.setAttribute("aria-label", `Remove ${file.name}`);
    remove.textContent = "×";
    remove.addEventListener("click", () => {
      state.supportingFiles.splice(index, 1);
      elements.draftDocuments.value = "";
      renderSupportingFiles();
      setDocumentStatus(state.supportingFiles.length
        ? `${state.supportingFiles.length} document${state.supportingFiles.length === 1 ? "" : "s"} ready for local processing.`
        : "Files are processed locally and used only for this sales-text draft.");
    });
    row.append(details, remove);
    fragment.append(row);
  });
  elements.draftDocumentList.replaceChildren(fragment);
}

function handleSupportingFileSelection(event) {
  const incoming = [...(event.target.files || [])];
  const rejected = [];
  incoming.forEach((file) => {
    const extension = supportingFileExtension(file.name);
    if (!SUPPORTED_SUPPORTING_EXTENSIONS.has(extension)) {
      rejected.push(`${file.name}: unsupported file type`);
      return;
    }
    if (file.size > MAX_SUPPORTING_FILE_BYTES) {
      rejected.push(`${file.name}: exceeds 10 MB`);
      return;
    }
    const signature = `${file.name}|${file.size}|${file.lastModified}`;
    if (!state.supportingFiles.some((candidate) => `${candidate.name}|${candidate.size}|${candidate.lastModified}` === signature)) {
      state.supportingFiles.push(file);
    }
  });
  if (state.supportingFiles.length > MAX_SUPPORTING_FILES) {
    rejected.push(`Only the first ${MAX_SUPPORTING_FILES} files were retained`);
    state.supportingFiles = state.supportingFiles.slice(0, MAX_SUPPORTING_FILES);
  }
  while (state.supportingFiles.reduce((total, file) => total + file.size, 0) > MAX_SUPPORTING_TOTAL_BYTES) {
    const removed = state.supportingFiles.pop();
    rejected.push(`${removed.name}: exceeds the 25 MB combined limit`);
  }
  event.target.value = "";
  renderSupportingFiles();
  if (rejected.length) setDocumentStatus(rejected.join(" · "), "error");
  else setDocumentStatus(`${state.supportingFiles.length} document${state.supportingFiles.length === 1 ? "" : "s"} ready for local processing.`);
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => resolve(reader.result));
    reader.addEventListener("error", () => reject(new Error(`${file.name} could not be read.`)));
    reader.readAsDataURL(file);
  });
}

async function extractSupportingDocuments() {
  if (!state.supportingFiles.length) return { documents: [], errors: [] };
  setDocumentStatus(`Reading ${state.supportingFiles.length} local document${state.supportingFiles.length === 1 ? "" : "s"}…`, "working");
  const files = await Promise.all(state.supportingFiles.map(async (file) => ({
    name: file.name,
    mimeType: file.type || "application/octet-stream",
    data: await fileToDataUrl(file),
  })));
  const response = await fetch("/api/extract-documents", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ files }),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok && !payload.documents?.length) throw new Error(payload.error || "The attached documents could not be read locally.");
  const documents = payload.documents || [];
  const errors = payload.errors || [];
  const truncated = documents.filter((documentSource) => documentSource.truncated).length;
  const detail = [
    `${documents.length} document${documents.length === 1 ? "" : "s"} read locally`,
    truncated ? `${truncated} truncated to the 60,000-character screening limit` : "",
    errors.length ? `${errors.length} could not be read` : "",
  ].filter(Boolean).join(" · ");
  setDocumentStatus(detail, errors.length ? "error" : "default");
  return { documents, errors };
}

function cleanGuidanceText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function splitGuidancePhrases(value, limit = 8) {
  return [...new Set(String(value || "")
    .split(/[\r\n,;|]+/)
    .map((part) => cleanGuidanceText(part).replace(/^[-*\u2022]\s*/, ""))
    .filter(Boolean))]
    .slice(0, limit);
}

const FEEDBACK_SOURCE_LABELS = {
  manual: "manually entered approved facts",
  workbook: "DHF workbook",
  strategy: "IGT-S Strategy SharePoint",
  "sales-portal": "IGT Systems Sales Portal",
  attached: "attached documents",
  catalogue: "the current sales-text catalogue",
};

function parseDraftFeedback(value) {
  const text = cleanGuidanceText(value);
  const normalized = normalize(text);
  const selected = new Set();
  const add = (source) => selected.add(source);

  if (/\b(?:sales portal|systems sales portal|igt systems sales portal|second sharepoint)\b/.test(normalized)) add("sales-portal");
  if (/\b(?:strategy sharepoint|strategy execution|transformation sharepoint|first sharepoint)\b/.test(normalized)) add("strategy");
  if (/\bsharepoint\b/.test(normalized) && !selected.has("strategy") && !selected.has("sales-portal")) {
    add("strategy");
    add("sales-portal");
  }
  if (/\b(?:dhf|workbook|technical data)\b/.test(normalized)) add("workbook");
  if (/\b(?:attached|attachment|supporting|uploaded|local) document/.test(normalized)) add("attached");
  if (/\b(?:catalogue|catalog|existing sales text|existing text|3,?727|4,?280)\b/.test(normalized)) add("catalogue");
  if (/\b(?:approved product facts|entered facts|manual facts|manually entered)\b/.test(normalized)) add("manual");

  const exclusiveRequested = /\b(?:only|solely|exclusively|exclusive focus|focus solely|use just|rely solely)\b/.test(normalized);
  const priorityRequested = /\b(?:prioriti[sz]e|priority|prefer|give preference|focus on|emphasi[sz]e)\b/.test(normalized);
  const expanded = /\b(?:more detailed|more descriptive|expand|expanded|longer|add detail|greater detail|in depth|comprehensive)\b/.test(normalized);
  const concise = /\b(?:more concise|shorter|condense|less detail|simplif(?:y|ied))\b/.test(normalized);

  return {
    text,
    exclusive: exclusiveRequested && selected.size ? [...selected] : [],
    priority: priorityRequested && selected.size ? [...selected] : [],
    detail: expanded && !concise ? "expanded" : concise && !expanded ? "concise" : "standard",
  };
}

function feedbackSourceList(sources) {
  return joinNaturally(sources.map((source) => FEEDBACK_SOURCE_LABELS[source]).filter(Boolean));
}

function feedbackEditorialTokens(value) {
  const instructionWords = new Set([
    "add", "draft", "exclusive", "exclusively", "feedback", "focus", "make", "only", "please",
    "prefer", "prioritize", "priority", "source", "sources", "solely", "text", "use", "version",
  ]);
  return [...new Set((normalize(value).match(/[a-z0-9]+/g) || [])
    .filter((token) => token.length > 2 && !GUIDANCE_STOP_WORDS.has(token) && !instructionWords.has(token)))];
}

function orderSentencesForFeedback(sentences, value) {
  const tokens = feedbackEditorialTokens(value);
  if (!tokens.length) return sentences;
  return sentences
    .map((sentence, index) => ({
      sentence,
      index,
      score: tokens.reduce((score, token) => score + (normalize(sentence).includes(token) ? 1 : 0), 0),
    }))
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .map((entry) => entry.sentence);
}

function updateFeedbackUi() {
  const hasDraft = Boolean(state.drafts);
  elements.draftFeedback.disabled = !hasDraft;
  if (!hasDraft) {
    elements.draftFeedbackStatus.textContent = "Create the first draft, then add editorial feedback or tell the engine which sources to prioritize or use exclusively.";
    elements.generateActionText.textContent = "Create local drafts";
    return;
  }
  elements.draftFeedbackStatus.textContent = elements.draftFeedback.value.trim()
    ? "Your feedback will guide the next version. Source instructions change which evidence may contribute; feedback is never treated as a product fact."
    : "Add general feedback, request more or less detail, prioritize a source, or ask the engine to focus solely on selected sources.";
  elements.generateActionText.textContent = elements.draftFeedback.value.trim()
    ? "Update drafts with feedback"
    : "Regenerate local drafts";
}

function guidanceTokens(request) {
  const source = normalize([request.itemName, request.keywords, request.facts, request.audience].join(" "));
  const tokens = source.match(/[a-z0-9]+/g) || [];
  return [...new Set(tokens.filter((token) => (token.length > 1 || /^\d$/.test(token)) && !GUIDANCE_STOP_WORDS.has(token)))];
}

function scoreGuidanceReference(item, request, tokens, phrases) {
  const fields = {
    name: normalize(item.name),
    short: normalize(item.shortText),
    long: normalize(item.longText),
    taxonomy: normalize([item.magName, item.agName, item.businessCategory, item.itemType].join(" ")),
  };
  let score = 0;
  tokens.forEach((token) => {
    if (fields.name.includes(token)) score += 28;
    if (fields.short.includes(token)) score += 19;
    if (fields.long.includes(token)) score += 8;
    if (fields.taxonomy.includes(token)) score += 6;
  });
  phrases.forEach((phrase) => {
    const normalizedPhrase = normalize(phrase);
    const compactPhrase = normalizedPhrase.replace(/[^a-z0-9]/g, "");
    if (normalizedPhrase.length < 3) return;
    if (fields.name.includes(normalizedPhrase)) score += 70;
    if (fields.short.includes(normalizedPhrase)) score += 45;
    if (fields.long.includes(normalizedPhrase)) score += 25;
    if (compactPhrase.length >= 5 && fields.name.replace(/[^a-z0-9]/g, "").includes(compactPhrase)) score += 70;
  });
  if (item.shortText && item.longText) score += 3;
  if (/^details\s+configured offering\s*$/i.test(cleanGuidanceText(item.longText))) score -= 8;
  return score;
}

function findGuidanceReferences(request) {
  const tokens = guidanceTokens(request);
  const phrases = [request.itemName, ...splitGuidancePhrases(request.keywords)].filter(Boolean);
  const seen = new Set();
  return state.items
    .map((item) => ({ item, score: scoreGuidanceReference(item, request, tokens, phrases) }))
    .filter(({ item, score }) => score > 0 && (item.shortText || item.longText))
    .sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name))
    .filter(({ item }) => {
      const signature = normalize(`${item.shortText}|${item.longText}`);
      if (seen.has(signature)) return false;
      seen.add(signature);
      return true;
    })
    .slice(0, 5)
    .map(({ item }) => ({
      id: item.id,
      name: item.name,
      shortText: item.shortText,
      longText: item.longText,
    }));
}

function isSubstantiveCatalogueText(value) {
  const text = cleanGuidanceText(value);
  return text.length >= 40
    && text !== "-"
    && !/^details\s+configured offering\s*$/i.test(text);
}

function findCatalogueProductSources(request) {
  const requestedKey = productNameKey(request.itemName);
  if (requestedKey.length < 5) return [];

  return state.items
    .map((item) => {
      const nameKey = productNameKey(item.name);
      const shortKey = productNameKey(item.shortText);
      const exactMatch = nameKey === requestedKey || shortKey === requestedKey;
      const familyMatch = nameKey.includes(requestedKey) || shortKey.includes(requestedKey);
      const score = exactMatch
        ? 300
        : familyMatch
          ? 220 - Math.min(Math.abs(nameKey.length - requestedKey.length), 60)
          : 0;
      return { item, score, exactMatch };
    })
    .filter(({ item, score }) => score > 0 && isSubstantiveCatalogueText(item.longText))
    .sort((a, b) => b.score - a.score || Number(b.exactMatch) - Number(a.exactMatch) || a.item.name.localeCompare(b.item.name))
    .slice(0, 4)
    .map(({ item, exactMatch }) => ({
      id: item.id,
      name: item.name,
      shortText: item.shortText,
      longText: item.longText,
      exactMatch,
    }));
}

function repairCatalogueSentence(value, name, isFirstSentence) {
  let sentence = normalizeGuidedPhrase(value)
    .replace(/^(?:key benefits?|specifications?|details|additional information)\s*/i, "")
    .replace(/\bwithout the need of\b/gi, "without requiring")
    .replace(/\bfaded in\s*\/\s*out\b/gi, "faded in or out")
    .replace(/\bpre- and post- intervention\b/gi, "pre- and post-intervention")
    .replace(/\bsimplifies the roadmapping procedures\b/gi, "simplifies roadmapping procedures")
    .replace(/overlaying on the live monitor fluoroscopy with a selected reference image/gi, "overlaying fluoroscopy with a selected reference image on the live exam-room monitor")
    .replace(/overlaying a selected reference image with fluoroscopy/gi, "overlaying fluoroscopy with a selected reference image")
    .replace(/overlaying fluoroscopy with a selected acquired image/gi, "overlaying fluoroscopy with a selected acquired image")
    .replace(/technology for Azurion,\s*that aims to advance image quality,\s*to empower clinicians to see with confidence/gi, "technology for Azurion that aims to advance image quality and help clinicians see with confidence")
    .replace(/SmartIQ’s/g, "SmartIQ's")
    .replace(/\s+/g, " ")
    .replace(/[.!?]+$/, "")
    .trim();
  if (!sentence) return "";

  if (/^(?:Simplifies|Supports|Enables|Provides|Allows|Uses|Facilitates)\b/.test(sentence)) {
    sentence = `${isFirstSentence ? name : "It"} ${lowerInitial(sentence)}`;
  }
  return ensureSentence(sentence);
}

function catalogueSentenceCategory(value, name) {
  const text = normalize(value);
  const hasProductName = productNameKey(value).includes(productNameKey(name));
  if (/pre- and post|assess|result|comparison/.test(text)) return 3;
  if (/seamless|workflow|adoption|daily operations/.test(text)) return 1;
  if (hasProductName && /simplif|provide|function|designed|overlay|technology|imaging/.test(text)) return 0;
  if (/support|enable|manage|workflow|integrat|adoption|navigation|dose|contrast/.test(text)) return 1;
  if (/reference image|tableside|fade|select|acquired image|algorithm|image processing|content-aware|hardware|background noise/.test(text)) return 2;
  return 4;
}

function buildCatalogueProductSentences(name, sources) {
  const candidates = [];
  const seen = new Set();
  sources.forEach((source, sourceIndex) => {
    String(source.longText || "")
      .split(/\bAdditional Information\b/i)[0]
      .replace(/\b(?:Introduction|Key Benefits?|Includes|Details)\b/gi, ". ")
      .replace(/\b(?:See with confidence|Designed to reduce X-ray and contrast dose|Unlock the full potential of [^:]+):/gi, ". ")
      .replace(/'{2,}|\t+/g, ". ")
      .replace(/\[\d+\]/g, "")
      .replace(/[\r\n]+/g, ". ")
      .replace(/[\u2022\u00b7]+/g, ". ")
      .replace(/\.(?=[A-Z])/g, ". ")
      .split(/(?<=[.!?])\s+|\s*;\s*/)
      .map((part) => cleanGuidanceText(part).replace(/^[-*]+\s*/, ""))
      .filter((part) => part.length >= 24 && part.length <= 280)
      .filter((part) => !/^(?:key benefits?|specifications?|details|additional information)\.?$/i.test(part))
      .filter((part) => !/^(?:compatible with|allura\b)/i.test(part))
      .filter((part) => !/\b(?:you|your|we|our)\b/i.test(part))
      .filter((part) => !/\b(?:exceptional|exactly|clinically proven|trial|investigational|clinicaltrials\.gov|IFU)\b/i.test(part))
      .filter((part) => !/\b(?:e-?learning|education|enrol(?:lment|ment)|subscriber|e-?mail address|handover|new users?|seats?|licen[cs]e|expires?|valid for \d+ year|course registration|installation date|purchase date|this purchase)\b/i.test(part))
      .filter((part) => !guidanceExclusionReason(part))
      .forEach((part, sentenceIndex) => {
        const signature = normalize(part)
          .replace(/\b(?:the|a|an|it|smartmask)\b/g, "")
          .replace(/[^a-z0-9]+/g, " ")
          .trim();
        if (!signature || seen.has(signature)) return;
        seen.add(signature);
        candidates.push({
          text: part,
          sourceIndex,
          sentenceIndex,
          category: catalogueSentenceCategory(part, name),
        });
      });
  });

  const ordered = candidates
    .sort((a, b) => a.category - b.category || a.sourceIndex - b.sourceIndex || a.sentenceIndex - b.sentenceIndex);
  const selected = [];
  const selectedConcepts = new Set();
  const categoryCounts = new Map();
  const categoryLimits = new Map([[0, 1], [1, 4], [2, 3], [3, 1], [4, 1]]);
  ordered.forEach((candidate) => {
    if (selected.length >= 10) return;
    const categoryCount = categoryCounts.get(candidate.category) || 0;
    if (categoryCount >= (categoryLimits.get(candidate.category) || 1)) return;
    const concepts = deriveFactConcepts([candidate.text]);
    const isRedundant = concepts.length
      && concepts.every((concept) => selectedConcepts.has(concept))
      && candidate.category !== 2
      && candidate.category !== 3;
    if (isRedundant) return;
    concepts.forEach((concept) => selectedConcepts.add(concept));
    selected.push(candidate.text);
    categoryCounts.set(candidate.category, categoryCount + 1);
  });

  return selected
    .map((sentence, index) => repairCatalogueSentence(sentence, name, index === 0))
    .filter(Boolean);
}

function technicalSearchValue(value) {
  const spaced = normalize(value).replace(/[^a-z0-9]+/g, " ").trim();
  return `${spaced} ${spaced.replace(/\s+/g, "")}`.trim();
}

function normalizedPhraseVariants(value) {
  const phrase = normalize(value).replace(/[^a-z0-9]+/g, " ").trim();
  if (!phrase) return [];
  const singular = phrase.replace(/\b([a-z]{4,})s\b/g, "$1");
  return [...new Set([phrase, singular, phrase.replace(/\s+/g, ""), singular.replace(/\s+/g, "")].filter(Boolean))];
}

function updateApprovedFactStatus() {
  const sources = [];
  if (state.technicalSource && state.technicalFacts.length) {
    sources.push(`${formatNumber.format(state.technicalFacts.length)} workbook rows from ${formatNumber.format(state.technicalSource.indexedSheetCount || 1)} sheets`);
  }
  if (state.sharePointSource && state.sharePointFacts.length) {
    const strategyFacts = state.sharePointFacts.filter((fact) => fact._collection !== "sales-portal");
    if (strategyFacts.length) sources.push(`${formatNumber.format(strategyFacts.length)} SharePoint facts from ${formatNumber.format(state.sharePointSource.documentCount || 0)} documents`);
  }
  if (state.salesPortalSource && state.salesPortalFacts.length) {
    sources.push(`${formatNumber.format(state.salesPortalFacts.length)} Sales Portal facts from ${formatNumber.format(state.salesPortalSource.factBackedDocumentCount || 0)} documents`);
  }
  elements.sourceFactStatus.textContent = sources.length
    ? `${sources.join(" · ")} · automatic matching with exact source trace`
    : "Approved product-fact sources are unavailable; only facts entered above will be used.";
}

function prepareTechnicalSource(payload) {
  state.technicalSource = payload?.metadata || null;
  state.technicalFacts = [...(payload?.facts || []), ...(payload?.supplementalFacts || [])].map((fact) => ({
    ...fact,
    _fields: {
      item: technicalSearchValue(fact.item),
      subitem: technicalSearchValue(fact.subitem),
      parameter: technicalSearchValue(fact.parameter),
      value: technicalSearchValue(fact.value),
      applicability: technicalSearchValue((fact.applicability || []).join(" ")),
    },
  }));

  if (!state.technicalSource || !state.technicalFacts.length) {
    updateApprovedFactStatus();
    return;
  }
  updateApprovedFactStatus();
}

function prepareSharePointManifest(payload) {
  state.sharePointManifest = payload || null;
}

function prepareSharePointSource(payload) {
  state.sharePointSource = payload?.metadata || null;
  state.sharePointDocuments = new Map((payload?.documents || []).map((documentSource) => [documentSource.id, { ...documentSource, _collection: "strategy" }]));
  state.sharePointFacts = (payload?.facts || []).map((fact, index) => ({
    ...fact,
    index,
    _collection: "strategy",
    _fields: {
      product: technicalSearchValue([fact.product, ...(fact.aliases || [])].join(" ")),
      topic: technicalSearchValue(fact.topic),
      text: technicalSearchValue(fact.text),
    },
  }));
  updateApprovedFactStatus();
}

function prepareSalesPortalSource(payload) {
  state.salesPortalManifest = payload || null;
  state.salesPortalSource = payload?.metadata || null;
  state.salesPortalDocuments = new Map((payload?.documents || []).map((documentSource) => [documentSource.id, { ...documentSource, _collection: "sales-portal" }]));
  state.salesPortalDocuments.forEach((documentSource, id) => state.sharePointDocuments.set(id, documentSource));
  state.salesPortalFacts = (payload?.facts || []).map((fact, index) => ({
    ...fact,
    index: state.sharePointFacts.length + index,
    _collection: "sales-portal",
    _fields: {
      product: technicalSearchValue([fact.product, ...(fact.aliases || [])].join(" ")),
      topic: technicalSearchValue(fact.topic),
      text: technicalSearchValue(fact.text),
    },
  }));
  state.sharePointFacts.push(...state.salesPortalFacts);
  updateApprovedFactStatus();
}

function findSharePointFacts(request) {
  if (!state.sharePointFacts.length) return [];
  const requestText = technicalSearchValue([request.itemName, request.keywords].join(" "));
  const compactRequest = requestText.replace(/\s+/g, "");
  const requestedProductVariants = normalizedPhraseVariants(request.itemName);
  const tokens = technicalFactTokens(request);
  const seen = new Set();

  return state.sharePointFacts
    .map((fact) => {
      const productVariants = [fact.product, ...(fact.aliases || [])]
        .flatMap(normalizedPhraseVariants);
      const directProductMatch = requestedProductVariants.some((requestedVariant) => (
        productVariants.includes(requestedVariant)
      ));
      const specificProductMatch = requestedProductVariants.some((requestedVariant) => (
        productVariants.some((productVariant) => productVariant.startsWith(`${requestedVariant} `))
      ));
      const exactProductMatch = productVariants.some((variant) => {
        const compactVariant = variant.replace(/\s+/g, "");
        return requestText.includes(variant) || (compactVariant.length >= 5 && compactRequest.includes(compactVariant));
      });
      let score = directProductMatch ? 260 : specificProductMatch ? 240 : exactProductMatch ? 180 : 0;
      let distinctiveMatches = 0;
      tokens.forEach((token) => {
        if (fact._fields.product.includes(token)) {
          score += 34;
          distinctiveMatches += 1;
        } else if (fact._fields.topic.includes(token)) {
          score += 18;
          distinctiveMatches += 1;
        } else if (fact._fields.text.includes(token)) {
          score += 5;
          distinctiveMatches += 1;
        }
      });
      return { fact, score, directProductMatch, specificProductMatch, exactProductMatch, distinctiveMatches };
    })
    .filter(({ score, exactProductMatch, distinctiveMatches }) => exactProductMatch || (score >= 45 && distinctiveMatches >= 2))
    .sort((a, b) => (
      Number(b.directProductMatch) - Number(a.directProductMatch)
      || (a.directProductMatch && b.directProductMatch ? a.fact.index - b.fact.index : 0)
      || Number(b.specificProductMatch) - Number(a.specificProductMatch)
      || (a.specificProductMatch && b.specificProductMatch ? a.fact.index - b.fact.index : 0)
      || Number(b.exactProductMatch) - Number(a.exactProductMatch)
      || (a.exactProductMatch && b.exactProductMatch ? a.fact.index - b.fact.index : b.score - a.score)
      || a.fact.index - b.fact.index
    ))
    .filter(({ fact }) => {
      const signature = normalize(`${fact.product}|${fact.topic}|${fact.text}`);
      if (seen.has(signature)) return false;
      seen.add(signature);
      return true;
    })
    .slice(0, 6)
    .map(({ fact, score, directProductMatch, specificProductMatch, exactProductMatch }) => ({
      ...fact,
      score,
      directProductMatch,
      specificProductMatch,
      exactProductMatch,
      source: state.sharePointDocuments.get(fact.sourceId) || null,
    }));
}

function findSharePointDocumentReferences(request) {
  const documents = [
    ...(state.sharePointManifest?.documents || []).map((documentSource) => ({ ...documentSource, _collection: "strategy" })),
    ...(state.salesPortalManifest?.documents || []).map((documentSource) => ({ ...documentSource, _collection: "sales-portal" })),
  ];
  if (!documents.length) return [];
  const requestName = normalize(request.itemName).replace(/[^a-z0-9]+/g, " ").trim();
  const compactName = requestName.replace(/\s+/g, "");
  const tokens = technicalFactTokens(request).filter((token) => token.length >= 3);
  const indexedIds = new Set([...state.sharePointDocuments.values()]
    .filter((source) => source.contentStatus === "indexed" || !source.contentStatus)
    .map((source) => source.id));
  const indexedTitles = new Set([...state.sharePointDocuments.values()]
    .filter((source) => source.contentStatus === "indexed" || !source.contentStatus)
    .map((source) => normalize(source.title)));

  return documents
    .map((documentSource) => {
      const title = normalize(documentSource.title).replace(/[^a-z0-9]+/g, " ").trim();
      const compactTitle = title.replace(/\s+/g, "");
      const exactNameMatch = compactName.length >= 5 && compactTitle.includes(compactName);
      const matchedTokens = tokens.filter((token) => title.includes(token));
      const score = (exactNameMatch ? 200 : 0) + matchedTokens.length * 24;
      return {
        ...documentSource,
        contentIndexed: documentSource.contentStatus
          ? documentSource.contentStatus === "indexed"
          : indexedIds.has(documentSource.id) || indexedTitles.has(normalize(documentSource.title)),
        score,
        exactNameMatch,
        matchedTokens,
      };
    })
    .filter(({ score, exactNameMatch, matchedTokens }) => exactNameMatch || (score >= 48 && matchedTokens.length >= 2))
    .sort((a, b) => b.score - a.score || Number(b.contentIndexed) - Number(a.contentIndexed) || a.title.localeCompare(b.title))
    .slice(0, 40);
}

function technicalFactTokens(request) {
  const source = technicalSearchValue([request.itemName, request.keywords, request.facts].join(" "));
  const tokens = source.match(/[a-z0-9]+/g) || [];
  return [...new Set(tokens.filter((token) => token.length > 1 && !TECHNICAL_STOP_WORDS.has(token)))];
}

function scoreTechnicalFact(fact, tokens, phrases) {
  const weights = { item: 14, subitem: 24, parameter: 34, value: 6, applicability: 22 };
  let score = 0;
  let matchedTokens = 0;
  tokens.forEach((token) => {
    let tokenMatched = false;
    Object.entries(weights).forEach(([field, weight]) => {
      if (fact._fields[field].includes(token)) {
        score += weight;
        tokenMatched = true;
      }
    });
    if (tokenMatched) matchedTokens += 1;
  });

  phrases.forEach((phrase) => {
    const variants = normalizedPhraseVariants(phrase).filter((variant) => variant.length >= 4);
    if (!variants.length) return;
    if (variants.some((variant) => fact._fields.parameter.includes(variant))) score += 130;
    if (variants.some((variant) => fact._fields.subitem.includes(variant))) score += 95;
    if (variants.some((variant) => fact._fields.item.includes(variant))) score += 70;
    if (variants.some((variant) => fact._fields.value.includes(variant))) score += 24;
  });

  if (!matchedTokens) return -1;
  score += Math.round((matchedTokens / Math.max(tokens.length, 1)) * 20);
  return score;
}

function technicalFactMatchesProduct(fact, productName) {
  const productText = technicalSearchValue(productName);
  const compactProduct = productText.replace(/\s+/g, "");
  if (compactProduct.length < 5) return false;

  const identityText = [fact._fields.item, fact._fields.subitem, fact._fields.parameter].join(" ");
  const compactIdentity = identityText.replace(/\s+/g, "");
  if (compactIdentity.includes(compactProduct)) return true;

  const productTokens = productText
    .split(" ")
    .filter((token) => token.length > 2 && !TECHNICAL_STOP_WORDS.has(token));
  return productTokens.length >= 2 && productTokens.every((token) => identityText.includes(token));
}

function findTechnicalFacts(request) {
  if (!state.technicalFacts.length) return [];
  const tokens = technicalFactTokens(request);
  if (!tokens.length) return [];
  const phrases = [request.itemName, ...splitGuidancePhrases(request.keywords, 8)].filter(Boolean);
  const knownApplicability = [...new Set(state.technicalFacts.flatMap((fact) => fact.applicability || []))];
  const requestedApplicability = knownApplicability.filter((variant) => {
    const compactVariant = technicalSearchValue(variant).split(" ").at(-1);
    return tokens.includes(compactVariant);
  });
  const seen = new Set();
  return state.technicalFacts
    .filter((fact) => !cleanGuidanceText(request.itemName) || technicalFactMatchesProduct(fact, request.itemName))
    .filter((fact) => !requestedApplicability.length
      || !fact.applicability?.length
      || fact.applicability.some((variant) => requestedApplicability.includes(variant)))
    .map((fact) => ({ fact, score: scoreTechnicalFact(fact, tokens, phrases) }))
    .filter(({ score }) => score >= 18)
    .sort((a, b) => b.score - a.score || a.fact.row - b.fact.row)
    .filter(({ fact }) => {
      const signature = normalize(`${fact.sheet}|${fact.subitem}|${fact.parameter}|${fact.value}|${(fact.applicability || []).join(",")}`);
      if (seen.has(signature)) return false;
      seen.add(signature);
      return true;
    })
    .slice(0, 6)
    .map(({ fact, score }) => ({ ...fact, score, requestedApplicability }));
}

function technicalFactSentence(name, fact) {
  const parameter = lowerInitial(phraseWithoutTerminalPunctuation(normalizeGuidedPhrase(fact.parameter)));
  const subitem = lowerInitial(phraseWithoutTerminalPunctuation(normalizeGuidedPhrase(fact.subitem)));
  const value = lowerInitial(phraseWithoutTerminalPunctuation(normalizeGuidedPhrase(fact.value)));
  const applicableVariants = fact.requestedApplicability?.length ? fact.requestedApplicability : fact.applicability;
  const scope = applicableVariants?.length ? `For ${joinNaturally(applicableVariants)}, ` : "";
  if (/^present$/i.test(value)) return ensureSentence(`${scope}${name} includes ${parameter}`);
  if (/^not present$/i.test(value)) return ensureSentence(`${scope}${name} does not include ${parameter}`);
  return ensureSentence(`${scope}${name} specifications list ${parameter}${subitem ? ` for ${subitem}` : ""} as ${value}`);
}

function joinNaturally(values) {
  if (values.length < 2) return values[0] || "";
  if (values.length === 2) return `${values[0]} and ${values[1]}`;
  return `${values.slice(0, -1).join(", ")}, and ${values.at(-1)}`;
}

function ensureSentence(value) {
  const text = cleanGuidanceText(value);
  if (!text) return "";
  return /[.!?]$/.test(text) ? text : `${text}.`;
}

function replaceGuidanceWord(value, source, replacement) {
  return value.replace(new RegExp(`\\b${source}\\b`, "gi"), (match) => {
    if (match === match.toUpperCase()) return replacement.toUpperCase();
    if (match[0] === match[0].toUpperCase()) return `${replacement[0].toUpperCase()}${replacement.slice(1)}`;
    return replacement;
  });
}

const PHILIPS_ACRONYM_REPLACEMENTS = [
  ["TSM", "touch screen module"],
  ["ER/CR", "examination room and control room"],
];

function expandPhilipsAcronyms(value) {
  return PHILIPS_ACRONYM_REPLACEMENTS.reduce(
    (text, [acronym, expansion]) => text.replace(new RegExp(`\\b${acronym.replace("/", "\\/")}\\b`, "g"), expansion),
    String(value || ""),
  );
}

function formatConvertedNumber(value) {
  return Number(value.toFixed(1)).toString();
}

function convertedMeasurement(value, unit) {
  const amount = Number(value);
  const normalizedUnit = unit.toLowerCase();
  const conversions = {
    mm: [amount / 25.4, "inch"],
    cm: [amount / 2.54, "inch"],
    m: [amount * 3.28084, "ft"],
    kg: [amount * 2.20462, "lb"],
    g: [amount / 28.3495, "oz"],
    inch: [amount * 2.54, "cm"],
    inches: [amount * 2.54, "cm"],
    lb: [amount / 2.20462, "kg"],
    lbs: [amount / 2.20462, "kg"],
    oz: [amount * 28.3495, "g"],
    ft: [amount / 3.28084, "m"],
  };
  const conversion = conversions[normalizedUnit];
  return conversion ? `${formatConvertedNumber(conversion[0])} ${conversion[1]}` : "";
}

function formatDualMeasurements(value) {
  let text = value.replace(
    /\b(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*(mm|cm|m)\b(?!\s*\()/gi,
    (match, first, second, unit, offset, source) => {
      const after = source.slice(offset + match.length, offset + match.length + 55);
      if (/^\s*\([^)]*\b(?:inch|inches|ft)\b/i.test(after)) return match;
      const firstConversion = convertedMeasurement(Number(first), unit).split(" ");
      const secondConversion = convertedMeasurement(Number(second), unit).split(" ");
      return `${first} x ${second} ${unit} (${firstConversion[0]} x ${secondConversion[0]} ${secondConversion[1]})`;
    },
  );

  return text.replace(
    /\b(\d+(?:\.\d+)?)\s*(mm|cm|m|kg|g|inch|inches|lb|lbs|oz|ft)\b/gi,
    (match, amount, unit, offset, source) => {
      const before = source.slice(Math.max(0, offset - 45), offset);
      const after = source.slice(offset + match.length, offset + match.length + 55);
      const isInsidePair = /\([^)]*$/.test(before) && /^[^)]*\)/.test(after);
      const hasPairAfter = /^\s*\([^)]*\b(?:mm|cm|m|kg|g|inch|inches|lb|lbs|oz|ft)\b[^)]*\)/i.test(after);
      if (isInsidePair || hasPairAfter) return `${amount} ${unit}`;
      const conversion = convertedMeasurement(Number(amount), unit);
      return conversion ? `${amount} ${unit} (${conversion})` : `${amount} ${unit}`;
    },
  );
}

function normalizeGuideDate(monthOrDay, dayOrMonth, year) {
  const first = Number(monthOrDay);
  const second = Number(dayOrMonth);
  if (first <= 12 && second <= 31) return `${year}-${String(first).padStart(2, "0")}-${String(second).padStart(2, "0")}`;
  if (first <= 31 && second <= 12) return `${year}-${String(second).padStart(2, "0")}-${String(first).padStart(2, "0")}`;
  return `${monthOrDay}-${dayOrMonth}-${year}`;
}

function normalizePhilipsLanguage(value) {
  let text = cleanGuidanceText(value)
    .replace(/(\d+(?:\.\d+)?)\s*["”]/g, "$1 inch")
    .replace(/\s*&\s*/g, " and ")
    .replace(/\s+\+\s+/g, " and ")
    .replace(/\s*@\s*/g, " at ")
    .replace(/\s*[·•]\s*/g, "; ")
    .replace(/,\s*;/g, ";")
    .replace(/#\s*/g, "number ")
    .replace(/\band\s*\/\s*or\b/gi, "or")
    .replace(/\s*\/\s*/g, " or ")
    .replace(/[“”"]/g, "")
    .replace(/\s+([,.;:])/g, "$1")
    .replace(/([,;:])(?=\S)/g, "$1 ")
    .replace(/\.(?=[A-Za-z])/g, ". ")
    .replace(/\s+/g, " ")
    .trim();

  const americanEnglish = [
    ["analogue", "analog"],
    ["catalogue", "catalog"],
    ["centimetre", "centimeter"],
    ["colour", "color"],
    ["localisation", "localization"],
    ["localised", "localized"],
    ["metre", "meter"],
    ["utilise", "use"],
    ["utilize", "use"],
    ["freeware", "free software"],
  ];
  americanEnglish.forEach(([source, replacement]) => {
    text = replaceGuidanceWord(text, source, replacement);
  });
  text = text.replace(/\b(\d{1,2})-(\d{1,2})-(\d{4})\b/g, (_, first, second, year) => normalizeGuideDate(first, second, year));
  text = text.replace(/\b\d{5,}\b/g, (number) => Number(number).toLocaleString("en-US"));
  return formatDualMeasurements(text).replace(/\s+/g, " ").trim();
}

function normalizeGuidedPhrase(value) {
  return normalizePhilipsLanguage(expandPhilipsAcronyms(value));
}

function phraseWithoutTerminalPunctuation(value) {
  return normalizePhilipsLanguage(value).replace(/[.!?;:]+$/, "");
}

function lowerInitial(value) {
  if (!value || /^[A-Z0-9]{2,}\b/.test(value)) return value;
  return `${value[0].toLowerCase()}${value.slice(1)}`;
}

function limitShortText(value, maxLength = 30) {
  const text = cleanGuidanceText(value);
  if (text.length <= maxLength) return text;
  const candidate = text.slice(0, maxLength + 1);
  const lastSpace = candidate.lastIndexOf(" ");
  return (lastSpace > 20 ? candidate.slice(0, lastSpace) : text.slice(0, maxLength)).replace(/[\s,;:\-]+$/, "");
}

function salesTextWordCount(value) {
  return cleanGuidanceText(value).match(/\b[\p{L}\p{N}]+(?:[-'][\p{L}\p{N}]+)*\b/gu)?.length || 0;
}

function trimSalesTextToWords(value, maxWords = 20) {
  const words = cleanGuidanceText(value).replace(/[.!?]+$/, "").split(/\s+/).filter(Boolean);
  if (words.length <= maxWords) return ensureSentence(words.join(" "));
  const trimmed = words.slice(0, maxWords);
  while (trimmed.length && /^(?:a|an|and|by|for|from|in|of|on|or|the|to|with)$/i.test(trimmed.at(-1))) trimmed.pop();
  return ensureSentence(trimmed.join(" ").replace(/[,;:]+$/, ""));
}

function salesSentencesOverlap(left, right) {
  const contentTokens = (value) => (normalize(value).match(/[a-z0-9]+/g) || [])
    .filter((token) => token.length > 2 && !GUIDANCE_STOP_WORDS.has(token));
  const leftSequence = contentTokens(left);
  const rightSequence = contentTokens(right);
  const leftTokens = new Set(leftSequence);
  const rightTokens = new Set(rightSequence);
  if (!leftTokens.size || !rightTokens.size) return false;
  const shared = [...leftTokens].filter((token) => rightTokens.has(token)).length;
  const smallerCoverage = shared / Math.min(leftTokens.size, rightTokens.size);
  const unionCoverage = shared / new Set([...leftTokens, ...rightTokens]).size;
  return smallerCoverage >= 0.72 || unionCoverage >= 0.58;
}

function buildShortSalesText(name, audience, featureSentences, evidenceFacts) {
  const concepts = deriveFactConcepts(evidenceFacts.length ? evidenceFacts : featureSentences);
  const audienceRole = normalizeAudienceRole(audience) || "clinical teams";
  if (concepts.length) {
    const conceptSummary = ensureSentence(
      `${name} provides ${joinNaturally(concepts)} to support ${audienceRole} during clinical imaging workflows`,
    );
    if (salesTextWordCount(conceptSummary) >= 15) return trimSalesTextToWords(conceptSummary, 20);
  }

  const sentenceCores = featureSentences
    .map((sentence) => phraseWithoutTerminalPunctuation(sentence))
    .filter(Boolean);
  if (!sentenceCores.length) return ensureSentence(name);
  let summary = sentenceCores[0];
  for (let index = 1; salesTextWordCount(summary) < 15 && index < sentenceCores.length; index += 1) {
    const addition = sentenceCores[index]
      .replace(new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s+`, "i"), "")
      .replace(/^It\s+/i, "")
      .replace(/^The capability (?:also )?/i, "")
      .replace(/^allows?\s+/i, "allows ");
    summary = `${summary} and ${lowerInitial(addition)}`;
  }
  return trimSalesTextToWords(summary, 20);
}

const CLAIM_OR_COMPARISON_PATTERN = /\b(best|better|superior|market[- ]leading|industry[- ]leading|unique|unmatched|guarantee(?:d)?|safest|fastest|highest|lowest|outperform(?:s|ed)?|competitor(?:s)?)\b/i;
const DISCLOSURE_PATTERN = /\b(payment terms?|warranty|installation (?:terms?|conditions?|duration)|training (?:terms?|conditions?|duration))\b/i;
const INTERNAL_REFERENCE_PATTERN = /\b(internal (?:configuration|order)|order instructions?|product number|part number|material number|reference number)\b/i;
const PERSONAL_PRONOUN_PATTERN = /\b(he|she|him|her|his|hers)\b/i;
const OPTIONAL_PATTERN = /\b(option|optional|optionally|available separately|not included)\b/i;
const COMMON_ACRONYMS = new Set(["AI", "CT", "ECG", "EMR", "ICU", "IT", "LAN", "LCD", "LED", "MRI", "NIBP", "TFT", "UPS", "USB", "WLAN"]);

function guidanceExclusionReason(value) {
  if (CLAIM_OR_COMPARISON_PATTERN.test(value)) return "claim or comparison";
  if (OPTIONAL_PATTERN.test(value)) return "unverified optional feature";
  if (DISCLOSURE_PATTERN.test(value)) return "payment, warranty, installation, or training disclosure";
  if (INTERNAL_REFERENCE_PATTERN.test(value)) return "internal configuration or product reference";
  if (PERSONAL_PRONOUN_PATTERN.test(value)) return "personal pronoun";
  return "";
}

function findUnexplainedAcronyms(value) {
  const matches = normalizePhilipsLanguage(value).match(/\b[A-Z]{2,}[A-Z0-9]*(?:-[A-Z0-9]+)*\b/g) || [];
  return [...new Set(matches.filter((match) => !COMMON_ACRONYMS.has(match) && !/^\d/.test(match)))];
}

function capitalizeInitial(value) {
  return value ? `${value[0].toUpperCase()}${value.slice(1)}` : "";
}

function normalizeAudienceRole(value) {
  let audience = normalizePhilipsLanguage(value)
    .replace(/\b(cardiologist|clinician|physician|radiologist|technologist|nurse|operator|specialist|decision-maker)s?\b/gi, (role) => role.toLowerCase());
  audience = audience.replace(/\b(cardiologist|clinician|physician|radiologist|technologist|nurse|operator|specialist|decision-maker)\b$/i, "$1s");
  return lowerInitial(audience);
}

const FACT_ACTION_PATTERN = /^(access|adjust|annotate|capture|connect|control|display|draw|highlight|manage|mark|measure|monitor|navigate|place|record|review|select|support|use|view|visualize|work|zoom)\b/i;

function professionalizeFactClause(value) {
  let clause = lowerInitial(phraseWithoutTerminalPunctuation(normalizeGuidedPhrase(value)))
    .replace(/\btouch screen module screen\b/gi, "touchscreen")
    .replace(/^the ability to\s+/i, "")
    .replace(/^(?:allows?|enables?) (?:the )?(?:user|customer|clinician)s? to\s+/i, "")
    .replace(/^visuali[sz]ation of (?:the )?/i, "view ")
    .replace(/^viewing of (?:the )?/i, "view ")
    .replace(/^display of (?:the )?/i, "display ")
    .replace(/^drawing of\s+/i, "draw ")
    .replace(/^adjustment of\s+/i, "adjust ")
    .replace(/^highlighting of\s+/i, "highlight ")
    .replace(/\bthe acquired images\b/gi, "acquired images")
    .replace(/\bthe clinical images\b/gi, "clinical images")
    .replace(/draw markers on (?:the )?images directly on (?:the )?touchscreen/gi, "place markers directly on the touchscreen")
    .replace(/adjust (?:the )?collimator\b/gi, "adjust collimation")
    .replace(/\bby drag and drop\b/gi, "using drag-and-drop interaction")
    .replace(/zoom and pan clinical images by finger pinching/gi, "zoom and pan clinical images using pinch gestures")
    .replace(/\bon (?:the )?touchscreen screen\b/gi, "on the touchscreen")
    .replace(/\s+/g, " ")
    .trim();

  if (!clause) return "";
  if (!FACT_ACTION_PATTERN.test(clause)) clause = `access ${clause}`;
  return clause;
}

function deriveFactConcepts(facts) {
  const source = normalize(facts.join(" "));
  const concepts = [];
  const add = (concept) => {
    if (!concepts.includes(concept)) concepts.push(concept);
  };
  if (/visuali[sz]|view|display|acquired image/.test(source)) add("image viewing");
  if (/draw|marker|annotat|highlight|pointer/.test(source)) add("annotation");
  if (/collimat/.test(source)) add("collimation control");
  if (/navigation|image guidance/.test(source)) add("image guidance");
  if (/dose/.test(source)) add("dose management");
  if (/connect|integrat/.test(source)) add("connectivity");
  if (/\bmonitoring\b|\bmeasurements?\b/.test(source)) add("monitoring");
  if (/workflow/.test(source)) add("workflow support");
  return concepts.slice(0, 4);
}

function buildProfessionalFactSentences(name, audience, facts) {
  if (!facts.length) return [];
  const clauses = facts
    .map(professionalizeFactClause)
    .filter(Boolean)
    .filter((clause, index, allClauses) => allClauses.findIndex((candidate) => normalize(candidate) === normalize(clause)) === index);
  const concepts = deriveFactConcepts(facts);
  const sentences = [];
  if (concepts.length) {
    const interfacePhrase = /touchscreen|screen|TSM/i.test(facts.join(" "))
      ? " in one touchscreen interface"
      : " in one product capability";
    sentences.push(ensureSentence(`${name} combines ${joinNaturally(concepts)}${interfacePhrase}`));
  }
  if (clauses.length) {
    const actor = capitalizeInitial(normalizeAudienceRole(audience) || "users");
    const actorLower = lowerInitial(actor);
    clauses.forEach((clause, index) => {
      if (index === 0) sentences.push(ensureSentence(`${actor} can ${clause}`));
      else if (index === 1) sentences.push(ensureSentence(`${name} also allows ${actorLower} to ${clause}`));
      else if (index === 2) sentences.push(ensureSentence(`Further supported functionality allows ${actorLower} to ${clause}`));
      else sentences.push(ensureSentence(`The product capability also allows ${actorLower} to ${clause}`));
    });
  }
  return sentences;
}

function productNameKey(value) {
  return normalize(value).replace(/[^a-z0-9]/g, "");
}

function resolveProductName(value) {
  const requested = normalizePhilipsLanguage(value);
  const key = productNameKey(requested);
  if (!key) return { name: "", matched: false, changed: false, source: null };

  const catalogueMatch = state.items.find((item) => (
    productNameKey(item.name) === key || productNameKey(item.shortText) === key
  ));
  if (catalogueMatch) {
    const officialName = cleanGuidanceText(catalogueMatch.name || catalogueMatch.shortText);
    return {
      name: officialName,
      matched: true,
      changed: officialName !== requested,
      source: `catalogue item ${catalogueMatch.id}`,
    };
  }

  const catalogueFamilyMatches = state.items.filter((item) => (
    key.length >= 5
    && (productNameKey(item.name).includes(key) || productNameKey(item.shortText).includes(key))
    && isSubstantiveCatalogueText(item.longText)
  ));
  if (catalogueFamilyMatches.length) {
    return {
      name: requested,
      matched: true,
      changed: false,
      source: `${catalogueFamilyMatches.length} product-specific catalogue records`,
    };
  }

  const sharePointMatch = state.sharePointFacts.find((fact) => (
    [fact.product, ...(fact.aliases || [])].some((candidate) => productNameKey(candidate) === key)
  ));
  if (sharePointMatch) {
    const officialName = cleanGuidanceText(sharePointMatch.product);
    return {
      name: officialName,
      matched: true,
      changed: officialName !== requested,
      source: "approved SharePoint product documentation",
    };
  }

  const technicalMatch = state.technicalFacts.find((fact) => productNameKey(fact.subitem) === key);
  if (technicalMatch) {
    const sourceName = cleanGuidanceText(technicalMatch.subitem);
    return { name: sourceName, matched: true, changed: sourceName !== requested, source: "approved technical-data source" };
  }
  return { name: requested, matched: false, changed: false, source: null };
}

function draftComplianceWarnings(text) {
  const warnings = [];
  const acronyms = findUnexplainedAcronyms(text);
  if (acronyms.length) warnings.push(`Define or remove uncommon acronyms before approval: ${acronyms.join(", ")}.`);
  if (CLAIM_OR_COMPARISON_PATTERN.test(text)) warnings.push("Remove comparative or unapproved claim language before approval.");
  if (OPTIONAL_PATTERN.test(text)) warnings.push("Remove optional-feature wording unless the feature is confirmed as included.");
  if (PERSONAL_PRONOUN_PATTERN.test(text)) warnings.push("Replace personal pronouns with the customer, the patient, or the relevant professional role.");
  if (/\b(?:utili[sz]e|freeware|mike|flat[- ]screen)\b/i.test(text)) warnings.push("Replace colloquial or unnecessarily complex wording with the preferred terminology from page 29.");
  return warnings;
}

function findLocalDocumentFacts(request) {
  const documents = Array.isArray(request.localDocuments) ? request.localDocuments : [];
  if (!documents.length) return [];
  const itemKey = productNameKey(request.itemName);
  const tokens = technicalFactTokens(request).filter((token) => token.length >= 3);
  const exclusionPattern = /\b(?:copyright|all rights reserved|confidential|disclaimer|references?|bibliography|testimonial|study|trial|investigat|regulatory|warning|caution|contraindication|e-?learning|education|enrol|licen[cs]e|purchase|pricing|order number|part number|material number)\b/i;
  const capabilityPattern = /\b(?:allow|combine|connect|control|deliver|display|enable|facilitate|feature|include|integrate|manage|overlay|provide|reduce|support|use|visuali[sz])(?:s|d|es|ing)?\b/i;
  const candidates = [];

  documents.forEach((documentSource, documentIndex) => {
    const documentNameKey = productNameKey(documentSource.name.replace(/\.[^.]+$/, ""));
    const documentIdentityMatch = itemKey.length >= 5 && documentNameKey.includes(itemKey);
    const parts = String(documentSource.text || "")
      .replace(/[\u2022\u25cf\u25aa]+/g, ". ")
      .split(/(?<=[.!?])\s+|\n+/)
      .map((part) => cleanGuidanceText(part).replace(/^[-*\d.)\s]+/, ""))
      .filter((part) => part.length >= 30 && part.length <= 360);

    parts.forEach((text, sentenceIndex) => {
      if (exclusionPattern.test(text) || /\b(?:you|your|we|our)\b/i.test(text)) return;
      if (guidanceExclusionReason(text)) return;
      const normalizedText = technicalSearchValue(text);
      const compactText = normalizedText.replace(/\s+/g, "");
      const directProductMatch = itemKey.length >= 5 && compactText.includes(itemKey);
      const matchedTokens = tokens.filter((token) => normalizedText.includes(token));
      const keywordEvidence = matchedTokens.filter((token) => !productNameKey(request.itemName).includes(token));
      if (!directProductMatch && !documentIdentityMatch && matchedTokens.length < 2) return;
      if (!directProductMatch && documentIdentityMatch && !keywordEvidence.length && !capabilityPattern.test(text)) return;
      let score = directProductMatch ? 180 : documentIdentityMatch ? 100 : 0;
      score += matchedTokens.length * 16 + keywordEvidence.length * 12;
      if (capabilityPattern.test(text)) score += 24;
      candidates.push({
        documentIndex,
        sentenceIndex,
        text: ensureSentence(normalizePhilipsLanguage(text)),
        sourceName: documentSource.name,
        extension: documentSource.extension,
        truncated: Boolean(documentSource.truncated),
        score,
      });
    });
  });

  const seen = new Set();
  const perDocument = new Map();
  return candidates
    .sort((a, b) => b.score - a.score || a.documentIndex - b.documentIndex || a.sentenceIndex - b.sentenceIndex)
    .filter((candidate) => {
      const signature = normalize(candidate.text).replace(/[^a-z0-9]+/g, " ").trim();
      if (!signature || seen.has(signature)) return false;
      const count = perDocument.get(candidate.sourceName) || 0;
      if (count >= 3) return false;
      seen.add(signature);
      perDocument.set(candidate.sourceName, count + 1);
      return true;
    })
    .slice(0, 10);
}

function buildLocalDraft(request) {
  const rawKeywordPhrases = splitGuidancePhrases(request.keywords, 8);
  const rawFacts = splitGuidancePhrases(request.facts, 12);
  const feedback = parseDraftFeedback(request.feedback);
  const sourceAllowed = (source) => !feedback.exclusive.length || feedback.exclusive.includes(source);
  const nameResolution = resolveProductName(request.itemName);
  const itemName = nameResolution.name;
  const audience = normalizePhilipsLanguage(request.audience);
  const references = sourceAllowed("catalogue") ? findGuidanceReferences(request) : [];
  const catalogueProductSources = sourceAllowed("catalogue") ? findCatalogueProductSources(request) : [];
  const matchedTechnicalFacts = findTechnicalFacts(request);
  const matchedSharePointFacts = findSharePointFacts(request);
  const matchedSharePointDocuments = findSharePointDocumentReferences(request);
  const matchedLocalDocumentFacts = findLocalDocumentFacts(request);
  const warnings = [`${GUIDANCE_LABEL} were applied locally. Complete the required human spelling, grammar, syntax, and claims review before approval.`];

  if (feedback.text) {
    warnings.push("User feedback was applied as editorial and source-selection direction; it was not treated as approved product evidence.");
    if (feedback.exclusive.length) warnings.push(`Exclusive source focus requested: ${feedbackSourceList(feedback.exclusive)}. Other source types were excluded from this version.`);
    else if (feedback.priority.length) warnings.push(`Source priority requested: ${feedbackSourceList(feedback.priority)}. Matching evidence from these sources was placed first where available.`);
    if (feedback.detail === "expanded") warnings.push("Expanded-detail feedback was applied within the available screened evidence.");
    if (feedback.detail === "concise") warnings.push("Concise feedback was applied by limiting supporting sentences while preserving sourced product facts.");
  }

  if (nameResolution.changed) warnings.push(`Product naming was aligned to “${itemName}” using ${nameResolution.source}. Confirm the official trademark spelling in Philips Product Library or Windchill.`);
  else if (itemName && !nameResolution.matched) warnings.push("No exact catalogue or workbook match was found for the product name. Confirm its official spelling and capitalization in Philips Product Library or Windchill.");

  const excludedPhrases = [];
  const filterGuidedPhrases = (phrases) => phrases
    .map(normalizeGuidedPhrase)
    .filter((phrase) => {
      const reason = guidanceExclusionReason(phrase);
      const unexplainedAcronyms = findUnexplainedAcronyms(phrase);
      if (reason) {
        excludedPhrases.push(`${phrase} (${reason})`);
        return false;
      }
      if (unexplainedAcronyms.length) {
        excludedPhrases.push(`${phrase} (unexplained acronym: ${unexplainedAcronyms.join(", ")})`);
        return false;
      }
      return true;
    });
  const keywordPhrases = filterGuidedPhrases(rawKeywordPhrases);
  const facts = sourceAllowed("manual") ? filterGuidedPhrases(rawFacts) : [];
  const name = itemName || keywordPhrases[0] || "New item";
  const catalogueProductSentences = buildCatalogueProductSentences(name, catalogueProductSources);

  const technicalFacts = matchedTechnicalFacts.filter((fact) => {
    const acronyms = findUnexplainedAcronyms(normalizeGuidedPhrase(`${fact.parameter} ${fact.value}`));
    if (!acronyms.length) return true;
    excludedPhrases.push(`${fact.subitem} · ${fact.parameter} (unexplained acronym: ${acronyms.join(", ")})`);
    return false;
  }).filter(() => sourceAllowed("workbook"));
  const sharePointFacts = matchedSharePointFacts.filter((fact) => {
    const reason = guidanceExclusionReason(fact.text);
    const acronyms = findUnexplainedAcronyms(normalizeGuidedPhrase(`${fact.product} ${fact.text}`));
    if (!reason && !acronyms.length) return true;
    excludedPhrases.push(`${fact.product} · ${fact.topic} (${reason || `unexplained acronym: ${acronyms.join(", ")}`})`);
    return false;
  }).filter((fact) => sourceAllowed(fact._collection === "sales-portal" ? "sales-portal" : "strategy"));
  const strategySharePointFacts = sharePointFacts.filter((fact) => fact._collection !== "sales-portal");
  const salesPortalFacts = sharePointFacts.filter((fact) => fact._collection === "sales-portal");
  const strategySharePointDocuments = matchedSharePointDocuments.filter((documentSource) => documentSource._collection !== "sales-portal" && sourceAllowed("strategy"));
  const salesPortalDocuments = matchedSharePointDocuments.filter((documentSource) => documentSource._collection === "sales-portal" && sourceAllowed("sales-portal"));
  const localDocumentFacts = matchedLocalDocumentFacts.filter((fact) => {
    const reason = guidanceExclusionReason(fact.text);
    const acronyms = findUnexplainedAcronyms(normalizeGuidedPhrase(fact.text));
    if (!reason && !acronyms.length) return true;
    excludedPhrases.push(`${fact.sourceName} (${reason || `unexplained acronym: ${acronyms.join(", ")}`})`);
    return false;
  }).filter(() => sourceAllowed("attached"));

  if (excludedPhrases.length) warnings.push(`Excluded content that conflicts with pages 15-29: ${excludedPhrases.join("; ")}.`);
  if (request.localDocuments?.length) {
    warnings.push(`${request.localDocuments.length} attached document${request.localDocuments.length === 1 ? " was" : "s were"} processed locally. Only ${localDocumentFacts.length} relevant screened passage${localDocumentFacts.length === 1 ? " was" : "s were"} used; confirm source approval, applicability, and claims before approval.`);
    if (!localDocumentFacts.length) warnings.push("No suitable product fact matched the item and keywords in the attached documents, so they did not influence the draft.");
    if (request.localDocuments.some((documentSource) => documentSource.truncated)) warnings.push("At least one attached document exceeded the 60,000-character screening limit. Review the source trace and confirm that no relevant later section was omitted.");
  }
  if (request.localDocumentErrors?.length) warnings.push(`Attached documents not used: ${request.localDocumentErrors.map((error) => `${error.name} (${error.message})`).join("; ")}.`);
  if (technicalFacts.some((fact) => fact.applicability?.length)) warnings.push("Workbook facts can be configuration-specific. Confirm the applicability codes shown under each sourced fact before approval.");
  if (strategySharePointFacts.length) {
    warnings.push(`SharePoint facts came from the verified local snapshot dated ${state.sharePointSource?.snapshotDate || "unknown"}. Open the linked files and confirm current approval and market applicability before use.`);
    if (state.sharePointSource?.continuationAvailable) warnings.push("The SharePoint connector reported additional files beyond its returned folder page. Check Source coverage before final approval.");
  }
  if (salesPortalFacts.length) {
    warnings.push(`Sales Portal facts came from the audited local snapshot dated ${state.salesPortalSource?.snapshotDate || "unknown"}. Open each linked source and confirm current approval, product version, and market applicability before use.`);
    if (!state.salesPortalSource?.enumerationComplete || state.salesPortalSource?.contentIndexedDocumentCount !== state.salesPortalSource?.observedDocumentCount) {
      warnings.push("The Sales Portal coverage audit found an enumeration or readable-content gap. Only content-indexed passages were eligible for the draft; check Source coverage before approval.");
    }
  }
  const selectedSharePointDocuments = [...strategySharePointDocuments, ...salesPortalDocuments];
  const registerOnlyDocuments = selectedSharePointDocuments.filter((documentSource) => !documentSource.contentIndexed);
  if (registerOnlyDocuments.length) {
    warnings.push(`Source coverage gate: ${registerOnlyDocuments.length} of ${selectedSharePointDocuments.length} matching SharePoint documents are registered but not content-indexed. They were not used as claim evidence; review or index them before approval.`);
  }
  if (catalogueProductSentences.length) {
    warnings.push(`The draft uses product-specific language from ${catalogueProductSources.length} existing catalogue record${catalogueProductSources.length === 1 ? "" : "s"}. Confirm that the selected product variant and market remain applicable before approval.`);
  }

  const editorialAcronymSource = [itemName, keywordPhrases[0], ...facts.map(professionalizeFactClause)].filter(Boolean).join(" ");
  const unexplainedAcronyms = findUnexplainedAcronyms(editorialAcronymSource);
  if (unexplainedAcronyms.length) warnings.push(`Define Philips-specific or uncommon acronyms on first use: ${unexplainedAcronyms.join(", ")}.`);
  if (/\b(?:cm|kg|mm|meter|inch|lb|lbs)\b/i.test(request.facts)) warnings.push("Metric and US equivalents were added where possible. Verify converted measurements against the approved source before approval.");

  if (!itemName) warnings.push("No item name was supplied; replace the working name before approval.");
  if (!facts.length && !technicalFacts.length && !sharePointFacts.length && !localDocumentFacts.length && !catalogueProductSentences.length) warnings.push("No approved product fact matched the request. Refine the keywords or add verified facts before approval.");
  if (feedback.exclusive.length && !facts.length && !technicalFacts.length && !sharePointFacts.length && !localDocumentFacts.length && !catalogueProductSentences.length) {
    warnings.push(`No matching approved evidence was found in the exclusively selected sources: ${feedbackSourceList(feedback.exclusive)}. Broaden the source focus or refine the product name and keywords.`);
  }
  if (sourceAllowed("catalogue") && !references.length) warnings.push("No close catalogue match was found; the draft uses the local template only.");

  const approvedEvidenceText = [
    ...facts,
    ...technicalFacts.flatMap((fact) => [fact.item, fact.subitem, fact.parameter, fact.value]),
    ...sharePointFacts.map((fact) => fact.text),
    ...localDocumentFacts.map((fact) => fact.text),
    ...catalogueProductSentences,
  ].join(" ");
  const unmatchedKeywords = keywordPhrases.filter((phrase) => {
    const tokens = technicalSearchValue(phrase)
      .split(" ")
      .filter((token) => token.length > 2 && !GUIDANCE_STOP_WORDS.has(token));
    const evidence = technicalSearchValue(approvedEvidenceText);
    return tokens.length && !tokens.some((token) => evidence.includes(token));
  });
  if (unmatchedKeywords.length) {
    warnings.push(`Keywords not supported by the matched approved sources were omitted from the draft: ${unmatchedKeywords.join(", ")}.`);
  }

  const applicabilityCodes = new Set(state.technicalFacts.flatMap((fact) => fact.applicability || []).map((code) => normalize(code)));
  const topics = keywordPhrases
    .filter((phrase) => normalize(phrase) !== normalize(name))
    .filter((phrase) => !applicabilityCodes.has(normalize(phrase)))
    .slice(0, 4);

  const workbookNarrativeFacts = sharePointFacts.length ? [] : technicalFacts
    .filter((fact) => /^present$/i.test(cleanGuidanceText(fact.value)))
    .map((fact) => fact.parameter);
  const manualConcepts = new Set(deriveFactConcepts(facts));
  const localDocumentSentences = localDocumentFacts.flatMap((fact) => {
    const sourceConcepts = deriveFactConcepts([fact.text]);
    if (facts.length && sourceConcepts.some((concept) => manualConcepts.has(concept))) return [];
    return [ensureSentence(normalizePhilipsLanguage(fact.text))];
  });
  const sharePointSentence = (fact) => {
    const sourceConcepts = deriveFactConcepts([fact.text]);
    if (facts.length && sourceConcepts.some((concept) => manualConcepts.has(concept))) return "";
    return ensureSentence(normalizePhilipsLanguage(fact.text));
  };
  const includeTechnicalDetails = !sharePointFacts.length
    || feedback.detail === "expanded"
    || feedback.priority.includes("workbook")
    || feedback.exclusive.includes("workbook");
  const includeCatalogueDetails = Boolean(catalogueProductSentences.length) && (
    (!facts.length && !sharePointFacts.length && !localDocumentFacts.length)
    || sharePointFacts.length + localDocumentFacts.length < 6
    || feedback.detail === "expanded"
    || feedback.priority.includes("catalogue")
    || feedback.exclusive.includes("catalogue")
  );
  const sentenceGroups = {
    manual: buildProfessionalFactSentences(name, audience, facts),
    workbook: [
      ...buildProfessionalFactSentences(name, audience, workbookNarrativeFacts),
      ...(includeTechnicalDetails ? technicalFacts
        .filter((fact) => !/^present$/i.test(cleanGuidanceText(fact.value)))
        .map((fact) => technicalFactSentence(name, fact)) : []),
    ],
    attached: localDocumentSentences,
    strategy: strategySharePointFacts.map(sharePointSentence).filter(Boolean),
    "sales-portal": salesPortalFacts.map(sharePointSentence).filter(Boolean),
    catalogue: includeCatalogueDetails ? catalogueProductSentences : [],
  };
  const defaultSourceOrder = ["manual", "attached", "strategy", "sales-portal", "workbook", "catalogue"];
  const sourceOrder = [...new Set([
    ...feedback.priority,
    ...defaultSourceOrder,
  ])].filter(sourceAllowed);
  const featureSentenceLimit = feedback.detail === "concise" ? 5 : feedback.detail === "expanded" ? 16 : 12;
  const featureSentences = [];
  sourceOrder.forEach((source) => {
    orderSentencesForFeedback(sentenceGroups[source] || [], feedback.text).forEach((sentence) => {
      if (!sentence || featureSentences.length >= featureSentenceLimit) return;
      if (!featureSentences.some((candidate) => salesSentencesOverlap(candidate, sentence))) featureSentences.push(sentence);
    });
  });
  if (!featureSentences.length) {
    const focus = topics.length ? ` focused on ${joinNaturally(topics.map((topic) => lowerInitial(phraseWithoutTerminalPunctuation(topic))))}` : "";
    featureSentences.push(ensureSentence(`${name} is a working draft${focus}`));
  }

  const shortEvidence = [
    ...facts,
    ...catalogueProductSentences,
    ...sharePointFacts.map((fact) => fact.text),
    ...localDocumentFacts.map((fact) => fact.text),
    ...technicalFacts.map((fact) => `${fact.parameter} ${fact.value}`),
  ];
  const shortText = buildShortSalesText(name, audience, featureSentences, shortEvidence);
  const shortWordCount = salesTextWordCount(shortText);
  if (shortWordCount < 15) warnings.push(`The short draft contains ${shortWordCount} words because the matched approved sources do not provide enough detail for the 15-20 word target.`);

  const paragraphs = [];
  if (featureSentences.length <= 3) {
    paragraphs.push(featureSentences.join(" "));
  } else {
    for (let index = 0; index < featureSentences.length;) {
      const remaining = featureSentences.length - index;
      const paragraphLength = remaining === 3 ? 3 : 2;
      paragraphs.push(featureSentences.slice(index, index + paragraphLength).join(" "));
      index += paragraphLength;
    }
  }
  const featureBody = paragraphs.join("\n\n");
  const sections = [["Features of the product", featureBody]];
  const longText = sections.map(([heading, body]) => `${heading}\n\n${body}`).join("\n\n");
  warnings.push(...draftComplianceWarnings(`${shortText} ${longText}`));

  return {
    model: `Guide pp. 15-29${feedback.text ? " | feedback applied" : ""} | ${technicalFacts.length} workbook | ${strategySharePointFacts.length} SharePoint | ${salesPortalFacts.length} portal | ${localDocumentFacts.length} attached | ${catalogueProductSources.length || references.length} catalogue`,
    feedback: {
      text: feedback.text,
      exclusiveSources: feedback.exclusive,
      prioritySources: feedback.priority,
      detail: feedback.detail,
    },
    references,
    technicalSource: {
      metadata: state.technicalSource,
      facts: technicalFacts,
    },
    sharePointSource: {
      metadata: state.sharePointSource,
      facts: strategySharePointFacts,
      documentReferences: strategySharePointDocuments,
    },
    salesPortalSource: {
      metadata: state.salesPortalSource,
      facts: salesPortalFacts,
      documentReferences: salesPortalDocuments,
    },
    localDocumentSource: {
      documents: (request.localDocuments || []).map(({ name, extension, size, originalCharacters, truncated }) => ({ name, extension, size, originalCharacters, truncated })),
      facts: localDocumentFacts,
      errors: request.localDocumentErrors || [],
    },
    drafts: {
      shortText,
      longText,
      factWarnings: [...new Set(warnings)],
    },
  };
}

function showDraftError(message) {
  elements.draftError.querySelector("p").textContent = message;
  elements.draftError.hidden = false;
}

function renderDraftReferences(references) {
  const fragment = document.createDocumentFragment();
  if (!references.length) {
    const chip = document.createElement("span");
    chip.className = "reference-chip";
    chip.textContent = "No close catalogue match found";
    fragment.append(chip);
  } else {
    references.forEach((reference) => {
      const chip = document.createElement("span");
      chip.className = "reference-chip";
      const id = document.createElement("b");
      id.textContent = reference.id;
      chip.append(id, document.createTextNode(reference.name));
      fragment.append(chip);
    });
  }
  elements.draftReferences.replaceChildren(fragment);
}

function renderTechnicalSource(source) {
  const metadata = source?.metadata;
  const facts = source?.facts || [];
  elements.technicalFacts.replaceChildren();

  if (!metadata) {
    elements.technicalSourceSummary.textContent = "The Azurion workbook source is unavailable. No workbook fact was inserted into this draft.";
    return;
  }

  const sourceName = document.createElement("strong");
  sourceName.textContent = metadata.sourceFile;
  const sourceMessage = facts.length
    ? ` supplied ${facts.length} matching Approved product fact${facts.length === 1 ? "" : "s"} from the complete ${metadata.indexedSheetCount || 1}-worksheet substantive index. These facts were used directly or as verification for the draft.`
    : ` was checked as the Approved product facts source. No confident match was found, so no unrelated workbook fact was inserted.`;
  elements.technicalSourceSummary.replaceChildren(sourceName, document.createTextNode(sourceMessage));

  facts.forEach((fact) => {
    const card = document.createElement("article");
    card.className = "technical-fact-card";
    const heading = document.createElement("b");
    heading.textContent = `${fact.subitem} · ${fact.parameter}`;
    const location = document.createElement("small");
    location.textContent = `${fact.sheet || metadata.sheetName} · row ${fact.row}`;
    const value = document.createElement("p");
    const applicability = fact.applicability?.length ? ` Applies to: ${fact.applicability.join(", ")}.` : "";
    value.textContent = `${fact.value}${applicability}`;
    card.append(heading, location, value);
    elements.technicalFacts.append(card);
  });
}

function renderLocalDocumentSource(source) {
  const documents = source?.documents || [];
  const facts = source?.facts || [];
  const errors = source?.errors || [];
  elements.localDocumentFacts.replaceChildren();

  if (!documents.length && !errors.length) {
    elements.localDocumentSourceSummary.textContent = "No local supporting document was attached to this draft.";
    return;
  }

  const summary = document.createElement("strong");
  summary.textContent = `${documents.length} attached document${documents.length === 1 ? "" : "s"}`;
  const summaryText = facts.length
    ? ` supplied ${facts.length} matching screened passage${facts.length === 1 ? "" : "s"}. The files were read locally for this draft and were not uploaded to an external service.`
    : " were read locally, but no matching product fact was selected for the draft.";
  elements.localDocumentSourceSummary.replaceChildren(summary, document.createTextNode(summaryText));

  facts.forEach((fact) => {
    const card = document.createElement("article");
    card.className = "technical-fact-card";
    const heading = document.createElement("b");
    heading.textContent = fact.sourceName;
    const location = document.createElement("small");
    location.textContent = `Local supporting document${fact.extension ? ` · ${fact.extension.replace(/^\./, "").toUpperCase()}` : ""}${fact.truncated ? " · screened text truncated" : ""}`;
    const value = document.createElement("p");
    value.textContent = fact.text;
    card.append(heading, location, value);
    elements.localDocumentFacts.append(card);
  });

  const filesWithFacts = new Set(facts.map((fact) => fact.sourceName));
  documents
    .filter((documentSource) => !filesWithFacts.has(documentSource.name))
    .forEach((documentSource) => {
      const card = document.createElement("article");
      card.className = "technical-fact-card";
      const heading = document.createElement("b");
      heading.textContent = documentSource.name;
      const location = document.createElement("small");
      location.textContent = documentSource.truncated
        ? "Read locally — screening limit reached; no matching passage selected"
        : "Read locally — no matching passage selected";
      card.append(heading, location);
      elements.localDocumentFacts.append(card);
    });

  errors.forEach((documentError) => {
    const card = document.createElement("article");
    card.className = "technical-fact-card";
    const heading = document.createElement("b");
    heading.textContent = documentError.name;
    const location = document.createElement("small");
    location.textContent = `Not used — ${documentError.message}`;
    card.append(heading, location);
    elements.localDocumentFacts.append(card);
  });
}

function renderSharePointSource(source, summaryElement = elements.sharePointSourceSummary, factsElement = elements.sharePointFacts, sourceLabel = "SharePoint snapshot") {
  const metadata = source?.metadata;
  const facts = source?.facts || [];
  const documentReferences = source?.documentReferences || [];
  factsElement.replaceChildren();

  if (!metadata) {
    summaryElement.textContent = `The ${sourceLabel} is unavailable. No fact from this source was inserted into this draft.`;
    return;
  }

  const sourceName = document.createElement("a");
  sourceName.href = metadata.folderUrl;
  sourceName.target = "_blank";
  sourceName.rel = "noreferrer";
  sourceName.textContent = metadata.sourceName;
  const factBackedDocumentCount = metadata.factBackedDocumentCount ?? metadata.documentCount ?? 0;
  const sourceMessage = facts.length
    ? ` supplied ${facts.length} matching fact${facts.length === 1 ? "" : "s"} from ${factBackedDocumentCount} fact-backed documents in the ${metadata.snapshotDate} local snapshot. ${documentReferences.length} matching registered document${documentReferences.length === 1 ? " was" : "s were"} checked for coverage; only fact-backed content was used in the draft.`
    : ` was checked through its ${metadata.snapshotDate} local snapshot. No confident product match was found, so no unrelated SharePoint fact was inserted.`;
  summaryElement.replaceChildren(sourceName, document.createTextNode(sourceMessage));

  facts.forEach((fact) => {
    const card = document.createElement("article");
    card.className = "technical-fact-card";
    const heading = document.createElement("b");
    heading.textContent = `${fact.product} · ${fact.topic}`;
    const location = document.createElement("small");
    const market = (fact.markets || (fact.source?.market ? [fact.source.market] : [])).join(", ");
    const updated = fact.source?.updatedAt ? ` · updated ${fact.source.updatedAt.slice(0, 10)}` : "";
    location.textContent = `${fact.source?.title || "SharePoint document"}${market ? ` · ${market}` : ""}${updated}`;
    const value = document.createElement("p");
    value.textContent = fact.text;
    card.append(heading, location, value);
    if (fact.evidence?.quote) {
      const evidence = document.createElement("details");
      const label = document.createElement("summary");
      label.textContent = `Supporting passage · checked ${fact.evidence.verifiedAt.slice(0, 10)}`;
      const quote = document.createElement("blockquote");
      quote.textContent = fact.evidence.quote;
      evidence.append(label, quote);
      card.append(evidence);
    }
    if (fact.source?.url) {
      const link = document.createElement("a");
      link.className = "technical-source-link";
      link.href = fact.source.url;
      link.target = "_blank";
      link.rel = "noreferrer";
      link.textContent = "Open source document";
      card.append(link);
    }
    factsElement.append(card);
  });

  const factTitles = new Set(facts.map((fact) => normalize(fact.source?.title)));
  documentReferences
    .filter((documentSource) => !factTitles.has(normalize(documentSource.title)))
    .forEach((documentSource) => {
      const card = document.createElement("article");
      card.className = "technical-fact-card";
      const heading = document.createElement("b");
      heading.textContent = documentSource.title;
      const location = document.createElement("small");
      location.textContent = documentSource.contentIndexed
        ? "Content-indexed source — no matching fact selected"
        : "Register only — content not used for claims";
      card.append(heading, location);
      if (documentSource.url) {
        const link = document.createElement("a");
        link.className = "technical-source-link";
        link.href = documentSource.url;
        link.target = "_blank";
        link.rel = "noreferrer";
        link.textContent = "Open source document";
        card.append(link);
      }
      factsElement.append(card);
    });
}

function historyTimestamp(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Unknown date" : historyDateFormat.format(date);
}

function historyPayload(payload) {
  const stored = JSON.parse(JSON.stringify(payload, (key, value) => (key === "_fields" || key === "score" ? undefined : value)));
  stored.references = (stored.references || []).map(({ id, name }) => ({ id, name }));
  return stored;
}

function loadDraftHistory() {
  try {
    const stored = JSON.parse(localStorage.getItem(HISTORY_STORAGE_KEY) || "[]");
    state.history = Array.isArray(stored)
      ? stored.filter((entry) => entry?.id && entry?.payload?.drafts).slice(0, HISTORY_LIMIT)
      : [];
  } catch {
    state.history = [];
  }
}

function persistDraftHistory() {
  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(state.history.slice(0, HISTORY_LIMIT)));
  } catch {
    state.history = state.history.slice(0, Math.min(40, state.history.length));
    try {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(state.history));
    } catch {
      // History remains available for the current session when browser storage is unavailable.
    }
  }
}

function historyPreview(entry) {
  return cleanGuidanceText(entry.payload?.drafts?.longText || entry.payload?.drafts?.shortText || "")
    .replace(/^Features of the product\s*/i, "");
}

function renderDraftHistory() {
  elements.historyCount.textContent = formatNumber.format(state.history.length);
  elements.historyEmpty.hidden = state.history.length > 0;
  const fragment = document.createDocumentFragment();

  state.history.forEach((entry) => {
    const listItem = document.createElement("div");
    listItem.setAttribute("role", "listitem");
    const button = document.createElement("button");
    button.type = "button";
    button.className = `history-item${entry.id === state.currentHistoryId ? " is-selected" : ""}`;
    button.setAttribute("aria-label", `Restore ${entry.request?.itemName || "untitled draft"} from ${historyTimestamp(entry.createdAt)}`);

    const top = document.createElement("span");
    top.className = "history-item-top";
    const name = document.createElement("strong");
    name.textContent = cleanGuidanceText(entry.request?.itemName) || splitGuidancePhrases(entry.request?.keywords, 1)[0] || "Untitled draft";
    const time = document.createElement("time");
    time.dateTime = entry.createdAt;
    time.textContent = historyTimestamp(entry.createdAt).replace(/,?\s*\d{4},?/, "");
    top.append(name, time);

    const preview = document.createElement("p");
    preview.textContent = historyPreview(entry) || "Draft saved without preview text.";

    const meta = document.createElement("span");
    meta.className = "history-item-meta";
    const facts = document.createElement("span");
    const factCount = (entry.payload?.technicalSource?.facts?.length || 0)
      + (entry.payload?.localDocumentSource?.facts?.length || 0)
      + (entry.payload?.sharePointSource?.facts?.length || 0)
      + (entry.payload?.salesPortalSource?.facts?.length || 0);
    facts.textContent = `${factCount} source fact${factCount === 1 ? "" : "s"}`;
    const references = document.createElement("span");
    const referenceCount = entry.payload?.references?.length || 0;
    references.textContent = `${referenceCount} reference${referenceCount === 1 ? "" : "s"}`;
    meta.append(facts, references);

    button.append(top, preview, meta);
    button.addEventListener("click", () => restoreHistoryEntry(entry.id));
    listItem.append(button);
    fragment.append(listItem);
  });

  elements.historyList.replaceChildren(fragment);
}

function createHistoryEntry(request, payload) {
  const createdAt = new Date().toISOString();
  const id = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  const entry = {
    id,
    createdAt,
    updatedAt: createdAt,
    request: {
      itemName: request.itemName,
      keywords: request.keywords,
      facts: request.facts,
      audience: request.audience,
      feedback: request.feedback,
      documentNames: (request.localDocuments || []).map((documentSource) => documentSource.name),
    },
    payload: historyPayload(payload),
  };
  state.history.unshift(entry);
  state.history = state.history.slice(0, HISTORY_LIMIT);
  state.currentHistoryId = id;
  persistDraftHistory();
  renderDraftHistory();
  return entry;
}

function renderDraftTrace(entry, payload, restored = false) {
  if (!entry) {
    elements.draftTrace.textContent = "This draft is not yet stored in local history.";
    return;
  }
  const sourceCount = payload?.technicalSource?.facts?.length || 0;
  const localDocumentCount = payload?.localDocumentSource?.facts?.length || 0;
  const sharePointCount = payload?.sharePointSource?.facts?.length || 0;
  const salesPortalCount = payload?.salesPortalSource?.facts?.length || 0;
  const referenceCount = payload?.references?.length || 0;
  const action = restored ? "Restored" : "Saved";
  const feedbackTrace = payload?.feedback?.text ? " · feedback applied" : "";
  elements.draftTrace.textContent = `${action} ${historyTimestamp(entry.createdAt)} · ${sourceCount} workbook fact${sourceCount === 1 ? "" : "s"} · ${localDocumentCount} attached-document fact${localDocumentCount === 1 ? "" : "s"} · ${sharePointCount} SharePoint fact${sharePointCount === 1 ? "" : "s"} · ${salesPortalCount} Sales Portal fact${salesPortalCount === 1 ? "" : "s"} · ${referenceCount} catalogue reference${referenceCount === 1 ? "" : "s"}${feedbackTrace}`;
}

function restoreHistoryEntry(id) {
  const entry = state.history.find((candidate) => candidate.id === id);
  if (!entry) return;
  clearTimeout(historyUpdateTimer);
  state.currentHistoryId = id;
  elements.draftItemName.value = entry.request?.itemName || "";
  elements.draftKeywords.value = entry.request?.keywords || "";
  elements.draftFacts.value = entry.request?.facts || "";
  elements.draftAudience.value = entry.request?.audience || "";
  elements.draftFeedback.value = entry.request?.feedback || entry.payload?.feedback?.text || "";
  state.supportingFiles = [];
  elements.draftDocuments.value = "";
  renderSupportingFiles();
  if (entry.request?.documentNames?.length) {
    setDocumentStatus(`Source trace restored. Reattach ${entry.request.documentNames.join(", ")} to regenerate with those local files.`);
  }
  renderDraftResult(entry.payload, { historyEntry: entry, restored: true });
  renderDraftHistory();
  showToast("Draft and source trace restored");
}

function syncCurrentDraftToHistory() {
  const entry = state.history.find((candidate) => candidate.id === state.currentHistoryId);
  if (!entry || !state.drafts) return;
  entry.payload.drafts = JSON.parse(JSON.stringify(state.drafts));
  entry.updatedAt = new Date().toISOString();
  persistDraftHistory();
  renderDraftHistory();
  renderDraftTrace(entry, entry.payload, true);
}

function renderFactWarnings(warnings) {
  elements.factWarnings.hidden = warnings.length === 0;
  if (!warnings.length) {
    elements.factWarnings.replaceChildren();
    return;
  }
  const title = document.createElement("strong");
  title.textContent = "Check before approval";
  const list = document.createElement("ul");
  warnings.forEach((warning) => {
    const item = document.createElement("li");
    item.textContent = warning;
    list.append(item);
  });
  elements.factWarnings.replaceChildren(title, list);
}

function renderActiveDraft() {
  if (!state.drafts) return;
  const isShort = state.activeDraft === "short";
  const text = isShort ? state.drafts.shortText : state.drafts.longText;
  elements.draftShortTab.setAttribute("aria-selected", String(isShort));
  elements.draftLongTab.setAttribute("aria-selected", String(!isShort));
  elements.draftEditor.value = text;
  elements.draftCount.textContent = `${formatNumber.format(salesTextWordCount(text))} words · ${formatNumber.format(text.length)} characters`;
}

function renderDraftResult(payload, { historyEntry = null, restored = false } = {}) {
  state.drafts = payload.drafts;
  state.activeDraft = "short";
  if (historyEntry) state.currentHistoryId = historyEntry.id;
  elements.draftModel.textContent = payload.model || "Local guided draft";
  elements.draftEmpty.hidden = true;
  elements.draftError.hidden = true;
  elements.draftResult.hidden = false;
  renderTechnicalSource(payload.technicalSource);
  renderLocalDocumentSource(payload.localDocumentSource);
  renderSharePointSource(payload.sharePointSource);
  renderSharePointSource(payload.salesPortalSource, elements.salesPortalSourceSummary, elements.salesPortalFacts, "IGT Systems Sales Portal snapshot");
  renderDraftReferences(payload.references || []);
  renderFactWarnings(payload.drafts.factWarnings || []);
  renderDraftTrace(historyEntry, payload, restored);
  renderActiveDraft();
  updateFeedbackUi();
}

async function handleDraftGeneration(event) {
  event.preventDefault();
  clearTimeout(historyUpdateTimer);
  elements.draftError.hidden = true;

  const request = {
    itemName: elements.draftItemName.value,
    keywords: elements.draftKeywords.value,
    facts: elements.draftFacts.value,
    audience: elements.draftAudience.value,
    feedback: elements.draftFeedback.value,
  };
  if (!request.keywords.trim()) {
    elements.draftKeywords.focus();
    showDraftError("Add at least one keyword or key phrase.");
    return;
  }

  try {
    setDraftLoading(true);
    const localDocumentSource = await extractSupportingDocuments();
    request.localDocuments = localDocumentSource.documents;
    request.localDocumentErrors = localDocumentSource.errors;
    const payload = buildLocalDraft(request);
    const historyEntry = createHistoryEntry(request, payload);
    renderDraftResult(payload, { historyEntry });
  } catch (error) {
    showDraftError(error.message || "The draft could not be generated.");
  } finally {
    setDraftLoading(false);
  }
}

async function handleCopyDraft() {
  const text = elements.draftEditor.value.trim();
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    elements.draftEditor.select();
    document.execCommand("copy");
  }
  showToast(`${state.activeDraft === "short" ? "Short" : "Long"} draft copied`);
}

function bindEvents() {
  elements.search.addEventListener("input", (event) => {
    state.query = event.target.value;
    elements.clearSearch.hidden = !state.query;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => applySearch(), 70);
  });
  elements.clearSearch.addEventListener("click", () => {
    state.query = "";
    elements.search.value = "";
    applySearch();
    elements.search.focus();
  });
  elements.typeFilter.addEventListener("change", (event) => {
    state.type = event.target.value;
    applySearch();
  });
  elements.availabilityFilter.addEventListener("change", (event) => {
    state.availability = event.target.value;
    applySearch();
  });
  elements.resetFilters.addEventListener("click", clearAllFilters);
  elements.loadMore.addEventListener("click", () => {
    state.visible += 50;
    renderResults();
  });
  elements.shortTab.addEventListener("click", () => {
    state.activeText = "short";
    renderActiveText();
  });
  elements.longTab.addEventListener("click", () => {
    state.activeText = "long";
    renderActiveText();
  });
  elements.copyCurrent.addEventListener("click", copyActiveText);
  elements.copyCurrentTop.addEventListener("click", copyActiveText);
  elements.openCoverage.addEventListener("click", () => setCoverageOpen(true));
  elements.closeCoverage.addEventListener("click", () => setCoverageOpen(false));
  elements.coverageBackdrop.addEventListener("click", () => setCoverageOpen(false));
  elements.openComposer.addEventListener("click", () => setComposerOpen(true));
  elements.closeComposer.addEventListener("click", () => setComposerOpen(false));
  elements.composerBackdrop.addEventListener("click", () => setComposerOpen(false));
  elements.draftDocuments.addEventListener("change", handleSupportingFileSelection);
  elements.draftFeedback.addEventListener("input", updateFeedbackUi);
  elements.composerForm.addEventListener("submit", handleDraftGeneration);
  elements.draftShortTab.addEventListener("click", () => {
    state.activeDraft = "short";
    renderActiveDraft();
  });
  elements.draftLongTab.addEventListener("click", () => {
    state.activeDraft = "long";
    renderActiveDraft();
  });
  elements.draftEditor.addEventListener("input", () => {
    if (!state.drafts) return;
    const key = state.activeDraft === "short" ? "shortText" : "longText";
    state.drafts[key] = elements.draftEditor.value;
    elements.draftCount.textContent = `${formatNumber.format(salesTextWordCount(elements.draftEditor.value))} words · ${formatNumber.format(elements.draftEditor.value.length)} characters`;
    clearTimeout(historyUpdateTimer);
    historyUpdateTimer = setTimeout(syncCurrentDraftToHistory, 350);
  });
  elements.copyDraft.addEventListener("click", handleCopyDraft);
  document.addEventListener("keydown", (event) => {
    const isTyping = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName);
    if (event.key === "/" && !isTyping) {
      event.preventDefault();
      elements.search.focus();
    }
    if (event.key === "Escape") {
      if (!elements.coveragePanel.hidden) {
        setCoverageOpen(false);
        return;
      }
      if (!elements.composerPanel.hidden) {
        setComposerOpen(false);
        return;
      }
      if (state.query) {
        state.query = "";
        elements.search.value = "";
        applySearch();
      }
      elements.search.blur();
    }
  });
}

async function initialise() {
  bindEvents();
  prepareSharePointManifest(window.SHAREPOINT_SOURCE_MANIFEST);
  prepareTechnicalSource(window.AZURION_TECHNICAL_DATA);
  prepareSharePointSource(window.SHAREPOINT_PRODUCT_FACTS);
  prepareSalesPortalSource(window.IGT_SALES_PORTAL_SOURCE);
  renderCoverageDashboard();
  loadDraftHistory();
  renderDraftHistory();
  updateFeedbackUi();
  try {
    let payload = window.SALES_DATA;
    if (!payload) {
      const response = await fetch("public/data/items.json");
      if (!response.ok) throw new Error(`Data request failed with ${response.status}`);
      payload = await response.json();
    }
    state.items = payload.items.map((item) => ({ ...item, _search: makeSearchIndex(item) }));
    elements.sourceLabel.textContent = catalogueSourceLabel(payload.metadata);

    [...new Set(state.items.map((item) => item.itemType).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b))
      .forEach((type) => {
        const option = document.createElement("option");
        option.value = type;
        option.textContent = type.replaceAll("_", " ");
        elements.typeFilter.append(option);
      });

    applySearch();
    const initialId = new URLSearchParams(location.hash.replace(/^#/, "")).get("id");
    const initialItem = initialId && state.items.find((item) => item.id === initialId);
    if (initialItem) selectItem(initialItem, { updateHash: false });
    else showEmptyDetail();
  } catch (error) {
    console.error(error);
    elements.loadingState.querySelector("h1").textContent = "The sales library could not be loaded";
    elements.loadingState.querySelector("p").textContent = "Refresh the page. If the issue continues, restart the app with “npm start”.";
    elements.sourceLabel.textContent = "Catalogue unavailable";
  }
}

initialise();
