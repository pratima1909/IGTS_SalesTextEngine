import JSZip from "jszip";
import * as mammoth from "mammoth";
import { PDFParse } from "pdf-parse";
import * as XLSX from "xlsx";

export const SUPPORTED_DOCUMENT_EXTENSIONS = new Set([
  ".csv", ".docx", ".json", ".md", ".pdf", ".pptx", ".txt", ".xlsx",
]);
export const MAX_DOCUMENT_BYTES = 10 * 1024 * 1024;
export const MAX_EXTRACTED_CHARACTERS = 60_000;

function extensionOf(name) {
  const match = String(name || "").toLowerCase().match(/\.[a-z0-9]+$/);
  return match?.[0] || "";
}

function decodeXmlEntities(value) {
  return String(value || "")
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(Number.parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, number) => String.fromCodePoint(Number(number)))
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, "&");
}

function cleanExtractedText(value) {
  return String(value || "")
    .replace(/\u0000/g, " ")
    .replace(/\r\n?/g, "\n")
    .replace(/[\t\f\v]+/g, " ")
    .replace(/[ ]{2,}/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

async function extractPdf(buffer) {
  const parser = new PDFParse({ data: buffer });
  try {
    const result = await parser.getText();
    return result.text || "";
  } finally {
    await parser.destroy();
  }
}

async function extractDocx(buffer) {
  const result = await mammoth.extractRawText({ buffer });
  return result.value || "";
}

function extractXlsx(buffer) {
  const workbook = XLSX.read(buffer, { type: "buffer", cellDates: false });
  return workbook.SheetNames.map((sheetName) => {
    const sheet = workbook.Sheets[sheetName];
    const csv = XLSX.utils.sheet_to_csv(sheet, { blankrows: false });
    return csv.trim() ? `${sheetName}\n${csv}` : "";
  }).filter(Boolean).join("\n\n");
}

async function extractPptx(buffer) {
  const archive = await JSZip.loadAsync(buffer);
  const slideNames = Object.keys(archive.files)
    .filter((name) => /^ppt\/slides\/slide\d+\.xml$/i.test(name))
    .sort((left, right) => Number(left.match(/slide(\d+)/i)?.[1]) - Number(right.match(/slide(\d+)/i)?.[1]));
  const slides = [];
  for (const slideName of slideNames) {
    const xml = await archive.file(slideName).async("string");
    const paragraphs = xml
      .replace(/<a:br\s*\/>/gi, "\n")
      .replace(/<\/a:p>/gi, "\n")
      .match(/<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>/gi)
      ?.map((node) => decodeXmlEntities(node.replace(/^<a:t(?:\s[^>]*)?>|<\/a:t>$/gi, ""))) || [];
    const text = cleanExtractedText(paragraphs.join(" "));
    if (text) slides.push(text);
  }
  return slides.join("\n\n");
}

export async function extractDocumentText({ name, buffer }) {
  const extension = extensionOf(name);
  if (!SUPPORTED_DOCUMENT_EXTENSIONS.has(extension)) {
    throw new Error(`Unsupported file type ${extension || "without an extension"}.`);
  }
  if (!Buffer.isBuffer(buffer)) buffer = Buffer.from(buffer);
  if (!buffer.length) throw new Error("The file is empty.");
  if (buffer.length > MAX_DOCUMENT_BYTES) throw new Error("The file exceeds the 10 MB local limit.");

  let text;
  if ([".csv", ".json", ".md", ".txt"].includes(extension)) text = buffer.toString("utf8");
  else if (extension === ".pdf") text = await extractPdf(buffer);
  else if (extension === ".docx") text = await extractDocx(buffer);
  else if (extension === ".pptx") text = await extractPptx(buffer);
  else if (extension === ".xlsx") text = extractXlsx(buffer);

  text = cleanExtractedText(text);
  if (!text) throw new Error("No readable text was found in the document.");
  const originalCharacters = text.length;
  const truncated = originalCharacters > MAX_EXTRACTED_CHARACTERS;
  if (truncated) text = text.slice(0, MAX_EXTRACTED_CHARACTERS).trim();
  return { text, originalCharacters, truncated, extension };
}

export async function extractDocumentPayload(file) {
  const name = String(file?.name || "").trim();
  if (!name) throw new Error("A document name is required.");
  const base64 = String(file?.data || "").replace(/^data:[^,]*;base64,/i, "");
  if (!base64) throw new Error("Document content is missing.");
  const buffer = Buffer.from(base64, "base64");
  const result = await extractDocumentText({ name, buffer });
  return {
    name,
    mimeType: String(file?.mimeType || "application/octet-stream"),
    size: buffer.length,
    ...result,
  };
}
