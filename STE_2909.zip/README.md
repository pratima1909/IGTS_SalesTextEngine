# IGT Systems Sales Text Engine

A local web app for searching existing sales text and producing catalogue-guided drafts for new items.

The local writer applies the writing and formatting rules from pages 15-29 of the Product Description and Sales Text Guidelines. It aligns exact product names to catalogue data where possible, excludes unverified optional features and unsupported acronyms, normalizes American English, dates, numbers and measurements, and presents editable output in Calibri 11. Human review and authoritative product-name and claims approval remain required.

The catalogue backbone is **Sales Text Data_August 2026.xlsx**, containing 3,727 searchable items. The generated browser data keeps the workbook's first 19 catalogue and sales-text fields; later reporting-only columns remain in the workbook and are not exposed by the app.

## Open the app

Double-click `index.html` to use catalogue search and the local guided writer without setup. All matching and draft construction happen in the browser against the embedded catalogue and approved-fact snapshots; no API key or external service is used at runtime.

## Open through the local server (optional)

1. Open a terminal in this folder and run `npm start`.
2. Open [http://localhost:4173](http://localhost:4173).

Search by item ID, product name, MAG/AG code, or words inside either sales-text field. Use the text tabs to switch between short and long copy, then select **Copy text**.

Select **Write new sales text** to open the studio. Enter keywords and, when available, additional approved product facts. The browser automatically searches the complete substantive DHF index and a dated local snapshot of approved product documentation from the IGT-S Strategy Execution & Transformation SharePoint folder. The DHF index scans all 21 worksheets, makes all 19 substantive worksheets searchable and records the two administrative worksheets separately. Relevant facts are inserted only when a confident match is found. Every retrieved fact shows its exact workbook sheet and row or its exact SharePoint file with a link to open the source.

The SharePoint snapshot contains curated fact passages from content-indexed English product documents. Its separate document register was refreshed on 28 September 2026 and now contains 476 unique files observed by combining the connector's 200-file folder page with site-scoped wildcard and file-type searches. A continuation marker remains, so 476 is a verified lower bound rather than a completeness claim. Documents marked “Register only” are visible for audit but never treated as product evidence. Duplicate, testimonial, research, manual, incompatible-language and market-restricted content is excluded from draft facts. Because runtime access remains local, SharePoint changes require `public/data/sharepoint-source-manifest.js` and `public/data/sharepoint-product-facts.js` to be refreshed.

Select **Source coverage** in the header to review workbook sheet coverage, SharePoint document coverage, freshness, exclusions and every fact-backed SharePoint document. After replacing the DHF workbook, rebuild its complete local index with `python scripts/build_dhf_index.py` before reopening the app.

The writer also retrieves up to five similar catalogue entries and applies the Philips Product Description and Sales Text Guidelines automatically. Short drafts target 15-20 words and summarize the product, relevant capabilities and intended audience. Long drafts combine non-duplicative approved facts into multiple complete paragraphs describing supported features, customer value and workflow context, typically reaching 120-200 words when the matched sources contain enough evidence. Related facts are consolidated into professional copy rather than repetitive “includes” statements. The writer uses American English and complete sentences, avoids bullet lists and filters risky claims, disclosures, internal references and personal pronouns. If no confident source match is found, the app says so and does not insert an unrelated fact. The result must receive human, naming, market-applicability and claims review before use.

Every generated draft is stored locally in the browser’s scrollable **Draft history**. Selecting an entry restores its original inputs, edited short and long text, generation time, workbook facts and rows, and catalogue references. Up to 100 drafts are retained; the history remains on the device and is not sent to an external service.
