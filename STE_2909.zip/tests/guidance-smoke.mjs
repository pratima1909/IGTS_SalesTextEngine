import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

function loadWindowData(path, property) {
  const context = vm.createContext({ window: {} });
  vm.runInContext(fs.readFileSync(path, "utf8"), context);
  return context.window[property];
}

const inertElement = {};
const appContext = vm.createContext({
  console,
  document: { querySelector: () => ({ ...inertElement }) },
  window: {},
});
const appSource = fs.readFileSync("app.js", "utf8")
  .replace(/initialise\(\);\s*$/, "")
  .concat("\nglobalThis.guidanceTestApi = { state, makeSearchIndex, prepareTechnicalSource, prepareSharePointManifest, prepareSharePointSource, normalizePhilipsLanguage, buildLocalDraft };\n");
vm.runInContext(appSource, appContext);

const api = appContext.guidanceTestApi;
const wordCount = (value) => value.match(/\b[\p{L}\p{N}]+(?:[-'][\p{L}\p{N}]+)*\b/gu)?.length || 0;
const salesData = loadWindowData("public/data/items-data.js", "SALES_DATA");
const technicalData = loadWindowData("public/data/azurion-technical-facts.js", "AZURION_TECHNICAL_DATA");
const sharePointManifest = loadWindowData("public/data/sharepoint-source-manifest.js", "SHAREPOINT_SOURCE_MANIFEST");
const sharePointData = loadWindowData("public/data/sharepoint-product-facts.js", "SHAREPOINT_PRODUCT_FACTS");
assert.equal(salesData.metadata.source, "Sales Text Data_August 2026.xlsx");
assert.equal(salesData.metadata.itemCount, 3727);
assert.equal(salesData.items.length, 3727);
api.state.items = salesData.items.map((item) => ({ ...item, _search: api.makeSearchIndex(item) }));
api.prepareTechnicalSource(technicalData);
api.prepareSharePointManifest(sharePointManifest);
api.prepareSharePointSource(sharePointData);
assert.equal(technicalData.metadata.workbookSheetCount, 21);
assert.equal(technicalData.metadata.indexedSheetCount, 19);
assert.equal(technicalData.metadata.technicalFactCount, 553);
assert.ok(technicalData.metadata.supplementalFactCount > 1300);
assert.equal(sharePointManifest.metadata.listedFileCount, 200);
assert.ok(sharePointManifest.metadata.observedDocumentCount >= 476);
assert.equal(sharePointManifest.metadata.continuationAvailable, true);
assert.ok(sharePointData.metadata.documentCount >= 65);
assert.ok(sharePointData.metadata.factCount >= 116);
assert.equal(sharePointData.facts.length, sharePointData.metadata.factCount);

const normalized = api.normalizePhilipsLanguage("Colour display, 8.9cm, 15000 images, dated 03-18-2018.");
assert.match(normalized, /Color display/);
assert.match(normalized, /8\.9 cm \(3\.5 inch\)/);
assert.match(normalized, /15,000 images/);
assert.match(normalized, /2018-03-18/);

const draft = api.buildLocalDraft({
  itemName: "Touchscreen module Pro",
  keywords: "image viewing; intuitive controls; unique; optional pointer; ABC workflow",
  facts: "visualization of the acquired images; draw markers on the images directly on the TSM screen; adjust the collimator by drag and drop on the clinical images; use the interventional room pointer to highlight details on the clinical images",
  audience: "interventional Cardiologist",
});

assert.match(draft.model, /^Guide pp\. 15-29/);
assert.match(draft.drafts.longText, /^Features of the product\n\n/);
assert.match(draft.drafts.longText, /Touch Screen Module Pro/);
assert.doesNotMatch(draft.drafts.longText, /\bincludes\b.*\bincludes\b/i);
assert.doesNotMatch(draft.drafts.longText, /access place/i);
assert.doesNotMatch(draft.drafts.longText, /\b(?:unique|optional|ABC|TSM)\b/i);
assert.equal((draft.drafts.longText.match(/place markers/gi) || []).length, 1);
assert.match(draft.drafts.shortText, /^Touch Screen Module Pro\b/);
assert.ok(wordCount(draft.drafts.shortText) >= 15 && wordCount(draft.drafts.shortText) <= 20);
assert.ok(draft.drafts.longText.split(/(?<=[.!?])\s+/).length >= 5);
assert.ok(draft.sharePointSource.facts.length >= 2);
assert.ok(draft.sharePointSource.facts.every((fact) => fact.source?.url?.includes("share.philips.com")));
assert.ok(draft.drafts.factWarnings.some((warning) => /Product naming was aligned/.test(warning)));
assert.ok(draft.drafts.factWarnings.some((warning) => /Excluded content/.test(warning)));

const sharePointOnlyDraft = api.buildLocalDraft({
  itemName: "Touchscreen module Pro",
  keywords: "image viewing; collimation control; clinical image interaction; interventional room pointer",
  facts: "",
  audience: "interventional cardiologists",
});
assert.match(sharePointOnlyDraft.drafts.longText, /collimator and wedge adjustment/i);
assert.match(sharePointOnlyDraft.drafts.longText, /visualization of acquired images at tableside/i);

const clarityDraft = api.buildLocalDraft({
  itemName: "ClarityIQ",
  keywords: "low dose imaging; image quality; noise reduction; motion correction",
  facts: "",
  audience: "interventional cardiologists",
});
assert.match(clarityDraft.drafts.shortText, /^ClarityIQ\b/);
assert.ok(wordCount(clarityDraft.drafts.shortText) >= 15 && wordCount(clarityDraft.drafts.shortText) <= 20);
assert.equal(clarityDraft.sharePointSource.facts.length, 6);
assert.match(clarityDraft.drafts.longText, /supports lower X-ray dose while maintaining equivalent image quality/i);
assert.match(clarityDraft.drafts.longText, /flexible digital imaging pipeline/i);
assert.match(clarityDraft.drafts.longText, /Automatic Motion Control reduces motion artifacts/i);
assert.match(clarityDraft.drafts.longText, /spatial noise reduction/i);
assert.doesNotMatch(clarityDraft.drafts.longText, /specifications list/i);
assert.ok(clarityDraft.sharePointSource.facts.every((fact) => fact.source?.url?.includes("share.philips.com")));

const smartMaskDraft = api.buildLocalDraft({
  itemName: "SmartMask",
  keywords: "AI Tools",
  facts: "",
  audience: "interventional cardiologist",
});
assert.match(smartMaskDraft.drafts.shortText, /^SmartMask\b/);
assert.ok(wordCount(smartMaskDraft.drafts.shortText) >= 15 && wordCount(smartMaskDraft.drafts.shortText) <= 20);
assert.equal(smartMaskDraft.technicalSource.facts.length, 0);
assert.match(smartMaskDraft.drafts.longText, /overlaying fluoroscopy with a selected reference image/i);
assert.match(smartMaskDraft.drafts.longText, /tableside/i);
assert.match(smartMaskDraft.drafts.longText, /pre- and post-intervention comparisons/i);
assert.ok(smartMaskDraft.drafts.longText.split(/(?<=[.!?])\s+/).length >= 7);
assert.doesNotMatch(smartMaskDraft.drafts.longText, /\bAI Tools\b/i);
assert.doesNotMatch(smartMaskDraft.drafts.longText, /mains (?:voltage|frequency)|air kerma|specifications list/i);
assert.ok(smartMaskDraft.references.some((reference) => /SmartMask/i.test(reference.name)));
assert.ok(smartMaskDraft.drafts.factWarnings.some((warning) => /product-specific language/i.test(warning)));
assert.ok(smartMaskDraft.drafts.factWarnings.some((warning) => /AI Tools/.test(warning)));

const smartIqDraft = api.buildLocalDraft({
  itemName: "SmartIQ",
  keywords: "Workflow Efficiency",
  facts: "",
  audience: "interventional cardiologist",
});
assert.match(smartIqDraft.drafts.shortText, /^SmartIQ\b/);
assert.ok(wordCount(smartIqDraft.drafts.shortText) >= 15 && wordCount(smartIqDraft.drafts.shortText) <= 20);
assert.equal(smartIqDraft.sharePointSource.facts.length, 4);
assert.ok(wordCount(smartIqDraft.drafts.longText) >= 120);
assert.ok(smartIqDraft.drafts.longText.split("\n\n").length >= 4);
assert.match(smartIqDraft.drafts.longText, /content-aware algorithm/i);
assert.match(smartIqDraft.drafts.longText, /low iodinated contrast medium/i);
assert.match(smartIqDraft.drafts.longText, /existing.*workflows/i);
assert.doesNotMatch(smartIqDraft.drafts.longText, /clinicaltrials\.gov|\bIFU\b|\[\d+\]|\b(?:you|your|we|our)\b/i);

const azurionCoverageDraft = api.buildLocalDraft({
  itemName: "Azurion 7",
  keywords: "workflow efficiency; image guidance",
  facts: "",
  audience: "interventional teams",
});
assert.ok(azurionCoverageDraft.sharePointSource.documentReferences.length >= 10);
assert.ok(azurionCoverageDraft.sharePointSource.documentReferences.some((source) => !source.contentIndexed));
assert.ok(azurionCoverageDraft.drafts.factWarnings.some((warning) => /Source coverage gate/.test(warning)));

const zenitionCoverageDraft = api.buildLocalDraft({
  itemName: "Zenition 90",
  keywords: "workflow efficiency; intuitive controls; software options",
  facts: "",
  audience: "surgical teams",
});
assert.ok(zenitionCoverageDraft.sharePointSource.facts.length >= 3);
assert.match(zenitionCoverageDraft.drafts.longText, /user-friendly controls/i);
assert.match(zenitionCoverageDraft.drafts.longText, /software options/i);
assert.ok(zenitionCoverageDraft.sharePointSource.documentReferences.some((source) => source.contentIndexed));
assert.doesNotMatch(zenitionCoverageDraft.drafts.longText, /unmatched|highest standards|prevent malware|\bideal\b|excellent image quality/i);
assert.doesNotMatch(zenitionCoverageDraft.drafts.longText, /e-?learning|education|enrol|licen[cs]e|expires?|purchase date|installation date/i);

console.log("Guidance smoke test passed.");
