import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

function loadWindowData(path, property) {
  const context = vm.createContext({ window: {} });
  vm.runInContext(fs.readFileSync(path, "utf8"), context);
  return context.window[property];
}

const dhf = loadWindowData("public/data/azurion-technical-facts.js", "AZURION_TECHNICAL_DATA");
const manifest = loadWindowData("public/data/sharepoint-source-manifest.js", "SHAREPOINT_SOURCE_MANIFEST");
const sharePoint = loadWindowData("public/data/sharepoint-product-facts.js", "SHAREPOINT_PRODUCT_FACTS");

assert.equal(dhf.metadata.workbookSheetCount, 21);
assert.equal(dhf.metadata.sheetCoverage.length, 21);
assert.equal(dhf.metadata.indexedSheetCount, 19);
assert.equal(dhf.metadata.administrativeSheetCount, 2);
assert.equal(dhf.metadata.technicalFactCount, dhf.facts.length);
assert.equal(dhf.metadata.supplementalFactCount, dhf.supplementalFacts.length);
assert.equal(dhf.metadata.extractedFactCount, dhf.facts.length + dhf.supplementalFacts.length);
assert.equal(
  dhf.metadata.populatedCellCount,
  dhf.metadata.sheetCoverage.reduce((sum, sheet) => sum + sheet.populatedCells, 0),
);
assert.equal(
  Array.from(dhf.metadata.sheetCoverage)
    .filter((sheet) => sheet.status === "Administrative")
    .map((sheet) => sheet.name)
    .sort()
    .join("|"),
  "Frontpage|Revision History",
);
assert.ok(dhf.metadata.sheetCoverage.filter((sheet) => /clarity/i.test(sheet.name)).every((sheet) => sheet.status === "Indexed"));

assert.equal(manifest.metadata.listedFileCount, 200);
assert.equal(manifest.metadata.observedDocumentCount, manifest.documents.length);
assert.ok(manifest.metadata.observedDocumentCount >= 476);
assert.ok(manifest.metadata.searchDiscoveredFileCount >= 276);
assert.equal(manifest.metadata.continuationAvailable, true);
assert.equal(new Set(manifest.documents.map((document) => document.id)).size, manifest.documents.length);
assert.equal(new Set(manifest.documents.map((document) => document.title)).size, manifest.documents.length);

assert.equal(sharePoint.metadata.documentCount, sharePoint.documents.length);
assert.equal(sharePoint.metadata.factCount, sharePoint.facts.length);
assert.equal(new Set(sharePoint.documents.map((document) => document.id)).size, sharePoint.documents.length);
const documentIds = new Set(sharePoint.documents.map((document) => document.id));
assert.ok(sharePoint.facts.every((fact) => documentIds.has(fact.sourceId)));
assert.ok(sharePoint.facts.filter((fact) => fact.product === "ClarityIQ").length >= 8);

const html = fs.readFileSync("index.html", "utf8");
for (const id of ["openCoverage", "coveragePanel", "dhfCoverageKpis", "spCoverageKpis", "coverageSheetList", "coverageDocumentList"]) {
  assert.match(html, new RegExp(`id=["']${id}["']`));
}
assert.match(html, /sharepoint-source-manifest\.js/);

console.log("Source coverage test passed.");
